# Shingū follow-up research (round 2)

Checked on 2026-09-30. Every item gives a verdict, the quote as written in the source (Japanese) and the URL. When a figure is mine, or comes from a search listing rather than a page I fetched, the item says so.

---

## 1. Wildfire (林野火災)

### 1a. Wakayama Prefecture wildfire statistics (件数 / 焼損面積) — NOT FOUND
- I found no official Wakayama prefecture table of wildfire counts or burned area.
- The prefecture's 林業概況 (R8) PDF is mostly images and has no searchable 林野火災 text. I did not check it by eye.
- The only prefecture-level figure turned up (23 fires in 2011) comes from a third-party ranking site, so I have not used it.
- What the prefecture does publish is the new warning system:
  - 「令和8年1月1日から、全国的に「林野火災注意報・林野火災警報」の運用が開始されております。」
  - 「林野火災注意報や林野火災警報は、市町村の火災予防条例で規定され、市町村長が林野火災の危険性に応じて発令するものです。」
  - URL: https://www.pref.wakayama.lg.jp/prefg/011600/rinyakasai.html
- **PARTLY:** Shingū City's official X account posted 「当地域に林野火災注意報が発令中です。火災が発生しやすい状態です。屋外での火の取扱いは控えてください。」 I saw this only as a search snippet and did not capture the date. URL: https://x.com/Shingu_City/status/2025012636400976019

### 1b. Recent fire in Shingū — PARTLY (headlines only)
- Livedoor/MBS headline 「和歌山県新宮市で山林火災の可能性 警察のヘリコプターが煙発見」, dated 「2026年5月18日 18時28分」. The article body now reads 「提供社の都合により、削除されました。」. URL: https://news.livedoor.com/topics/detail/31307090/
- NHK headline (from the search listing; the page would not load): 「和歌山 新宮で山火事 火の勢い弱まる 人や建物の被害なし」. URL: https://news.web.nhk/newsweb/na/nb-2040022324
- Two details come only from a search summary and are not verified: the location (熊野川町), and firefighting continuing until about 16:30 on 19 May.
- Burned area: NOT FOUND.

### 1c. The 1946 Shōwa Nankai earthquake fire in Shingū
- **VERIFIED (Wakayama Prefecture).** 「この地震では、火災が発生して新宮市で市街地の3分の1が焼失したり、津波により多くの溺死者が出るなど、地震の揺れによる被害よりも、津波及び地震に伴う火災による被害の方がはるかに大きかったのです。」
  - URL: https://www.pref.wakayama.lg.jp/prefg/040400/bosai/jisinnsonae.html
- **VERIFIED, scholarly secondary source** (Ishibashi 2014, Iwanami; excerpt hosted by GHDNet). 「和歌山県新宮市は1944 年の東南海地震に続いて1945 年の空襲と艦砲射撃でも被害を受けていたが、本地震で死者58 人、全壊600 戸、全焼2400 戸の大被害をこうむった。」
  - URL: https://plaza.umin.ac.jp/GHDNet/circle/14/y9051.pdf
- **VERIFIED, but for the whole prefecture only** (JMA Wakayama, citing 日本被害地震総覧). 「【和歌山県】 死者195、負傷者562、不明者74、家屋全壊969、家屋半壊2,442、家屋流失325、家屋焼失2,399、家屋浸水14,102」
  - URL: https://www.data.jma.go.jp/wakayama/bousai/phenomenon/zishinsaigai.html
- **NOT VERIFIED:** "約16時間延焼". This appears only in a search summary that looks Wikipedia-derived.
- **NOT FOUND:**
  - A Cabinet Office 災害教訓 report covering the 1946 Shingū fire.
  - The burned area in hectares.

---

## 2. Drought and water supply — NOT FOUND (no 渇水 or 取水制限 record for the Kumano or Shingū's water supply)

### What I checked
MLIT's drought pages have no entry for 熊野川 or 新宮市:
- 過去の渇水情報: https://www.mlit.go.jp/mizukokudo/mizsei/mizukokudo_mizsei_fr2_000009.html
- 給水制限情報: https://www.mlit.go.jp/mizukokudo/watersupply/stf_seisakunitsuite_bunya_topics_bukyoku_kenkou_suido_kikikanri_dangensui.html
- 令和5年度の渇水状況: https://www.mlit.go.jp/mizukokudo/mizsei/mizukokudo_mizsei_fr2_000017.html

### 2005: the nearby restriction was on the 紀の川, not the Kumano
- MLIT's drought report of 27 June 2005 names the 紀の川: 「和歌山県の紀の川では、猿谷ダム、大迫ダムおよび津風呂ダムの合計の貯水率が概ね５０％に低下したため、本日（２７日）より取水制限を開始しました。」
  - URL: https://www.mlit.go.jp/kisha/kisha05/05/050627_.html
- 猿谷ダム sits in the upper Kumano basin, but its water is sent to the 紀の川. MLIT's Kumano overview diagram labels its outflow 「紀の川へ」 / 「熊野川下流へ」.
  - URL: https://www.kkr.mlit.go.jp/kinan/river/kumano_kondan/jyunbikai/files/giji/001/pdf/3-3_gaiyou.pdf

### Watch-outs when searching
- The 「新宮ダム」 in that same 2005 report is in Ehime (銅山川).
- Search results for 「新宮 渇水」 are mostly about 福岡県新宮町, which set up a drought office in 2026. It is a different town.

### Counterpoint: MLIT treats the Kumano as a spare water source — VERIFIED
From MLIT's 2009 water-crisis report:
- 「新宮港は、国・和歌山県・新宮市・那智勝浦町による「新宮港振興ビジョン」の中で、渇水時・災害時の救援用水資源として熊野の水資源を活用する「水資源救援港」として位置づけられている。」
- 「熊野川は、流況と水利用の状況から、約1~2m3/s(約9 万～17 万m3/日)の自流取水の余力が有るものと推測できる。」
- On the 2007 water-bag trials: 「和歌山県新宮港において…水バッグ（容量1,000m3）に注水し、徳島県富岡港（阿南市）まで約170km をタグボートで曳航した。」
- URL: https://www.mlit.go.jp/common/000116363.pdf

### Other
- Context from round 1: JMA 新宮 recorded 0.0 mm for the whole of January 2026 and January 2011. That is dry-spell data, not a drought event.
- Dam-related low flows in 2005, 2013 or 2022: NOT FOUND.

---

## 3. 池田港 and 三輪崎港

### 池田港 — PARTLY
The source is the city tourism association, not the city, prefecture or MLIT.
- 「ことに新宮産の炭は評判がよく、大消費地の江戸に海路を使って年間10万俵も送られ、江戸の炭相場を左右した。」
- 「新宮炭を満載した藩船は、丹鶴城下の炭納屋に集められ、新宮河口の池田港、あるいは鵜殿港から江戸へと航行した。」
- 「御手船といわれた藩船は港に常時50隻も停泊し、600石積みの船で一航海で2000俵を廻送した。」
- 「また海を越えて運ばれた熊野材は、江戸の木材需要の3割をまかなったといわ[れ…]」
- The same page mentions the 丹鶴丸's 「池田港での進水式」.
- URL: https://www.shinguu.jp/shinguu-modern-file06
- The same association's page https://www.shinguu.jp/shinguu gives 「最盛期には江戸入荷材の2割」, which does not match the 3割 above.

### 三輪崎港 — NOT FOUND
- No official source links 三輪崎港 to shipping timber or charcoal to Osaka or Edo.
- The second port the sources name is **鵜殿港**, on the Mie side, not 三輪崎.

### Osaka — NOT FOUND for Shingū
The prefecture contrasts Shingū (Edo) with Wakayama city (Osaka):
- 「一方、新宮市については、熊野材の集積地として近世からの歴史があり、製材品を江戸に送っていたことから、取扱量が大きくなっていたようです。」
- 「和歌山市では、大消費地の大阪に近かったため素材のまま売りさばくのが商売上得策であった」
- URL: https://www.pref.wakayama.lg.jp/prefg/070600/kisyuzai/history.html

### City source — VERIFIED
- 「熊野川流域の木炭を水ノ手郭に集積し、水運により江戸へと運んでいました。」
- URL: https://www.city.shingu.lg.jp/Info/229

---

## 4. 丹鶴ホール and 新宮下本町遺跡 — VERIFIED

### Short answer
- The excavation happened *because of* the hall project.
- The hall building was pushed onto the disturbed western part of the plot. That part was excavated and recorded, some features were moved, and a few were kept in place under the building.
- The designated historic site (5,796.37 m²) is the eastern part, laid out as the hall's grounds.
- It is a **stand-alone** national historic site called 「新宮下本町遺跡」. It is **not** an addition to 新宮城跡.

### Designation sentence (city page, as written)
- 「新宮下本町遺跡は、中世以降、太平洋航路の重要な拠点であった新宮における港湾や海を介した交流の実態を知る上で重要なだけでなく、中世の海上交通と宗教勢力のとの関係や、平安時代末頃以降から全国へ信仰が拡大する熊野三山の経済基盤等について考える上でも重要な遺跡であるとして、令和４年１１月１０日に国史跡に指定されています。」
- URL: https://www.city.shingu.lg.jp/info/690

### What was designated (保存活用計画, ch. 3)
- 「名 称：新宮下本町遺跡（しんぐうしもほんまちいせき) 所 在 地：和歌山県新宮市 指 定 日：令和４年(2022)11 月10 日 指定面積：5,796.37 ㎡ (市有地 5,796.37 ㎡) 区 分：記念物(史跡) 指定基準：史跡の部一（集落跡）六（交通・通信施設）所 有 者：新宮市」
- The official notice as printed: 「文部科学省告示第百四十一号 … 令和三年三月二十六日 文部科学大臣 永岡 桂子 名称 新宮下本町遺跡 所在地 和歌山県新宮市下本町二丁目二番一のうち 地域 実測五七九六・三七平方メートル」.
  - **Flag:** the printed date 令和三年三月二十六日 conflicts with the 2022-11-10 designation. It is probably a transcription error in the plan.
- Also from ch. 3: 「新宮下本町遺跡は、平成27 年（2015）に新宮市文化複合施設建設に伴う発掘調査で確認された。」 and 「地下式倉庫は、30 棟以上検出され」.
- URL: https://www.city.shingu.lg.jp/div/bunkazai/pdf/3_shingushimohonmachi.pdf

### Why the dig happened (総合調査報告書, ch. 1, linked from info/690)
- 「新宮市では、中心市街地の再整備による活性化を目的として、新宮市文化複合施設（文化ホール、図書館など）の建設を計画したが、建設予定地（旧新宮市立丹鶴小学校敷地、旧新宮市民会館敷地）が史跡新宮城跡に近接する場所であり、近世の城下町などの遺跡が展開する可能性があることから平成27 年に試掘調査を実施した。」
- URL: https://www.city.shingu.lg.jp/div/bunka-1/pdf/iseki/shimohonmachi_2.pdf

### How the building was placed (same report)
- The building moved west and the east was kept: 「施設の位置についてはすでに攪乱を受け遺構が残存しない範囲の多い敷地西側へと寄せることにし、第１次調査において敷地中央で確認された大型土坑列から東側の遺構を現状保存することとし、保存した範囲については広場などとして整備することになった。」
- On the building footprint, the second dig (3,461 m²) was a 記録保存 excavation, meaning features were recorded and then removed. Some were moved or kept in other ways: 「移設（近世石垣、地下式倉庫、石段通路、石垣）や立体剥ぎ取り（地下式倉庫）…」
- A few were kept in place under the building: 「なお、調査で検出された一部の地下式倉庫や大型土坑については、建物基礎構造の変更や矢板打設により現状保存を行った。」
- Construction dates: 「同年４月に施設建設工事が着工し、令和３年７月に竣工した。」

### The designated site is the hall's grounds (保存活用計画, ch. 1)
- 「史跡新宮下本町遺跡の史跡指定地全体が、文化複合施設の外構として整備されており」
- 「しかし、史跡地の大半は文化複合施設の敷地であり、これまでの発掘調査箇所は既に埋め戻されている。」
- The land record: 「新宮市下本町二丁目２番１(11,437 ㎡)のうち実測5,796.37 ㎡」 (地目 学校用地).
- The opening date is now **VERIFIED** as October 2021 (month only). The 令和３年度 row of the timeline table reads 「文化複合施設建設工事竣工（７月）・開館（10 月）」.
- URL: https://www.city.shingu.lg.jp/div/bunkazai/pdf/1_shingushimohonmachi.pdf

---

## 5. 神倉神社: steps and ゴトビキ岩 — VERIFIED

### 538 steps
- 熊野速玉大社 (official site): 「参詣者を迎えるのは、仰ぎ見るような538段の急峻な石段、通称「男坂（おとこざか）」です。自然石を積み上げた荒々しく力強い造りは「鎌倉積み」と呼ばれ、建久4年（1193年）に源頼朝公が寄進したと伝えられています。」
  - URL: https://kumanohayatama.jp/gotobiki/ (the same text is at https://kumanohayatama.jp/?page_id=18)
- Wakayama Prefecture (神倉山 page): 「見る者を圧倒する538段の石段です。」 and 「急峻な538段の石段を駆け下ります。」
  - URL: https://www.pref.wakayama.lg.jp/prefg/081300/d00214824.html
- Wakayama Board of Education cultural-properties site: 「麓から神社までは源頼朝が寄進したと伝える538段の石段があり」
  - The page is titled 「熊野速玉大社境内（神倉山）（熊野三山）」.
  - URL: https://wakayama-bunkazai.jp/bunkazai/bunkazai_447/

### ゴトビキ岩 as 御神体
- 熊野速玉大社, in its visitor notes: 「・ゴトビキ岩は御神体です」; it also calls the rock 「聖なる磐座「ゴトビキ岩」」.
- Wakayama Prefecture: 「神倉神社は、神倉山の山上にある「ゴトビキ岩」と呼ばれる巨石群を御神としています。」 (written 御神, as on the page).
- Board of Education: 「その中の一つはヒキガエルに似た形から「ゴトビキ岩」と呼ばれている。この岩の間から、銅鐸の破片や経塚が発見されており、古代から信仰の場として神聖視されてきた山」

### Number of participants — PARTLY
- The source is the prefecture's official tourism site, not an official count.
- 「白装束に荒縄を締めた約2000人の男子が松明を持ち、山頂から急な石段を駆け下りる「火の滝」」
- URL: https://www.wakayama-kanko.or.jp/spots/detail_479.html

---

## 6. Landslide dams (天然ダム / 河道閉塞) in 2011 — VERIFIED

### Official count: 17
- MLIT's river-and-sabo bureau list: 「別紙 台風１２号関係 河道閉塞発生箇所（奈良県・和歌山県） 平成２３年９月１３日 １４時現在 水管理・国土保全局 砂防部 合計：１７箇所」.
- It adds: 「※⑨は調査の結果、河道閉塞でない ことが判明したため、欠番」 (⑨ turned out not to be a landslide dam, so its number is skipped).
- URL: https://www.mlit.go.jp/common/000166229.pdf
- The same list is repeated in MLIT's report of 31 October 2011: https://www.mlit.go.jp/river/sabo/dosyahou_review/02/111031_shiryo2.pdf

### The 17 sites
| Prefecture | Sites | Count |
|---|---|---|
| Nara | ①②③ 天川村坪内, ④ 五條市大塔町宇井, ⑤ 十津川村長殿, ⑥ 五條市大塔町赤谷, ⑦ 十津川村栗平, ⑧ 十津川村野尻, ⑩ 野迫川村桧股, ⑪ 黒滝村赤滝, ⑭ 野迫川村北股, ⑰ 十津川村杉清, ⑱ 上北山村白川 | 13 |
| Wakayama | ⑫ 田辺市熊野（いや）, ⑬ みなべ町東神野川, ⑮ 田辺市本宮町三越, ⑯ 田辺市中辺路町真砂 | 4 |

### In Shingū city: none
- No landslide dam on the list is in 新宮市.

### On the Kumano main stem: at least 野尻 (⑧)
- MLIT: 「【奈良県十津川村野尻地区で発生した災害】・斜面から流出した土砂で熊野川がせき止められ、あふれ出した水が対岸の村営住宅2棟を直撃して死者・行方不明者8名を出した。」 (111031_shiryo2.pdf)
- I could not tell from these documents which of the other sites sit on the main stem.
- Five sites carry the label 緊急調査対象 (emergency survey under the sediment-disaster law). I did not work out which five from the extracted text.

### Wakayama's largest site: 田辺市熊野（いや）
- 「田辺市熊野（いや）地区で発生した深層崩壊と河道閉塞（天然ダム）。崩壊土砂量約470万ｍ3、崩壊高さ約250ｍ、幅約440ｍ。」
- URL: https://www.pref.wakayama.lg.jp/prefg/080604/2011disaster/d00221247.html

### Sediment disasters in Shingū (not landslide dams)
- Wakayama Prefecture: 「新宮市丸岡谷で発生した土石流の被害状況。土石流が住居まで到達した。」 and 「新宮市新宮では9月4日に時間雨量132．5ｍｍの猛烈な雨を観測しました。」 (d00221247.html)
- MLIT map of sediment disasters that caused casualties: 「⑨土石流等 和歌山県新宮市南檜杖 【死者４名】」 and 「⑩がけ崩れ 和歌山県新宮市木ノ川」.
  - The extracted text is jumbled, so treat the pairing of numbers and places as PARTLY.
- MLIT, whole region: 「土砂災害により、三重県、奈良県、和歌山県において死者４１名、行方不明者１５名の人的被害が発生」 and 「１０１件の土砂災害が発生 (１０月２８日１０時現在)」 (111031_shiryo2.pdf).

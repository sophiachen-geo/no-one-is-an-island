# Official documents (agent B, verified 200)
- 立地適正化計画 (Location Optimization Plan) 2017, rev. Sep 2021: https://www.city.shingu.lg.jp/Info/773 ; PDF https://www.city.shingu.lg.jp/div/kikaku/pdf/rittekikaiteiban.pdf
  amendment reason: red zones designated Jul 2018 by Wakayama -> removed from 居住誘導区域
- 都市計画マスタープラン (Urban Planning Master Plan) Dec 2012: https://www.city.shingu.lg.jp/Info/402 ; PDF https://www.city.shingu.lg.jp/div/tosiken-1/pdf/keikaku/toshimas.pdf (slogan 熊野の都 新宮)
- 第２次新宮市総合計画 後期基本計画 (Second Comprehensive Plan, latter-term 2023–2027): https://www.city.shingu.lg.jp/info/1987
- 国土強靭化地域計画 (National Resilience Regional Plan) Dec 2019, 5th rev Mar 2026: https://www.city.shingu.lg.jp/info/1024 ; PDF https://www.city.shingu.lg.jp/div/bousai/pdf/kokudokyoujin/shingu-kokudokyoujin0803.pdf
- 地域防災計画 (Regional Disaster Management Plan) rev Mar 2026: https://www.city.shingu.lg.jp/info/412
- 津波防災地域づくり推進計画 (Tsunami Disaster-Resilient Community Development Promotion Plan) Oct 2025: https://www.city.shingu.lg.jp/info/2811 ; PDF https://www.city.shingu.lg.jp/div/bousai/pdf/suisinkeikaku/suisinkeikaku.pdf
- 新宮川水系流域治水プロジェクト (Basin-wide Flood Management Project) 30 Mar 2021: https://www.mlit.go.jp/river/kasen/ryuiki_pro/index.html ; PDF https://www.mlit.go.jp/river/kasen/ryuiki_pro/pdf/86/86-1.pdf ; 2.0 page https://www.kkr.mlit.go.jp/kinan/kasen/ryuiki_chisui/index.html
- 新宮川水系河川整備計画 (River Improvement Plan) Mar 2022: https://www.kkr.mlit.go.jp/kinan/kasen/kasenseibikeikaku/index.html ; PDF https://www.kkr.mlit.go.jp/kinan/kasen/kasenseibikeikaku/k1cog50000000bjf-att/220331seibikeikaku.pdf
- 新宮川水系河川整備基本方針 (Basic River Improvement Policy) rev 15 Oct 2021: https://www.mlit.go.jp/river/basic_info/jigyo_keikaku/gaiyou/seibi/shingu_index.html
- Wakayama 2026 seismic/tsunami assumptions: https://www.pref.wakayama.lg.jp/prefg/011400/bousai/shinsui/r8sinsui.html
- 東牟婁圏域 都市計画区域マスタープラン May 2015: https://www.pref.wakayama.lg.jp/prefg/080900/masterplan/kuiki_mp.html
- 市田川 特定都市河川: designation planned FY2026 (R8年度中) https://www.mlit.go.jp/river/kasen/tokuteitoshikasen/pdf/260901.pdf ; https://www.kkr.mlit.go.jp/kinan/kasen/tokuteitoshi/index.html
- 観光振興計画 (Tourism Promotion Plan) Apr 2018: https://www.city.shingu.lg.jp/info/904 ; PDF https://www.city.shingu.lg.jp/div/syoukou-1/pdf/syoukou/kankoshinkokeikaku.pdf
- 紀伊半島大水害新宮市記録集: https://www.city.shingu.lg.jp/info/575
- Hazard map: https://www.city.shingu.lg.jp/info/1132 ; ja https://shingu.nigedoki-map.com/ en /en zh /zh (简体) ko /ko tl /tl
# Tourism (Wakayama 観光客動態調査)
- 2025: total 1,293,447; overnight 187,788; day 1,105,659; foreign 22,040 人泊 (R7houkokusho.pdf p14/p33) https://www.pref.wakayama.lg.jp/prefg/062400/doutai2_d/fil/R7houkokusho.pdf
- 2019: total 1,368,191; overnight 146,822; foreign 12,504 人泊 https://www.pref.wakayama.lg.jp/prefg/062400/doutai2_d/fil/R01_doutaityousa.pdf
- river boats FY2011 2,426 ... FY2016 4,127 (1,306 foreign) (tourism plan)
- cruise calls 新宮港 2010–2019 total 82; 2018: 15 (pref) https://www.pref.wakayama.lg.jp/bcms/prefg/082400/cruise/port_call_results.html
- 川舟下り revived Sep 2005; 16 km to the riverbank beside Hayatama (MLIT kinan) https://www.kkr.mlit.go.jp/kinan/fukeikaidokumano/kumano/area5/05kawanokodo.html

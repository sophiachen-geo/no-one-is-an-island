"""Extract Shingu (30207) and Kiho (24562) facilities from KSJ layers (Wakayama 30, Mie 24 files)."""
import json, os, zipfile, io, csv, glob, collections
import shapefile
from shapely.geometry import shape, Point, mapping
from shapely.ops import unary_union

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = os.path.join(BASE, 'ksj')
X = os.path.join(K, '_x')
OUT = os.path.join(K, 'subset_shingu_kiho'); os.makedirs(OUT, exist_ok=True)
CL = json.load(open(os.path.join(K, 'codelist', 'codelists.json'), encoding='utf-8'))
MED = {'1': '病院', '2': '診療所', '3': '歯科診療所'}
P05C = {'1': '本庁', '2': '支所・出張所・連絡所', '3': 'その他行政サービス施設', '4': '公立公民館', '5': '集会施設'}
P17C = {'1': '消防本部', '2': '消防署', '3': '分署・出張所'}
P34C = {'1': '本庁', '2': '支所・出張所・連絡所'}
CITY = {'30207': '新宮市', '24562': '紀宝町'}

sa = json.load(open(os.path.join(BASE, 'census2020_smallarea', 'derived_smallarea_age_2020_shingu_kiho.geojson'), encoding='utf-8'))
muni = {c: unary_union([shape(f['geometry']) for f in sa['features'] if f['properties']['group_key'].startswith(c)]) for c in CITY}
mbuf = {c: g.buffer(0.0015) for c, g in muni.items()}

for z in glob.glob(os.path.join(K, '*_GML.zip')):
    d = os.path.join(X, os.path.basename(z)[:-4])
    if not os.path.isdir(d):
        zipfile.ZipFile(z).extractall(d)

def city_of(pt, code=None):
    if code and str(code)[:5] in CITY:
        return str(code)[:5], 'admin_code'
    if code:
        return None, 'admin_code'
    for c, g in muni.items():
        if g.contains(pt): return c, 'spatial'
    for c, g in mbuf.items():
        if g.contains(pt): return c, 'spatial_buffer150m'
    return None, None

def read_geojson(pattern):
    feats = []
    for f in glob.glob(os.path.join(X, pattern), recursive=True):
        feats += json.load(open(f, encoding='utf-8'))['features']
    return feats

def read_shp(pattern, enc='cp932'):
    feats = []
    for f in glob.glob(os.path.join(X, pattern), recursive=True):
        r = shapefile.Reader(f, encoding=enc)
        flds = [x[0] for x in r.fields[1:]]
        for sr in r.iterShapeRecords():
            feats.append({'type': 'Feature', 'properties': dict(zip(flds, list(sr.record))), 'geometry': sr.shape.__geo_interface__})
    return feats

layers = {
  'P04-20_medical_2020': (read_geojson('P04-20_*_GML/**/*.geojson'), None,
        lambda p: {'category': MED.get(str(p['P04_001'])), 'name': p['P04_002'], 'address': p['P04_003'], 'beds': p['P04_008'],
                   'emergency_designated': p['P04_009'] == 1, 'disaster_base_hospital': {1: '基幹', 2: '地域'}.get(p['P04_010'])}),
  'P14-23_welfare_2023': (read_geojson('P14-23_*_GML/**/*.geojson'), 'P14_003',
        lambda p: {'category_major': CL['welfareInstitution_welfareFacilityMajorClassificationCode'].get(p['P14_005']),
                   'category_middle': CL['welfareInstitution_welfareFacilityMiddleClassificationCode'].get(p['P14_006']),
                   'category_minor': CL['welfareInstitution_welfareFacilityMinorClassificationCode'].get(p['P14_007']),
                   'name': p['P14_008'], 'address': (p['P14_002'] or '') + (p['P14_004'] or '')}),
  'P29-23_schools_2023': (read_geojson('P29-23_*_GML/**/*.geojson'), 'P29_001',
        lambda p: {'category': CL['SchoolClassCd-v2_0'].get(p['P29_003']), 'name': p['P29_004'], 'address': p['P29_005'],
                   'closed_code': p['P29_007']}),
  'P05-22_cityoffices_halls_2022': (read_geojson('P05-22_*_GML/**/*.geojson'), 'P05_001',
        lambda p: {'category': P05C.get(str(p['P05_002'])), 'name': p['P05_003'], 'address': p['P05_004']}),
  'P17-12_firestations_2012_NONCOMMERCIAL': (read_shp('P17-12_*_GML/*FireStation.shp'), 'P17_002',
        lambda p: {'category': P17C.get(str(p['P17_003'])), 'name': p['P17_001'], 'address': p['P17_004']}),
  'P18-12_police_2012_NONCOMMERCIAL': (read_shp('P18-12_*_GML/*PoliceStation.shp'), 'P18_002',
        lambda p: {'category': CL['PoliceStationCd'].get(str(p['P18_003'])), 'name': p['P18_001'], 'address': p['P18_004']}),
  'P02-06_publicfacilities_2006_NONCOMMERCIAL': (read_shp('P02-06_*_GML/*PublicFacility.shp'), 'P02_001',
        lambda p: {'category_major': CL['PubFacMaclassCd'].get(str(p['P02_002'])), 'category_minor': CL['PubFacMiclassCd'].get(str(p['P02_003'])),
                   'name': p['P02_004'], 'address': p['P02_005']}),
  'P34-14_cityoffices_2014_NONCOMMERCIAL': (read_shp('P34-14_*_GML/*.shp'), 'P34_001',
        lambda p: {'category': P34C.get(str(p['P34_002'])), 'name': p['P34_003'], 'address': p['P34_004']}),
}
summary = []
for name, (feats, codefield, conv) in layers.items():
    out = []
    for f in feats:
        g = shape(f['geometry'])
        code = f['properties'].get(codefield) if codefield else None
        c, how = city_of(g, code)
        if c is None:
            continue
        props = {'city_code': c, 'city': CITY[c], 'assigned_by': how}
        props.update(conv(f['properties']))
        props['raw'] = f['properties']
        out.append({'type': 'Feature', 'properties': props, 'geometry': mapping(g)})
    with open(os.path.join(OUT, name + '.geojson'), 'w', encoding='utf-8') as fo:
        json.dump({'type': 'FeatureCollection', 'name': name, 'features': out}, fo, ensure_ascii=False)
    cnt = collections.Counter((p['properties']['city'], p['properties'].get('category') or p['properties'].get('category_major')) for p in out)
    for (city, cat), n in sorted(cnt.items(), key=lambda x: (x[0][0], str(x[0][1]))):
        summary.append({'layer': name, 'city': city, 'category': cat, 'count': n})
    print(name, 'total', len(feats), '-> subset', len(out), dict(collections.Counter(p['properties']['city'] for p in out)))
with open(os.path.join(OUT, 'summary_counts.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.DictWriter(fo, fieldnames=['layer', 'city', 'category', 'count']); w.writeheader(); w.writerows(summary)

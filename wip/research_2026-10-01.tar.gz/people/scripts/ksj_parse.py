import re, html, sys, json
def parse(fn):
    s = open(fn, 'rb').read().decode('utf-8', 'replace')
    rows = []
    for m in re.finditer(r'<tr>\s*<td class="bgc6"[^>]*>([^<]*)</td>\s*<td class="txtCenter">([^<]*)</td>\s*<td class="txtCenter">([^<]*)</td>\s*<td class="txtCenter">([^<]*)</td>\s*<td class="txtCenter">([^<]*)</td>.*?DownLd\(\'[^\']*\',\'[^\']*\',\'([^\']+)\'', s, re.S):
        rows.append(dict(region=m.group(1).strip(), datum=m.group(2).strip(), year=m.group(3).strip(), size=m.group(4).strip(), file=m.group(5).strip(), path=m.group(6).strip()))
    t = re.sub(r'<script.*?</script>|<style.*?</style>', '', s, flags=re.S)
    t = html.unescape(re.sub(r'<[^>]+>', '\n', t))
    lines = [l.strip() for l in t.split('\n') if l.strip()]
    txt = '\n'.join(lines)
    info = {}
    for key in ['最新のデータは', '更新履歴', 'このデータの使用許諾条件', 'データ作成年度', '内容']:
        i = txt.find(key)
        info[key] = txt[i:i + 400] if i >= 0 else None
    return rows, info, txt
if __name__ == '__main__':
    for fn in sys.argv[1:]:
        rows, info, txt = parse(fn)
        print('=====', fn, 'rows', len(rows))
        for k, v in info.items():
            print('--', k, ':', (v or '').replace('\n', ' ')[:400])
        years = sorted(set(r['year'] for r in rows))
        print('years:', years)
        for r in rows:
            if r['region'] in ('和歌山', '三重', '全国', '和歌山県', '三重県'):
                print('  ', r)

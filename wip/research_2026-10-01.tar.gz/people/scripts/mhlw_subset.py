import csv, io, zipfile, json, glob, os, collections
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
M = os.path.join(BASE, 'mhlw'); OUT = os.path.join(M, 'subset_shingu_kiho'); os.makedirs(OUT, exist_ok=True)
CITY = {('30', '207'): '新宮市', ('24', '562'): '紀宝町'}
CITY6 = {'302074': '新宮市', '245623': '紀宝町'}
feats = []; summary = collections.Counter()
# medical (医療情報ネット 2026-06-01)
for f, kind in [('01-1_hospital_facility_info_20260601.csv.zip', '病院'), ('02-1_clinic_facility_info_20260601.csv.zip', '診療所'), ('03-1_dental_facility_info_20260601.csv.zip', '歯科診療所')]:
    z = zipfile.ZipFile(os.path.join(M, 'raw', f))
    rows = list(csv.DictReader(io.StringIO(z.read(z.namelist()[0]).decode('utf-8-sig'))))
    for r in rows:
        c = CITY.get((r['都道府県コード'], r['市区町村コード']))
        if not c: continue
        try: lat, lon = float(r['所在地座標（緯度）']), float(r['所在地座標（経度）'])
        except: lat = lon = None
        p = {'source': '医療情報ネット オープンデータ 2026-06-01', 'type': kind, 'city': c, 'name': r['正式名称'], 'address': r['所在地'], 'id': r['ID'],
             'beds_total': r.get('合計病床数')}
        feats.append({'type': 'Feature', 'properties': p, 'geometry': {'type': 'Point', 'coordinates': [lon, lat]} if lat else None})
        summary[(c, 'medical', kind)] += 1
# care (介護サービス情報公表システム 2026-06末)
for f in sorted(glob.glob(os.path.join(M, 'raw', 'jigyosho_*.csv'))):
    for r in csv.DictReader(open(f, encoding='utf-8-sig')):
        c = CITY6.get(r['都道府県コード又は市町村コード'])
        if not c: continue
        try: lat, lon = float(r['緯度']), float(r['経度'])
        except: lat = lon = None
        p = {'source': '介護サービス情報公表システム オープンデータ 2026年6月末時点（出力日2026-07-09）', 'type': r['サービスの種類'], 'city': c,
             'name': r['事業所名'], 'address': r['住所'], 'id': r['事業所番号'], 'capacity': r['定員'], 'operator': r['法人の名称']}
        feats.append({'type': 'Feature', 'properties': p, 'geometry': {'type': 'Point', 'coordinates': [lon, lat]} if lat else None})
        summary[(c, 'care', r['サービスの種類'])] += 1
json.dump({'type': 'FeatureCollection', 'name': 'mhlw_medical_care_shingu_kiho', 'features': feats}, open(os.path.join(OUT, 'mhlw_medical_care_shingu_kiho.geojson'), 'w', encoding='utf-8'), ensure_ascii=False)
with open(os.path.join(OUT, 'mhlw_medical_care_shingu_kiho.csv'), 'w', newline='', encoding='utf-8') as fo:
    keys = ['source', 'type', 'city', 'name', 'address', 'id', 'beds_total', 'capacity', 'operator', 'lat', 'lon']
    w = csv.DictWriter(fo, fieldnames=keys); w.writeheader()
    for ft in feats:
        p = dict(ft['properties']); g = ft['geometry']
        p['lon'], p['lat'] = (g['coordinates'] if g else (None, None))
        w.writerow({k: p.get(k) for k in keys})
with open(os.path.join(OUT, 'summary_counts.csv'), 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo); w.writerow(['city', 'group', 'type', 'count'])
    for (c, g, t), n in sorted(summary.items()): w.writerow([c, g, t, n])
for (c, g, t), n in sorted(summary.items()): print(c, g, t, n)
print('features', len(feats), 'without coords', sum(1 for f in feats if not f['geometry']))

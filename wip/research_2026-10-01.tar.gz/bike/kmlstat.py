import sys, re, math, xml.etree.ElementTree as ET
NS={'k':'http://www.opengis.net/kml/2.2'}
def hav(a,b):
    R=6371008.8; la1,lo1=map(math.radians,(a[1],a[0])); la2,lo2=map(math.radians,(b[1],b[0]))
    h=math.sin((la2-la1)/2)**2+math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 2*R*math.asin(math.sqrt(h))
S,W,N,E=33.55,135.70,33.95,136.10
def inb(p): return S<=p[1]<=N and W<=p[0]<=E
for f in sys.argv[1:]:
    root=ET.parse(f).getroot()
    tot=0; totb=0
    print('==',f, 'doc name:', root.find('.//k:Document/k:name',NS).text if root.find('.//k:Document/k:name',NS) is not None else None)
    for pm in root.iter('{http://www.opengis.net/kml/2.2}Placemark'):
        name=pm.find('k:name',NS); name=name.text if name is not None else ''
        desc=pm.find('k:description',NS); desc=(desc.text or '')[:80] if desc is not None else ''
        for ls in pm.iter():
            tag=ls.tag.split('}')[1]
            if tag in ('LineString','Point'):
                c=ls.find('k:coordinates',NS).text.split()
                pts=[tuple(map(float,x.split(',')[:2])) for x in c]
                L=sum(hav(pts[i],pts[i+1]) for i in range(len(pts)-1))
                Lb=sum(hav(pts[i],pts[i+1]) for i in range(len(pts)-1) if inb(pts[i]) and inb(pts[i+1]))
                tot+=L; totb+=Lb
                lats=[p[1] for p in pts]; lons=[p[0] for p in pts]
                print(f'  {tag:10s} {name[:40]:40s} n={len(pts):5d} len={L/1000:8.2f} km  inbbox={Lb/1000:7.2f} km  lat {min(lats):.4f}-{max(lats):.4f} lon {min(lons):.4f}-{max(lons):.4f} {desc}')
    print(f'  TOTAL {tot/1000:.1f} km; inside bbox {totb/1000:.1f} km')

"""Parse WAKAYAMA800 'ルート周辺施設' category pages (https://wakayama800.jp/facilities-page/catidN/) into CSV + GeoJSON."""
import re, html, json, csv, os, time
D = os.path.dirname(os.path.abspath(__file__))
rows = []
for c in [1, 2, 4, 5, 6, 7, 8, 9, 10]:
    s = open(os.path.join(D, '_html', f'w800_cat{c}.html'), encoding='utf-8', errors='replace').read()
    cat = html.unescape(re.search(r'<h2 class="p-main__title ac">(.*?)</h2>', s).group(1)).strip()
    for li in re.findall(r'<li>\s*<a href="javascript:void\(0\);" class="gmap_link">(.*?)</a>\s*</li>', s, flags=re.S):
        g = lambda k: (re.search(rf'<div class="{k}">(.*?)</div>\s*(?=<div class="gmap_|$)', li, flags=re.S) or [None, ''])[1]
        title = html.unescape(re.sub(r'<[^>]+>', '', g('gmap_title'))).strip()
        info_raw = re.search(r'<div class="gmap_info">(.*?)</div>\s*<div class="gmap_coord">', li, flags=re.S)
        info_raw = info_raw.group(1) if info_raw else ''
        svc = re.search(r'<b>提供サービス</b>(.*?)</div>', info_raw, flags=re.S)
        services = [x.strip() for x in html.unescape(re.sub(r'<[^>]+>', '\n', svc.group(1))).replace('●', '\n').splitlines() if x.strip()] if svc else []
        info_txt = re.sub(r'<div style=.*', '', info_raw, flags=re.S)
        lines = [l.strip() for l in html.unescape(re.sub(r'<br\s*/?>', '\n', re.sub(r'<(?!br)[^>]+>', '', info_txt))).splitlines() if l.strip()]
        tel = next((l.split('：', 1)[1].strip() for l in lines if l.startswith('TEL')), '')
        addr = ' '.join(l for l in lines if not l.startswith('TEL'))
        coord = re.search(r'<div class="gmap_coord">\s*([-\d.]+)\s*,\s*([-\d.]+)', li)
        lat, lon = (float(coord.group(1)), float(coord.group(2))) if coord else (None, None)
        rows.append({'category_id': c, 'category': cat, 'name': title, 'address': addr, 'tel': tel,
                     'services': ';'.join(services), 'lat': lat, 'lon': lon})
S, W, N, E = 33.55, 135.70, 33.95, 136.10
for r in rows:
    r['in_bbox'] = bool(r['lat'] and S <= r['lat'] <= N and W <= r['lon'] <= E)
src = 'https://wakayama800.jp/facilities-page/'
with open(os.path.join(D, 'w800_facilities_all.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
fc = {'type': 'FeatureCollection',
      'metadata': {'source': src, 'publisher': '和歌山県 観光振興課・公益社団法人 和歌山県観光連盟 (WAKAYAMA800)',
                   'retrieved_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                   'note': 'Parsed from the gmap_coord/gmap_info elements of each category page; coordinates as published (WGS84 lat,lon for Google Maps).'},
      'features': [{'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [r['lon'], r['lat']]} if r['lat'] else None,
                    'properties': {k: v for k, v in r.items() if k not in ('lat', 'lon')}} for r in rows]}
json.dump(fc, open(os.path.join(D, 'w800_facilities_all.geojson'), 'w'), ensure_ascii=False, indent=0)
from collections import Counter
print(Counter(r['category'] for r in rows))
print('in bbox:', Counter(r['category'] for r in rows if r['in_bbox']))
for r in rows:
    if r['in_bbox']:
        print(f"{r['category']:12s} | {r['name']} | {r['address']} | {r['tel']} | {r['services']} | {r['lat']},{r['lon']}")

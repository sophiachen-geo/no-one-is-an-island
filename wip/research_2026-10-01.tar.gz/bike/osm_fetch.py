"""Overpass queries for cycling research, Kumano three shrines corridor.
bbox (S,W,N,E) = 33.55,135.70,33.95,136.10
Tries overpass-api.de first with backoff, then public mirrors. Logs endpoint + osm_base timestamp."""
import json, sys, time, urllib.request, urllib.parse, os

OUT = os.path.dirname(os.path.abspath(__file__))
UA = {"User-Agent": "no-one-is-an-island research"}
BBOX = "33.55,135.70,33.95,136.10"
ENDPOINTS = (["https://overpass-api.de/api/interpreter"] * 4 + [
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter"]) * 3
MAX_AGE_H = 48  # reject mirror snapshots older than this (kumi/private.coffee served June/July 2026 data on 2026-10-01)

QUERIES = {
    # 1. cycling route relations (any network) touching the bbox, tags only
    "osm_bicycle_route_relations_tags": f"""[out:json][timeout:300];
relation["route"~"^(bicycle|mtb)$"]({BBOX});
out tags;""",
    # 2. cycleways, bicycle=designated, cycleway=* lanes, and bicycle-related ways in bbox
    "osm_cycleways_designated": f"""[out:json][timeout:300];
(
  way["highway"="cycleway"]({BBOX});
  way["bicycle"="designated"]({BBOX});
  way["cycleway"]({BBOX});
  way["cycleway:left"]({BBOX});
  way["cycleway:right"]({BBOX});
  way["cycleway:both"]({BBOX});
);
out geom;""",
    # 3. where bicycles may be banned: motorways, motorroads, bicycle=no, trunk roads, tunnels
    "osm_bike_restrictions": f"""[out:json][timeout:300];
(
  way["highway"~"^(motorway|motorway_link)$"]({BBOX});
  way["motorroad"="yes"]({BBOX});
  way["bicycle"~"^(no|use_sidepath|dismount)$"]({BBOX});
  way["highway"~"^(trunk|trunk_link)$"]({BBOX});
  way["tunnel"]["highway"]["tunnel"!="no"]({BBOX});
  way["access"="no"]["highway"~"^(trunk|primary|secondary)$"]({BBOX});
);
out geom;""",
    # 4. bicycle facilities: parking, rental, repair stations, shops, ferry terminals
    "osm_bike_facilities": f"""[out:json][timeout:300];
(
  nwr["amenity"="bicycle_parking"]({BBOX});
  nwr["amenity"="bicycle_rental"]({BBOX});
  nwr["amenity"="bicycle_repair_station"]({BBOX});
  nwr["shop"="bicycle"]({BBOX});
  nwr["service:bicycle:rental"="yes"]({BBOX});
  nwr["rental"~"bicycle"]({BBOX});
);
out center tags;""",
}


def run(name, q):
    path = os.path.join(OUT, name + ".json")
    if os.path.exists(path) and os.path.getsize(path) > 200:
        print("cached", name, file=sys.stderr)
        return json.load(open(path))
    open(os.path.join(OUT, name + ".overpassql"), "w").write(q)
    for i, ep in enumerate(ENDPOINTS):
        try:
            req = urllib.request.Request(ep, data=urllib.parse.urlencode({"data": q}).encode(), headers=UA)
            raw = urllib.request.urlopen(req, timeout=400).read()
            d = json.loads(raw)
            if "remark" in d and "runtime error" in d.get("remark", ""):
                raise RuntimeError(d["remark"][:200])
            base = d.get("osm3s", {}).get("timestamp_osm_base", "1970-01-01T00:00:00Z")
            age_h = (time.time() - time.mktime(time.strptime(base, "%Y-%m-%dT%H:%M:%SZ")) + time.timezone) / 3600
            if age_h > MAX_AGE_H:
                raise RuntimeError(f"stale snapshot {base} ({age_h:.0f} h old)")
            d.setdefault("_fetch", {})
            d["_fetch"] = {"endpoint": ep, "fetched_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "query_file": name + ".overpassql"}
            json.dump(d, open(path, "w"), ensure_ascii=False)
            print("ok", name, ep, d.get("osm3s", {}).get("timestamp_osm_base"), len(d.get("elements", [])), file=sys.stderr)
            return d
        except Exception as e:
            wait = min(60, 5 * (i + 1))
            print("fail", name, ep, repr(e)[:160], "sleep", wait, file=sys.stderr)
            time.sleep(wait)
    raise SystemExit("all endpoints failed for " + name)


if __name__ == "__main__":
    names = sys.argv[1:] or list(QUERIES)
    for n in names:
        run(n, QUERIES[n])
    # full geometry of each route relation (whole relation, not clipped to bbox) for lengths
    rel = json.load(open(os.path.join(OUT, "osm_bicycle_route_relations_tags.json")))
    ids = [e["id"] for e in rel["elements"] if e["type"] == "relation"]
    if ids:
        q = "[out:json][timeout:600];\nrelation(id:%s);\nout geom;" % ",".join(map(str, ids))
        QUERIES["osm_bicycle_route_relations_geom"] = q
        run("osm_bicycle_route_relations_geom", q)

import json, math, collections
S, W, N, E = 33.55, 135.70, 33.95, 136.10
def hav(a, b):
    R = 6371008.8
    la1, lo1, la2, lo2 = map(math.radians, (a['lat'], a['lon'], b['lat'], b['lon']))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))
def inb(p): return S <= p['lat'] <= N and W <= p['lon'] <= E
def glen(g, clip=False):
    return sum(hav(g[i], g[i + 1]) for i in range(len(g) - 1) if (not clip or (inb(g[i]) and inb(g[i + 1]))))
d = json.load(open('osm_bicycle_route_relations_geom.json'))
print('osm base', d['osm3s']['timestamp_osm_base'])
for r in d['elements']:
    t = r['tags']
    ways = [m for m in r['members'] if m['type'] == 'way' and 'geometry' in m]
    L = sum(glen(m['geometry']) for m in ways)
    Lb = sum(glen(m['geometry'], True) for m in ways)
    roles = collections.Counter(m.get('role', '') for m in r['members'])
    print(f"\nrelation {r['id']}  https://www.openstreetmap.org/relation/{r['id']}")
    for k in sorted(t): print(f"   {k} = {t[k]}")
    print(f"   members: {len(r['members'])} ({len(ways)} ways with geometry); roles {dict(roles)}")
    print(f"   sum of member-way lengths: {L/1000:.1f} km  (inside bbox: {Lb/1000:.1f} km)")
    # bbox of geometry inside bbox
    pts = [p for m in ways for p in m['geometry'] if inb(p)]
    if pts:
        print(f"   in-bbox extent lat {min(p['lat'] for p in pts):.4f}-{max(p['lat'] for p in pts):.4f} lon {min(p['lon'] for p in pts):.4f}-{max(p['lon'] for p in pts):.4f}")
    print('   meta: version', r.get('version'), 'timestamp', r.get('timestamp'))

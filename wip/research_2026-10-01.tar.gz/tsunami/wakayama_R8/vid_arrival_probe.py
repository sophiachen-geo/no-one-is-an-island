"""Feasibility probe (NOT official data): first-wet time per pixel from Wakayama's R8 2D
tsunami animation for Shingu (16_shinguu_nk_2D_k.mp4, 1280x720, 10 fps, 1 frame = 10 s of
simulated time; label at frame n reads n*10 s). Land pixels = not water-coloured at t=0;
'wet' = strong, saturated colour change vs t=0 (water-level colour overlay).
Needs: pip install imageio-ffmpeg pillow numpy. Output is in VIDEO PIXELS (not georeferenced)."""
import glob, subprocess, numpy as np, imageio_ffmpeg
from PIL import Image
FF = imageio_ffmpeg.get_ffmpeg_exe()
subprocess.run([FF, '-hide_banner', '-loglevel', 'error', '-i', 'wakayama_R8/wk_r8_16_shinguu_nk_2D_k.mp4',
                '-vf', "select='lte(n\\,240)'", '-vsync', '0', '/tmp/vf_%04d.png'], check=True)
fr = sorted(glob.glob('/tmp/vf_*.png'))
x0, y0, x1, y1 = 298, 69, 983, 610            # map panel in the 1280x720 frame
f0 = np.asarray(Image.open(fr[0]).convert('RGB'))[y0:y1, x0:x1].astype(int)
water0 = (abs(f0[..., 0]-13) < 40) & (abs(f0[..., 1]-176) < 40) & (abs(f0[..., 2]-240) < 40)
land = ~water0
sat = lambda a: (a.max(-1)-a.min(-1))/(a.max(-1)+1e-6)
first = np.full(land.shape, -1)
for n, f in enumerate(fr):
    a = np.asarray(Image.open(f).convert('RGB'))[y0:y1, x0:x1].astype(int)
    wet = land & (np.sqrt(((a-f0)**2).sum(-1)) > 70) & (sat(a) > 0.55)
    first[wet & (first < 0)] = n
minutes = np.where(first >= 0, first*10/60, np.nan)   # first-wet time in minutes
np.save('vid_first_wet_minutes.npy', minutes)

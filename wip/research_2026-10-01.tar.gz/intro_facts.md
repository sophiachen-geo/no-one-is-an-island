# Shingū (新宮市, Wakayama) — verified facts for the introduction section

Researched 2026-09-30. Every source below was fetched and read on that date; quotes are copied from the fetched text
(whitespace collapsed). Local copies of the downloaded pages, PDFs and tables are in `research/intro/`.

Confidence labels
- **verified**: the number or statement is in the cited primary source, quoted verbatim.
- **derived**: computed here from verified numbers. The arithmetic is shown.
- **secondary**: from an official but non-local source, a news agency, a company or a tourism site, or pieced together from two primary sources.
- **not-found**: I could not verify it. Do not use it on the page.

---

## 0. Read this first: corrections to the brief

1. **The 2025 census has replaced the 2020 census as the latest count.** The Statistics Bureau published the
   final 令和7年国勢調査 人口等基本集計 on **2026-09-29**. Shingū's count is **24,331**. The 2020 figure is kept below
   for comparison.
2. **There is no Settlement and Self-Reliance Zone (定住自立圏) centred on Shingū.** The Ministry of Internal Affairs
   status table (as of 2025-04-01) lists 新宮市 under "中心市要件を満たす市（左記を除く）", which means the city meets
   the requirements but has **not** declared itself a central city. No Wakayama city appears in the "宣言中心市"
   column. Shingū is also absent from the Ministry's list of 12 cross-prefecture zones. I found nothing showing a
   declaration after April 2025. See R1.
3. **Sources disagree on when commercial log rafting ended.** They give c. 1963, March 1964, or "the Shōwa 40s"
   (from 1965). The page should say "the mid-1960s". See E5.
4. **Deaths in Shingū in the 1946 Nankai earthquake could not be confirmed** from a primary source. Wikipedia gives
   58. The figure of 2,398 houses burned is verified. See H3.
5. **Two official pages contain errors or are out of date:**
   - The MLIT 熊野川懇談会 page gives the World Heritage inscription as 平成17年 (2005). The correct year is 2004.
   - An MLIT page still describes the Dorokyō jet-boat as running. The city handbook says the service was suspended
     in April 2020 and **abolished in April 2025**.
6. **I could not open the UNESCO site** (Cloudflare challenge, HTTP 403). The component list comes instead from the
   Agency for Cultural Affairs and the Wakayama Prefecture World Heritage Center.

---

## 1. Top picks for a 150–250-word introduction (ranked)

| # | Fact | Value | id |
|---|------|-------|----|
| 1 | Population, 2025 census (final) | 24,331, down 10.4% from 27,171 in 2020 | D1 |
| 2 | Peak population and decline since | 45,666 in 1960; the 2025 count is 47% lower | D5 |
| 3 | Share of residents aged 65+ | 40.3% in 2025 (38.4% in 2020); median age 58.1 | D3 |
| 4 | Births and deaths in fiscal 2025 | 109 births, 486 deaths | D7 |
| 5 | Regional hub role | Daytime population 109% of residents; 5,011 commute in, 2,571 commute out (2020) | E2 |
| 6 | Largest employers | Health and welfare 20.1%; wholesale and retail 19.3%; primary sector 2.2% (2020) | E1 |
| 7 | Hospital catchment | Serves about 100,000 people in three prefectures | E4 |
| 8 | Port cargo | 1.19 Mt in 2024, of which 81% was wood chips (imported from Vietnam, Chile and Australia) | E6 |
| 9 | End of the timber-rafting era | Rafting stopped in the mid-1960s; the paper and pulp mill closed in 1995 | E5, E7 |
| 10 | World Heritage | Inscribed July 2004; Hayatama Taisha (with 御船島 and 神倉神社) and the Kumano River "river pilgrimage route" are components | C1, C2 |
| 11 | Festivals | 御燈祭り (6 Feb) and 御船祭 (16 Oct); both are part of an Important Intangible Folk Cultural Property designated 2 March 2016 | C3 |
| 12 | Ōishi Seinosuke | Made honorary citizen 24 Jan 2018; the city council cleared the six local defendants of the High Treason case in 2001 | C6 |
| 13 | Kitayama village | Japan's only exclave village (356 people) joined Wakayama in 1871 because of its rafting ties to Shingū | R2 |
| 14 | Kihō town | Faces Shingū across the Kumano River | R3 |

---

## D. Demographics

### D1 — Population and households, 2025 census (final)
- **Claim:** Shingū had 24,331 residents and 12,157 households on 1 October 2025. That is 2,840 fewer people (−10.45%) and
  966 fewer households (−7.36%) than in 2020.
- **Values:** population 24,331 (men 11,329, women 13,002); 2020 population on the same boundaries 27,171; change −2,840
  (−10.45232%); area 255.23 km²; density 95.3 per km²; households 12,157 (general households 12,112).
- **Source:** Statistics Bureau, 令和7年国勢調査 人口等基本集計, 第1-1表 (Excel), published 2026-09-29.
  File: https://www.e-stat.go.jp/stat-search/file-download?statInfId=000040506423&fileKind=0 .
  Listing: https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&lid=000001491012 .
  The release date is confirmed on https://www.stat.go.jp/data/kokusei/2025/kekka.html ("人口等基本集計 … 令和8年 9月29日").
- **Verbatim row:** `2658_新宮市 | 24331 | 11329 | 13002 | 27171 | -2840 | -10.45232 | 87.13275 | 255.23 | 95.3 | 12157 | 12112 | 45 | 13123 | -966 | -7.36112`
- **Confidence:** verified

### D1b — Where people live inside the city (2025 census)
- **Claim:** 96% of residents live in the former Shingū city, which is 31% of the land area. The former Kumanogawa town
  makes up 69% of the area but holds only 906 people (3.7%).
- **Values:**
  - 旧新宮市: 23,425 people, 79.66 km², 294.1 per km²
  - 旧熊野川町: 906 people (1,127 in 2020, −19.6%), 175.47 km², 5.2 per km²
- **Source:** same table as D1 (rows "（旧：新宮市）" and "（旧：熊野川町）").
- **Verbatim rows:** `2659_（旧：新宮市） | 23425 | … | 79.66 | 294.1` and `2660_（旧：熊野川町） | 906 | 448 | 458 | 1127 | -221 | -19.60958 | 97.81659 | 175.47 | 5.2`
- **Confidence:** verified. The shares are derived: 175.47 / 255.23 = 68.7%; 906 / 24,331 = 3.7%.

### D2 — 2020 census (for comparison)
- **Values:** population 27,171 (men 12,610, women 14,561); households 13,123 (general households 13,075); density
  106.5 per km². 2015 population: 29,331 (−7.36%).
- **Source:** Wakayama Prefecture, 令和2年国勢調査 和歌山県版.
  Page: https://www.pref.wakayama.lg.jp/prefg/020300/kokusei/2020/d00207662.html .
  Tables: 第4表 `…/d00207662_d/fil/hyo04.xlsx` and 第10表 `…/hyo10.xlsx`.
- **Verbatim rows:** 第4表 `新宮市 | 27171 | 12610 | 14561 | 106.5 | 29331 | … | -2160 | -7.364…`; 第10表 `新宮市 | 13123 | 13617 | -494 | -3.63 | 2.07 …`
- **Confidence:** verified

### D3 — Share of residents aged 65+ (高齢化率) and median age
- **Claim:** 40.3% of residents were 65 or older in 2025, up from 38.4% in 2020. The median age in 2025 was 58.1.
- **Values, 2025:** 65+ = 9,668 people (40.33%); 75+ = 5,857 (24.43%); 85+ = 2,049 (8.55%); under 15 = 9.99%; mean
  age 54.47; median age 58.09. The census note says 「人口構成比…平均年齢…年齢中位数については、年齢「不詳」の者を除いて算出」
  (percentages and ages exclude people whose age is unknown; 359 people in 2025).
- **Values, 2020:** 65+ = 10,111 (38.42% excluding unknown ages, prefecture 第7表). With the Statistics Bureau's imputed
  values (不詳補完値) the share is 38.33%, the median age 56.8 and the mean age 53.1.
- **Sources:**
  - 2025: 第2-7表, https://www.e-stat.go.jp/stat-search/file-download?statInfId=000040506431&fileKind=0 (2026-09-29).
    Verbatim excerpt of the 新宮市 row: `… 2395 | 11909 | 9668 | 5857 | 2049 | … | 9.99082 | 49.67879 | 40.33039 | … | 24.43267 | 8.54747 | … | 54.47464 | 58.08589`
  - 2020: prefecture 第7表 `…/hyo07.xlsx` (verbatim: `新宮市 | 27171 | 2869 | 13339 | 10111 | 10.90087 | 50.68202 | 38.41711`).
    e-Stat 「都道府県・市区町村別の主な結果」: https://www.e-stat.go.jp/stat-search/file-download?statInfId=000032143614&fileKind=0
- **Confidence:** verified

### D4 — Latest monthly figures (two official series)
- **Resident register (住民基本台帳), city:** 24,932 people and 13,903 households, labelled 「令和8年9月1日現在」 on the city
  homepage. The city's PDF shows these are end-of-August figures (「※人口は月末現在」, row 8月 = 13,903 households,
  24,932 people).
  - Sources: https://www.city.shingu.lg.jp/ (homepage box: 「人口世帯数（令和8年9月1日現在） 総人口 男性 女性 世帯数 24,932人 11,588人 13,344人 13,903世帯」)
    and https://www.city.shingu.lg.jp/div/simin-1/pdf/zinkou/R8-8.pdf (linked from https://www.city.shingu.lg.jp/info/2708, updated 2026-09-25).
  - Confidence: verified
- **Prefecture monthly estimate (毎月推計人口), 1 September 2026:** 23,965 people (men 11,149, women 12,816), 12,028
  households, −445 over the previous 12 months. This series is based on the 2025 census **preliminary** count and will
  be revised to the final count.
  - Source: https://www.pref.wakayama.lg.jp/prefg/020300/suikei/indexR8.html → `indexR8_d/fil/mtR8-y.xlsx`, sheet R8.9.
    Verbatim row: `新   宮   市 | 23965 | 11149 | 12816 | 12028 | -445 | …`
  - Page note, verbatim: 「※令和7年国勢調査（速報値）に基づく数値ですので、令和7年国勢調査（確報値）公表後、補正を予定しています。」
  - Confidence: verified
- **Why the two series differ:** the resident register counts people registered in Shingū (including students living
  elsewhere). The census and the prefecture estimate count usual residents. Use the census figure (D1) as the headline.

### D5 — Peak population and the census series
- **Claim:** On today's boundaries (including Kumanogawa), the population peaked at 45,666 in 1960. It has fallen almost
  continuously since then.
- **Series (current boundaries, census):**

  | Year | Population |
  |------|-----------|
  | 1960 | 45,666 |
  | 1965 | 44,285 |
  | 1970 | 42,073 |
  | 1975 | 41,748 |
  | 1980 | 42,428 |
  | 1985 | 40,465 |
  | 1990 | 38,140 |
  | 1995 | 36,278 |
  | 2000 | 35,176 |
  | 2005 | 33,790 |
  | 2010 | 31,498 |
  | 2015 | 29,331 |
  | 2020 | 27,171 |
  | 2025 | 24,331 |

  Earlier years come only from the chart in the **draft** 人口ビジョン (lower confidence): 1947: 38,931; 1950: 41,116;
  1955: 44,613. The same draft chart gives 44,294 for 1965, which differs from the plan's 44,285.
- **Sources:**
  - 新宮市過疎地域持続的発展計画 (令和3年9月, partly revised 令和6年6月), 表1－1（1）:
    https://www.city.shingu.lg.jp/div/kikaku/pdf/keikaku/kasokeikaku_ichibuhennkou202406.pdf .
    Quote (p.3): 「昭和35 年には45,666 人であった人口は、平成27 年には29,331 人へと55 年間で16,000 人以上、割合では約36％減少している。」
  - 新宮市人口ビジョン (final, March 2016), p.6: https://www.city.shingu.lg.jp/div/kikaku/pdf/chihousousei/bijon1.pdf .
    Quote: 「1960年（S35年）の約45,600人をピークに減少に転じる。」
  - 1990–2020 figures also match prefecture 第5表 (`…/hyo05.xlsx`). 2025 figure from D1.
- **Confidence:** verified for 1960–2025. The pre-1960 values are secondary (draft chart).
- **Derived:** 24,331 / 45,666 = 53.3% of the peak, a fall of 46.7%.

### D6 — Official projections (IPSS, 2023)
- **Claim:** The national population institute projected 19,074 people in 2040 and 15,423 in 2050, which is 56.8% of the
  2020 level. It projected that half the population would be 65+ by 2050 (50.1%).
- **Values:**

  | Year | Projected population | Projected 65+ share |
  |------|---------------------|---------------------|
  | 2025 | 25,150 | 40.5% |
  | 2030 | 23,065 | |
  | 2035 | 21,041 | |
  | 2040 | 19,074 | 47.2% |
  | 2045 | 17,195 | |
  | 2050 | 15,423 | 50.1% |

- **Source:** 国立社会保障・人口問題研究所『日本の地域別将来推計人口（令和5年推計）』, published 2023-12-22.
  Page: https://www.ipss.go.jp/pp-shicyoson/j/shicyoson23/2gaiyo_hyo/gaiyo.asp . Files: 結果表1 `kekkahyo1.xlsx` and 結果表3_3 `kekkahyo3_3.xlsx`.
- **Verbatim row (結果表1):** `30207 | 2 | 和歌山県 | 新宮市 | 27171 | 25150 | 23065 | 21041 | 19074 | 17195 | 15423 | 100 | … | 56.76272`
- **Confidence:** verified
- **Derived:** the actual 2025 count (24,331) is 819 people (3.3%) **below** the 2025 projection. The decline is running
  ahead of the official projection.

### D7 — Births and deaths
- **Claim:** In fiscal 2025 (April 2025 to March 2026), Shingū recorded 109 births and 486 deaths, about 4.5 deaths per
  birth.
- **Sources:**
  - Prefecture 人口調査 2026-04-01, 資料3: https://www.pref.wakayama.lg.jp/prefg/020300/suikei/d00222628.html (`r0804.xlsx`).
    Verbatim: `新宮市 | -377 | 109 | 486 | 4.43 | 19.74` (natural change, births, deaths, births per 1,000, deaths per 1,000).
  - City register PDF R8-8.pdf, 令和7年度 total row: 出生者 109, 死亡 486, 自然増減 ▲377.
- **Confidence:** verified

### D8 — Area and the 2005 merger
- **Claim:** The present city was formed on 1 October 2005 by merging the former Shingū city and Kumanogawa town. Its
  area is 255.23 km², 5.4% of Wakayama Prefecture.
- **Source:** 過疎計画 (as D5), p.1.
  Quotes: 「面積は、255.23ｋ㎡であり、和歌山県全体の5.4％を占める広さである。」 and
  「本市は、平成17 年10 月1 日に、旧新宮市及び旧熊野川町が合併して誕生した市である。」
  The next sentence explains the merger: 「両市町は、これまでも、熊野川を利用した木材流通によって、密接な産業構造の中、人・モノ・情報の強い繋がりがあり…」
- **Also:** 新宮市 市勢要覧資料編 (令和7年), 「市行政区域の変遷」 chart: 「平成17年10月1日合併」.
  https://www.city.shingu.lg.jp/div/hisyo/pdf/kouhou/shiryouhen_r7.pdf (image-only PDF, read visually, p.19).
- **Confidence:** verified

---

## E. Economy

### E1 — Employment by industry (2020 census, imputed values)
- **Claim:** Health and welfare is the largest employer, followed by wholesale and retail. Farming, forestry and fishing
  together employ 2.2%.
- **Values:** 12,788 people in work.

  | Industry | People | Share |
  |----------|--------|-------|
  | P 医療，福祉 (health, welfare) | 2,568 | 20.1% |
  | I 卸売業，小売業 (wholesale, retail) | 2,462 | 19.3% |
  | D 建設業 (construction) | 1,252 | 9.8% |
  | M 宿泊業，飲食サービス業 (hotels, restaurants) | 1,029 | 8.0% |
  | E 製造業 (manufacturing) | 768 | 6.0% |
  | S 公務 (public service) | 752 | 5.9% |
  | O 教育 (education) | 719 | 5.6% |

  By sector: primary 281 (2.20%), secondary 2,027 (15.85%), tertiary 10,480 (81.95%).
- **Source:** e-Stat 「令和２年国勢調査 都道府県・市区町村別の主な結果」, 第２面:
  https://www.e-stat.go.jp/stat-search/file-download?statInfId=000032143614&fileKind=0 .
  The sheet notes that ※ columns use the imputed values: 「※マークの項目については、「参考表：令和２年国勢調査に関する不詳補完結果」の結果数値を掲載している。」
- **Confidence:** verified. Shares are derived from the counts.
- **Context (long run):** from 1960 to 2015 the primary sector fell from 17.7% to 3.0%, the secondary sector from 29.9%
  to 16.2%, and the tertiary sector rose from 52.3% to 79.0%.
  - Source: 過疎計画 p.3. Quote: 「第二次産業についても、昭和35 年の29.9％から平成27 年の16.2％と減少しており、木材関連産業の低迷や大手製紙工場の撤退の影響が出ている。」
  - Confidence: verified

### E2 — Regional hub: net commuter inflow (2020 census)
- **Claim:** Shingū's daytime population (29,611) is 109% of its resident population. 5,011 people commute in and 2,571
  commute out.
- **Values:** 昼間人口 29,611; 昼夜間人口比率 108.98; 流入人口 5,011; 流出人口 2,571.
- **Source:** same e-Stat file as E1, 第２面, 新宮市 row. Verbatim: `… 29611 | 108.98016 | 2571 | 5011`
- **Confidence:** verified. Check: 27,171 − 2,571 + 5,011 = 29,611.
- **Not found:** which municipalities the commuters come from. The origin–destination table (e.g. how many workers from
  Kihō) was not retrieved; see §X.

### E3 — What the city says its economy rests on
- **Claim:** The city describes itself as having moved from timber, paper and sawmilling to a service economy centred
  on its role as the regional hub.
- **Sources and quotes:**
  - City profile, https://www.city.shingu.lg.jp/Info/10 (updated 2022-03-01):
    「明治以降は熊野材の生産地、製紙業や製材業で繁栄した歴史を持ち、今日まで熊野地方の行政、経済、文化、教育の中心都市として発展してきました。」
  - 過疎計画 p.1: 「本地域は、中世においては、全国各地からの熊野三山詣で賑わい、以降は、本地域の基幹産業である木材産業を中心に発展してきたが、外国産木材の輸入自由化など経済の国際化に伴って、次第に衰退している。」
  - 過疎計画 p.3: 「本市が圏域の中心都市であることから、卸小売業及びサービス業就業者の占める割合が高くなっている。」
  - On tourism, 過疎計画: 「本市は通過型の観光地であり、観光関連産業への経済波及効果は十分とは言えない状況である。」 (Shingū is a place visitors pass through.)
- **Tourism volume:** 1,210,085 visitors in 2024 (160,935 overnight, 1,049,150 day visitors); 1,078,518 in 2023.
  - Source: 市勢要覧資料編 令和7年, p.5 table 「観光客数」 (image PDF, read visually), URL as in D8.
- **Confidence:** verified

### E4 — The regional hospital (新宮市立医療センター)
- **Claim:** The city hospital serves about 100,000 people across three prefectures: Shingū, Higashimuro district,
  Hongū (Tanabe), Totsukawa village (Nara), and Kumano city and Minamimuro district (Mie). It has 285 beds.
- **Sources and quotes:**
  - Hospital, director's message: https://hsp.shingu.wakayama.jp/about/
    「当センターは新宮市・東牟婁郡の新宮保健医療圏に加え、田辺市本宮町・奈良県十津川村・三重県熊野市及び南牟婁郡からの広範な地域の人口約10万人の医療対象者を受け持ち、急性期病床を中心としつつ地域包括ケア病棟を含む285床を擁しています。残念ながら現在は看護師不足のため一部病棟を閉鎖しています。」
  - Hospital history (same site): 「平成13年5月 新宮市蜂伏に移転新築。…名称を「新宮市立医療センター」に改称して開院。」 and 「平成9年5月 災害拠点病院の指定を受ける」
  - City 過疎計画 p.31 (a slightly wider list that adds Owase):
    「※広域住民：新宮市のほか和歌山県南部（東牟婁郡、田辺市本宮町）、三重県南部（南牟婁郡、熊野市、尾鷲市）、奈良県南部（十津川村）を含む地域の住民」
- **Workload, FY2024:** 59,525 inpatient days and 120,196 outpatient visits.
  Source: 市勢要覧資料編 令和7年, p.10 「市立医療センター入院・外来患者数」 (image PDF).
- **Confidence:** verified
- **Derived check of "about 100,000":** adding up the hospital's own list of areas gives 101,816 people in the 2020
  census and **90,631 in 2025**. Areas counted: 新宮市, 那智勝浦町, 太地町, 古座川町, 北山村, 串本町, 旧本宮町,
  十津川村, 熊野市, 御浜町, 紀宝町 (2025 census 第1-1表).

### E5 — Timber rafting to Shingū and when it ended
- **Claim:** For centuries, logs were rafted down the Kitayama and Kumano rivers to Shingū. Commercial rafting stopped in
  the mid-1960s, after dam and road building.
- **Sources, which disagree on the exact date:**
  - **Wakayama Prefecture 道路政策課** tourism page on Kitayama, https://www.pref.wakayama.lg.jp/prefg/081300/d00216803.html :
    「伐採した木材を、新宮へ運ぶ手段として始まった筏流しは、600年もの歴史を持ちます。…昭和40年代にはいり、木材の運搬も水路から陸路に切り替わったため筏師もすっかり姿を消してしまいましたが、昭和54年8月、筏流しが観光筏下りとして復活しました。」 (verified; says "the Shōwa 40s", i.e. from 1965)
  - **わかやま歴史物語 062** (Wakayama history-tourism site; publisher not confirmed from the page), http://wakayama-rekishi100.jp/story/062.html :
    「約600年続いた筏流しも、昭和38年（1963）頃にダムの建設や道路整備により途絶えましたが、その伝統や技術は昭和54年（1979）に復活した「北山川観光筏下り」へと引き継がれました。」 (secondary)
  - **新宮原木市場** (local timber market), http://shingugenboku.ec-net.jp/ikadanagashi.html :
    「この名物筏流送も、ダム開発、国道168号線の開通等、時代の変遷により、昭和39年3月にその使命を終える。」
    The same page: 「明治に完成した貯木場の面積は、2万坪といわれた。昭和42年に埋め立てられて、陸上貯木場…となる。」 (secondary)
  - **MLIT 紀南河川国道事務所**, https://www.kkr.mlit.go.jp/kinan/river/kumano_kondan/kumanogawa.html :
    「かつての熊野川流域では、切り出された木材は筏に組まれ、また山地で焼かれた木炭などは、三反帆と呼ばれる団平船に積まれ、河口に位置する新宮まで運ばれました。…これらの舟運は、昭和30年代以降のダムの建設に伴う道路の整備により次第に衰退し…」
    Note: this page wrongly gives the World Heritage year as 平成17年.
- **Recommended wording:** "ended in the mid-1960s". **Confidence:** secondary for any single year. Revived as
  tourist rafting at Kitayama in August 1979 (verified, prefecture page).

### E6 — Shingū Port: cargo in 2024
- **Claim:** In 2024 Shingū Port handled 1.19 million tonnes of cargo. 81% of it was wood chips: imported from Vietnam,
  Chile and Australia and shipped on by sea to paper mills at Mishima-Kawanoe (Ehime) and Udono (Kihō, Mie).
- **Values, calendar year 2024:**
  - Total 1,193,377 t: exports 0; imports 381,611 t; domestic outbound 652,619 t; domestic inbound 159,147 t.
  - **Imports:** wood chips 360,413 t (Vietnam 145,626; Chile 121,364; Australia 93,423); logs 21,198 t (Canada
    14,964; USA 6,234).
  - **Domestic outbound:** wood chips 544,368 t (to 三島川之江 321,361; to 鵜殿 222,257; to Osaka 750); sand and gravel
    100,040 t (74,574 to Osaka); metal ore 8,211 t.
  - **Domestic inbound:** cement 83,193 t; wood chips 61,020 t; logs 7,539 t; paper and pulp 5,758 t; sand 1,637 t.
  - Wood chips in total: 965,801 t = **80.9%**.
- **Source:** MLIT 港湾統計（年報）令和6年, database format, https://www.mlit.go.jp/k-toukei/R6kowan-datebase.html .
  Files: 第3表(1) トン数総数表 `https://www.mlit.go.jp/k-toukei/content/001974129.xlsx`; (5) 輸入 `001974134.xlsx`;
  (6) 移出 `001974135.xlsx`; (7) 移入 `001974136.xlsx`.
- **Verbatim row, table (1):** `和歌山県 | 30 | 地方港湾 | 新宮 | 30015 | 一般 | 1 | 1193377 | (輸出なし) | 381611 | 652619 | 159147`
- **Confidence:** verified. The commodity totals add up exactly to 1,193,377.
- **Caveat:** the city's own figures for fiscal 2024 are different (inbound ships 573; 移出 314,964 t; 輸入 365,401 t;
  移入 158,611 t; source 市勢要覧資料編 p.5, "新宮港利用状況より"). They use a different period and possibly a different
  scope. Use the MLIT figures for tonnage.
- **Port status (prefecture):** https://www.pref.wakayama.lg.jp/prefg/080500/kowan/40shingu.html
  「輸入木材を取り扱うため、昭和40年代に第1期工事を行いました…紀南地方唯一の外貿港湾である新宮港は、新宮地域のみならず三重県や奈良県をも含めた地域の拠点港として重要な役割を担っています。」
  Also: 「地方港湾指定 昭和45年3月12日 特定地域振興重要港湾選定 平成12年5月23日」. Confidence: verified.

### E7 — The paper and pulp mill that closed
- **Claim:** Tomoegawa Paper's Shingū mill made kraft pulp from 1945 and paper from 1958, and **closed in 1995**.
- **Source:** 巴川コーポレーション 沿革, https://www.tomoegawa.co.jp/corporation/history/
  Quotes: 「1945年（昭和20年） 新宮木材パルプ株式会社を吸収合併し新宮工場と改称、クラフトパルプの自社生産を開始」,
  「1958年（昭和33年） 新宮工場内に抄紙工場を設置」, 「1995年（平成7年） 新宮工場を閉鎖、パルプ事業から撤退」
- **Link to the city's account:** the city's 過疎計画 (p.13) blames 「大手製紙工場の撤退や、木材関連産業の低迷など」 for
  secondary-sector jobs falling from 3,582 (1995) to 2,018 (2015), about −44%. **The city does not name the company**, so
  treat the link to Tomoegawa as an inference.
- **Confidence:** verified for the mill dates; secondary (inference) for the link.

---

## C. What makes Shingū distinctive

### C1 — World Heritage inscription (2004; boundary modification 2016)
- **Claim:** 「紀伊山地の霊場と参詣道」 (Sacred Sites and Pilgrimage Routes in the Kii Mountain Range) was inscribed in
  July 2004, under criteria (ii)(iii)(iv)(vi). A minor boundary modification was approved in October 2016.
- **Sources:**
  - Agency for Cultural Affairs, 文化遺産オンライン: https://online.bunka.go.jp/special_content/hlinkA
    Quote: 「記載年月 平成16年(2004年)7月 資産範囲の軽微な変更承認年月 平成28年(2016年)10月 評価基準 (ⅱ)(ⅲ)(ⅳ)(ⅵ)」. Shingū is listed among the municipalities.
  - Wakayama World Heritage Center (prefectural body), https://www.sekaiisan-wakayama.jp/know/outline/henkou2016.html
    Quotes: 「平成16年7月7日 世界遺産「紀伊山地の霊場と参詣道」 世界遺産一覧表に記載」 and 「平成28年10月24日 第40回ユネスコ世界遺産委員会の臨時会合…において追加登録が決定」.
    The 2016 additions include 「阿須賀王子跡」 (in Shingū).
  - UNESCO page https://whc.unesco.org/en/list/1142 could not be opened (HTTP 403, Cloudflare).
- **Confidence:** verified through the Agency and the prefecture; the UNESCO page itself was not read.

### C2 — The inscribed components in Shingū
- **Kumano Hayatama Taisha** is one of the three Kumano shrines (Kumano Sanzan). The Agency's description says the
  component includes the precinct, the mountain behind it with 神倉神社, and the festival sites 御船島 and 御旅所.
  - Agency component page, https://online.bunka.go.jp/special_content/component/75 :
    「1951年再建の社殿が建ち並ぶ現在の熊野速玉大社の境内を中心とし、背後の山と、熊野川を約1㎞遡った所にある祭礼の場、「御船島」・「御旅所」を含む。…背後の「権現山」は…その中腹に、祭神が降臨した所とされる「神倉神社」があり、神体として信仰される巨岩（ゴトビキ岩）の周辺からは、3世紀の銅鐸をはじめ、12世紀を中心とする経塚が多数発見されている。」
  - Prefecture page, https://www.pref.wakayama.lg.jp/prefg/081300/d00214829.html :
    「熊野速玉大社は、熊野川の河口近くに鎮座する熊野三山のひとつで、境内は世界遺産の登録地です。」
    The same page gives one theory for the city's name: 「元宮である神倉山から現在の場所に遷されたことより、神倉神社の「旧宮」に対して「新宮」と号したという説もあります。」
- **The Kumano River** is inscribed as the "river pilgrimage route" linking Hongū and Hayatama.
  - Wakayama World Heritage Center inventory, https://www.sekaiisan-wakayama.jp/know/outline/registered.html :
    「熊野川 | 遺跡・景観 | 有史以前 | 熊野本宮大社と熊野速玉大社を結ぶ「川の参詣道」」.
    The same inventory lists 「熊野速玉大社 | 遺跡・景観 | 有史以前 | 巨石崇拝に起源し、熊野三山を構成する三神社の一つ」 and 「熊野速玉神社のナギ | 天然記念物 | 樹齢800年」.
  - The river is also part of the national historic site 熊野参詣道 (「（熊野川）新宮川水系熊野川」, designated 2000-11-02 with later additions):
    https://online.bunka.go.jp/heritages/detail/162968
- **The city's own list** (https://www.city.shingu.lg.jp/Info/10):
  「平成１６年７月７日世界遺産登録された「紀伊山地の霊場と参詣道」の熊野古道「大雲取越」「小雲取越」「高野坂」や川の参詣道「熊野川」」
- **Confidence:** verified

### C3 — Festivals: 御燈祭り (6 Feb) and 御船祭 (16 Oct)
- **Claim:** 「新宮の速玉祭・御燈祭り」 was designated a national Important Intangible Folk Cultural Property on 2 March
  2016. 御燈祭り is held on 6 February at 神倉神社. 御船祭 is held on 16 October, the second day of the shrine's main
  festival (15–16 Oct).
- **Sources:**
  - Agency database, https://online.bunka.go.jp/heritages/detail/286380 :
    「指定年月日:20160302 保護団体名:熊野速玉大社祭事保存会 … 重要無形民俗文化財」. Its description: 「速玉祭は，初日に神馬の渡御があり…翌日には神輿渡御と御船祭りがある。…神霊は神輿から船に遷され川を遡上し，御船島へと向かう。御船島では小船による早舟競争が行われ…」 and 「御燈祭りは，神倉山の山上に上がり子と称する参拝者が群れ集うなか，御神火が起こされ…上がり子たちは一気に山を駆け下りていく。」
  - Shrine calendar, https://kumanohayatama.jp/?page_id=8 :
    「2月6日 夕刻〜 御燈祭り（神倉神社 例大祭／国指定重要無形民俗文化財）」 and 「10月16日 午後2時 神輿渡御式 午後4時30分 御船祭」
  - City pages https://www.city.shingu.lg.jp/info/35 and https://www.city.shingu.lg.jp/info/36 :
    「毎年、２月６日 夜に行われる神倉神社の例祭…平成２８年３月国の重要無形民俗文化財に指定。」 and
    「御船祭 熊野速玉大社の例大祭。…紀南地方随一の船祭として名高い。平成２８年３月、国の重要無形民俗文化財に指定。(10月15,16日)」
- **Confidence:** verified
- **Note:** the Agency's World Heritage page still describes 熊野御燈祭 as a prefectural designation. That text dates
  from before 2016; the national designation above replaces it.

### C4 — 浮島の森 (Ukishima floating-island forest)
- **Claim:** The floating peat island near Shingū Station is a national Natural Monument, designated 8 April 1927.
- **Source:** Agency database, https://online.bunka.go.jp/heritages/detail/202366 :
  「新宮藺沢浮島植物群落 … 天然記念物 … 新宮市新宮・浮島 指定年月日:19270408 管理団体名:新宮市」.
  Its description: 「藺澤浮島ハ新宮駅ノ附近ニアリ、元此地方一帶ニ存在セル池沼中ノ泥炭地ノ僅ニ遺存セルモノナリ」
  (a small surviving piece of the peat marsh that once covered the area).
- **Visitors in 2024:** 6,289 (市勢要覧資料編 p.5).
- **Confidence:** verified

### C5 — The Xu Fu (徐福) legend
- **Claim:** Local tradition holds that Xu Fu, sent by the First Emperor of Qin to find an elixir of immortality, landed
  in Kumano and settled in Shingū. His tomb stone dates from 1736 and Jofuku Park opened in August 1994.
- **Source:** City page, https://www.city.shingu.lg.jp/info/565 :
  「徐福は今から２，２００年ほど前、中国を統一した秦の始皇帝に仕え、その命により、東方海上の三神山にあるという不老不死の霊薬を求めて３，０００人の童男童女を引き連れ、この熊野に渡来したと伝えられています。」
  Also: 「新宮駅から東にわずか100ｍのところに「徐福の墓」があり」, 「墓碑は紀州藩祖徳川頼宣が儒臣の李梅溪に書かせたものです。 元文元年（1736）建立」, 「平成6年8月…「徐福公園」としてオープン」
- **Confidence:** verified that this is the city's account. It is a legend and should be presented as tradition.

### C6 — Writers, thinkers and the High Treason Incident
- **Honorary citizens:** the city has named 11 honorary citizens, among them:
  - 佐藤春夫 (1892–1964): 「明治２５年、新宮市に生まれる。『田園の憂鬱』、『殉情詩集』で文壇での地位を確立する。芸術院会員、文化勲章を受章。」
  - 西村伊作 (1884–1963): 「大正１０年、東京駿河台に「文化学院」を創設。芸術家・建築家としても活躍」
  - 中上健次 (1946–1992): 「芥川賞受賞の『岬』をはじめ、生まれ故郷の熊野を題材にした重厚な文学作品を多数著す。」
  - 大石誠之助 (1867–1911): 「渡米して医療を学び、新宮市に医院を開業。人権思想や平和思想の基礎を築き、甥の西村伊作等に対して大きな影響を与えた。」
  - Source: https://www.city.shingu.lg.jp/Info/46 (updated 2018-01-30), 「これまでに、以下の１１人の方々が顕彰されています。」 Confidence: verified.
- **Ōishi's honorary citizenship, 24 January 2018:**
  - Kyodo via 四国新聞 (2018-01-24), https://www.shikoku-np.co.jp/national/life_topic/20180124000782 :
    「和歌山県新宮市は、市出身で明治末期の大逆事件で処刑された医師大石誠之助（1867～1911年）を名誉市民にすることを決め、24日、遺族代表に表彰状を贈った。…大石は事件に連座して43歳で処刑。市は事件を「戦後の研究では明らかに冤罪とされる」と指摘している。」
  - Confidence: verified. The date comes from the news agency; the city page lists him and was updated that week.
- **The High Treason Incident and the "Shingū group":**
  - Wakayama Prefecture, https://www.pref.wakayama.lg.jp/prefg/081300/d00214686.html :
    「明治44年（1911年）年1月の判決で有罪になった24人の中に新宮グループ6人がいました。大石誠之助、成石平四郎が死刑、高木顕明、成石勘三郎、崎久保誓一、峯尾節堂が無期懲役になりました。新宮市議会は90年後の2001年9月「6人は冤罪であっただけでなく、平等・非戦を唱えた先覚者」として名誉回復を宣言し、2003年、西村記念館の庭に碑が完成しました。」
  - Confidence: verified

---

## H. Short history (not already on the page)

### H1 — The Mizuno clan, 1619 to the end of the Edo period
- **Claim:** From 1619, Shingū was held by the Mizuno, senior retainers (附家老) of the Kishū Tokugawa. They held 35,000
  koku, were treated like daimyō, and ruled for ten generations until the end of the Edo period.
- **Sources:**
  - Agency record for 史跡「新宮城跡附水野家墓所」 (designated 2003-08-27), https://online.bunka.go.jp/heritages/detail/192602 :
    「元和５年（１６１９）…新宮には頼宣の付家老として水野重仲が入った。重仲は、徳川家康の母方の従兄弟で、頼宣の後見役として３万５千石を領した。水野氏は、尾張・水戸の付家老と同様、待遇は大名に準じ、将軍に拝謁をすることができた。以後、水野氏は、幕末まで１０代にわたり新宮領主として当地を支配した。」
  - City page https://www.city.shingu.lg.jp/Info/229 : 「明治４年（1871）の廃藩置県とともに城としての役目を終え、城内にあったすべての建物が取り壊されました。」
    The Agency record dates the removal of the buildings to 明治８年 (1875).
- **Confidence:** verified
- **Not verified:** the date Shingū became an independent domain in 1868. The sources above do not state it.

### H2 — Becoming a city (1933) and later mergers
- **Claim:** 新宮町 and 三輪崎町 merged to form 新宮市 in 1933. 高田村 joined in 1956. Five villages merged into
  熊野川町 in 1956. The two merged on 1 October 2005.
- **Sources:**
  - City handbook 市勢要覧資料編 令和7年, p.19 「市行政区域の変遷」 (read visually): 「新宮町（明治22年施行）」＋「三輪崎町」→「昭和8年合併 新宮市」; 「高田村」→「昭和31年編入」; 小口村・三津ノ村・九重村・玉置口村・敷屋村→「昭和31年合併 熊野川町」; 「平成17年10月1日合併 新宮市」.
  - Exact day in 1933: NII 歴史的行政区域データセットβ版, https://geoshape.ex.nii.ac.jp/city/resource/30207A1968.html :
    「和歌山県新宮市 … 有効期間 1933-10-01 〜」.
- **Confidence:** verified for the year; **secondary** for 1 October 1933 (research dataset rather than a city document).

### H3 — The 1946 Shōwa Nankai earthquake and the Shingū fire
- **Claim:** The quake of 21 December 1946 started a fire that burned 2,398 houses in Shingū, roughly a third of the town.
- **Sources:**
  - Japan Coast Guard 5th District, 水路要報『昭和21年南海大地震調査報告』 (1948; Wakayama summary 2011), p.1, 新宮:
    https://www1.kaiho.mlit.go.jp/KAN5/siryouko/suiro-youhou/sum_wakayama.pdf
    「総戸数7,000 戸中全壊6,000戸、半壊1,000戸でしかもこれらの中には焼失家屋2,398 戸も含まれ…全壊区域は約7万坪、半壊区域は約13万坪に達するといわれる。」
    The same table also says 「2,398焼失、600戸全壊、1,000戸半壊」, so the source is internally inconsistent on
    6,000 versus 600 houses collapsed. Only the 2,398 burned figure is safe to use. (verified)
  - Wakayama Prefecture 障害福祉課 earthquake page, https://www.pref.wakayama.lg.jp/prefg/040400/bosai/jisinnsonae.html :
    「この地震では、火災が発生して新宮市で市街地の3分の1が焼失したり…地震の揺れによる被害よりも、津波及び地震に伴う火災による被害の方がはるかに大きかったのです。」 (verified)
  - JMA Wakayama, https://www.jma-net.go.jp/wakayama/bousai/phenomenon/zishinsaigai.html , Wakayama totals (from 日本被害地震総覧):
    「死者195、負傷者562、不明者74、家屋全壊969、家屋半壊2,442、家屋流失325、家屋焼失2,399、家屋浸水14,102」.
    Derived: 2,398 of the prefecture's 2,399 burned houses were in Shingū. This combines two sources, so treat it as secondary.
  - Gifu Prefecture 防災課 (2021-03-31), https://www.pref.gifu.lg.jp/page/5982.html :
    「新宮市の火事は、激震直後に出火し、約17時間にわたって燃え続け、全戸数の34％にあたる2398戸を焼失させ、市内の繁華街はほとんど全滅した。その被災者は8300人にのぼった。」 (secondary: official, but not local)
- **Not found:** deaths in Shingū (Wikipedia says 58; no primary source found) and the burned area in hectares.

### H4 — The 1944 Tōnankai earthquake (optional)
- **Claim:** The tsunami reached 2.0 m at Shingū.
- **Source:** JMA Wakayama (same page as H3): 「1944年 （昭和19） 12月7日 昭和東南海地震 7.9 4 新宮 2.0m …」 (from 日本被害津波総覧).
- **Confidence:** verified

---

## R. Shingū in its region

### R1 — Settlement and Self-Reliance Zone (定住自立圏): does not exist
- **Finding:** Shingū meets the central-city requirements but, as of 1 April 2025, had not declared itself a central
  city. No 定住自立圏 is centred on Shingū, and no Wakayama city has formed one. Shingū is not among the 12
  cross-prefecture zones.
- **Source:** Ministry of Internal Affairs, 「定住自立圏構想について（令和7年4月1日）」 p.5, table 「定住自立圏構想の取組状況（令和７年４月１日現在）」:
  https://www.soumu.go.jp/main_content/000758777.pdf .
  In the Wakayama row the "宣言中心市" column is empty. 「和歌山市、田辺市、新宮市」 appears in the next column,
  「中心市要件を満たす市（左記を除く）」; I checked this from the text coordinates in the PDF.
  The cross-prefecture list, verbatim: 「県境型圏域：12圏域（十和田市・三沢市、大田原市、上田市、鳥取市、松江市・米子市、備前市、大牟田市、中津市、都城市、北杜市、小山市、伊賀市を中心市とする圏域）」.
  On the p.4 map, Wakayama has no zone marker.
- **Confidence:** verified as absent (as of 2025-04-01). No later declaration found.
- **Use instead:** the hospital catchment (E4), about 91,000–102,000 people across three prefectures, and the
  inter-municipal body 新宮周辺広域市町村圏事務組合. I did not verify that body's members from a primary source.

### R2 — Kitayama village (北山村), Japan's only exclave village
- **Claim:** Kitayama belongs to Wakayama but borders only Mie and Nara. The village's own account says it joined
  Wakayama in 1871 because its raftsmen depended on the Shingū timber trade. Population: 356 (2025 census).
- **Sources:**
  - Village tourism site, https://www.vill.kitayama.wakayama.jp/kanko/about/ :
    「日本で唯一の「飛び地」の村。…村に隣接する町や村はすべて三重県、奈良県。」 and
    「伐採された木材の輸送は川を利用して筏によって木材集積地の新宮まで運ばれていました。当時、北山村は人口の大半を筏師が占め、新宮木材業者と筏師は共存共栄、切っても切れない関係で成り立っていたのです。明治4年、廃藩置県が実施され、新宮が和歌山県に編入された際、地理的に言えば北山は奈良県に属するところを「新宮が和歌山県に入ったのならぜひ私たちも」との村民の意見を聞き入れ、和歌山県に編入。」
  - Population: 2025 census 第1-1表 (as D1): 北山村 356 (2020: 404; −11.9%); 48.2 km².
- **Confidence:** verified that this is the village's account; the 1871 decision is a local tradition. Population verified.

### R3 — Kihō town (紀宝町, Mie), across the river
- **Claim:** Kihō, the southernmost town in Mie, faces Shingū across the Kumano River. It had 9,640 residents in 2025.
- **Sources:**
  - Kihō's town-run migration site (紀宝町役場 企画調整課), https://kiho-town.com/summary/ :
    「紀宝町は、紀伊半島の南東部に位置し、三重県の南玄関となっています。東は七里御浜で熊野灘に面し、北は御浜町、西を熊野市、南は熊野川を隔てて和歌山県新宮市と接しています。」
  - Town pamphlet: https://www.town.kiho.lg.jp/wp-content/uploads/2021/06/HP_kiho_iju_pamphlet_Part2.pdf
    「南東部には住宅街や商業地をはじめ、港湾を活用した製紙工場や製材工場などが立地しています。」 The pamphlet uses Shingū's weather data for its own climate chart (「紀宝町（新宮市）」).
  - Shingū's side: 過疎計画 p.1: 「本市の東側は、三重県熊野市、紀宝町と、北側は、奈良県十津川村と、西側は和歌山県田辺市、那智勝浦町、古座川町とそれぞれ接しており」
  - Population: 2025 census 第1-1表: 紀宝町 9,640 (2020: 10,321).
- **Confidence:** verified

### R4 — Rail travel to Ōsaka and Nagoya
- **Claim:** The limited express takes about 3 h 20 min to Nagoya (JR Central "Nanki") and about 4 h to Shin-Ōsaka
  (JR West "Kuroshio"). Shingū is where the JR Central and JR West lines meet.
- **Sources:**
  - City, https://www.city.shingu.lg.jp/Info/10 :
    「新宮市は、JR東海とJR西日本の分岐点に位置し、名古屋へは特急で3時間20分位、新大阪へは4時間でアクセスしています。」
    Also https://www.city.shingu.lg.jp/Info/16 (新大阪から「約4時間」, 名古屋から「約3時間20分」). Confidence: verified (city figure, rounded).
  - JR tourist-pass timetable PDF (Ise-Kumano-Wakayama area, dated April 2023), https://touristpass.jp/assets/pdf/route_timetable/tt_ise02.pdf :
    - Shingū → Shin-Ōsaka by Kuroshio: 6:29→10:51, 8:32→12:51, 11:27→15:51, 13:29→17:51, 15:04→19:21, 17:46→22:08,
      i.e. **4 h 17 min to 4 h 24 min**.
    - Shingū → Nagoya by Nanki: 6:20→9:42, 9:13→12:41, 12:45→16:10, 17:29→20:49, i.e. **3 h 20 min to 3 h 28 min**.
    - Confidence: secondary (the 2023 timetable may have changed). JR Central's own pages returned 403.
- **Recommended wording:** "about 3½ hours to Nagoya and about 4¼ hours to Shin-Ōsaka".

### R5 — The Kinan (紀南) region
- **Claim:** Shingū is the port and service centre of Kinan, the southern Kii Peninsula. The Kumano basin spans three
  prefectures.
- **Sources:**
  - Prefecture port page (E6): 「紀南地方唯一の外貿港湾である新宮港」.
  - MLIT 近畿地方整備局 新宮川水系, https://www.kkr.mlit.go.jp/river/kasen/shinguugawa.html :
    「熊野川流域は、奈良県、和歌山県、三重県の３県にまたがり、５市３町６村からなり…「紀伊山地の霊場と参詣道」が世界遺産に登録されているなど紀南地方の社会、経済、文化の基盤をなしています。」
    Same page: 「幹川流路延183km、流域面積2,360 km2の一級河川」.
- **Confidence:** verified

---

## X. Not verified or not found (do not use on the page)
- **Settlement and Self-Reliance Zone centred on Shingū:** does not exist (R1).
- **Deaths in Shingū in the 1946 quake, and the burned area in hectares:** no primary source found (H3).
- **An exact year for the end of commercial rafting:** sources give 1963, March 1964 and "the Shōwa 40s" (E5). Say "mid-1960s".
- **Where Shingū's commuters come from** (e.g. how many come from Kihō): not retrieved. It needs the 2020 census
  従業地・通学地 origin–destination table on e-Stat
  (https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&lid=000001296018, per-prefecture files).
- **The date Shingū became an independent domain in 1868:** not stated in the sources read (H1).
- **Wikipedia details** (Shingū as Wakayama's second city; Kihō as Shingū's "bed town"): not verified; left out.
- **UNESCO's own component list and ID numbers:** whc.unesco.org returned 403. The Japanese sources in C1 and C2 cover
  the same ground.

## Y. Other useful numbers (verified, lower priority)
- **Climate, 2020:** mean temperature 18.3 °C; annual rainfall 3,633 mm. 過疎計画 p.1: 「令和2 年の気象観測では、年平均気温18.3℃、年間降水量3,633mm となっている。」
- **Kumano River:** 183 km long, basin 2,360 km², 95% of the basin forested (MLIT, R5).
- **Dorokyō jet-boat:** suspended April 2020, abolished April 2025. 市勢要覧資料編 p.5: 「※令和2年4月から瀞峡ウォータージェット船休止→令和7年4月廃止」.
- **Shingū Station:** 841 boardings per day in FY2024 (市勢要覧資料編 p.5).
- **Honorary-citizen list:** also includes 東くめ, lyricist of 「鳩ぽっぽ」 and 「お正月」 (Info/46).

## Z. Freely licensed charts and maps (links only; nothing downloaded for reuse)
- **Wakayama Prefecture 「グラフでみる和歌山県～市町村編～」, 新宮市:** population pyramid compared with 30 years earlier (2022).
  https://www.pref.wakayama.lg.jp/prefg/020300/datawakayama_shichoson/index_d/fil/shinguushi.pdf
  Reuse terms (https://www.pref.wakayama.lg.jp/prefg/000200/opendata/hpopendatakiyaku.html): free reuse including
  commercial, with attribution; 「数値データ、簡単な表・グラフ等は著作権の対象ではありません」.
- **Statistics Bureau 日本統計地図** (municipal maps from the 2025 census): https://www.stat.go.jp/data/chiri/map/index_2.html
  (Government Standard Terms of Use 2.0, compatible with CC BY 4.0).
- **Agency for Cultural Affairs component location maps** (scanned PDF, 27 MB): https://online.bunka.go.jp/docs/special_content/kiisanchi_location.pdf
  Reuse terms not checked.
- **e-Stat tables** (D1, D3, E1) and **MLIT port statistics** (E6) are under the Government Standard Terms of Use
  (compatible with CC BY 4.0). Good sources for the page's own charts: the census series in D5, the IPSS projection in D6
  and the port commodity split in E6.

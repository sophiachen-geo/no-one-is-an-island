import zipfile, json, glob, os, sys
sys.path.insert(0,'/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/tools')
from areas import load, munis, DEPTH, DUR, HZ, tr
from shapely.geometry import box, Point
from shapely.ops import unary_union, transform
from shapely.strtree import STRtree
T='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/tools'
BASE='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/ksj'
def mesh_bounds(code):
    c=str(code)
    p,u=int(c[0:2]),int(c[2:4]); q,v=int(c[4]),int(c[5]); r,w=int(c[6]),int(c[7]); h=int(c[8]); k=int(c[9])
    lat=p/1.5 + q/12 + r/120; lon=u+100 + v/8 + w/80
    dlat,dlon=1/240,1/160
    if h in (3,4): lat+=dlat
    if h in (2,4): lon+=dlon
    dlat2,dlon2=dlat/2,dlon/2
    if k in (3,4): lat+=dlat2
    if k in (2,4): lon+=dlon2
    return (lon,lat,lon+dlon2,lat+dlat2)
cells=[]
for f in ['estat_T001142_5035.zip','estat_T001142_5036.zip']:
    z=zipfile.ZipFile(f'{T}/{f}')
    lines=z.read(z.namelist()[0]).decode('cp932').splitlines()[2:]
    for l in lines:
        a=l.split(',')
        if not a[0]: continue
        def num(x):
            try: return int(x)
            except: return 0
        cells.append(dict(code=a[0],htk=a[1],saki=a[2],pop=num(a[4]),hh=num(a[37])))
# geometry and municipality by centroid
for c in cells:
    b=mesh_bounds(c['code'])
    g=transform(tr, box(*b))
    c['geom']=g
    c['muni']=None
    for code,m in munis.items():
        if m.contains(g.centroid): c['muni']=code
cells=[c for c in cells if c['muni']]
for code in munis:
    cs=[c for c in cells if c['muni']==code]
    print('muni',code,'cells',len(cs),'pop all rows',sum(c['pop'] for c in cs),'pop excl htk=2',sum(c['pop'] for c in cs if c['htk']!='2'),'hh',sum(c['hh'] for c in cs),'hh excl2',sum(c['hh'] for c in cs if c['htk']!='2'))
json.dump([{k:v for k,v in c.items() if k!='geom'} for c in cells],open(f'{T}/cells.json','w'))

def maxrank_layers(paths, labels):
    by={}
    for p in paths:
        br,_=load(p)
        for k,g in br.items(): by.setdefault(k,[]).append(g)
    by={k:unary_union(v) for k,v in by.items()}
    study=unary_union(list(munis.values()))
    out={}; higher=None
    for rk in sorted(by, reverse=True):
        g=by[rk].intersection(study)
        g2=g.difference(higher) if higher is not None else g
        higher=g if higher is None else unary_union([higher,g])
        out[labels.get(rk,rk)]=g2
    return out
def exposure(layers):
    res={code:{} for code in munis}
    for c in cells:
        a=c['geom'].area
        for lab,g in layers.items():
            if g.is_empty or not g.intersects(c['geom']): continue
            f=g.intersection(c['geom']).area/a
            d=res[c['muni']].setdefault(lab,[0.0,0.0])
            d[0]+=f*c['pop']; d[1]+=f*c['hh']
    return res
os.chdir(BASE)
sets={
 'L1 national rivers (熊野川・相野谷川・市田川; designated 2023-03-16)':(['A31a-25/10_計画規模/A31a-10-25_86_8606010001_10.shp'],DEPTH),
 'L2 national rivers (max of 3 maps; designated 2017)':(['A31a-25/20_想定最大規模/A31a-20-25_86_8606010001_10.shp','A31a-25/20_想定最大規模/A31a-20-25_86_8606010002_10.shp','A31a-25/20_想定最大規模/A31a-20-25_86_8606010006_10.shp'],DEPTH),
 'L1 all rivers in KSJ A31b (national+prefectural, merged)':(glob.glob(BASE+'/A31b-25/10_計画規模/*.shp'),DEPTH),
 'L2 all rivers in KSJ A31b (national+prefectural, merged)':(glob.glob(BASE+'/A31b-25/20_想定最大規模/*.shp'),DEPTH),
 'Duration L2 national (熊野川・相野谷川)':(['A31a-25/30_浸水継続時間/A31a-30-25_86_8606010001_10.shp'],DUR),
 'Duration all rivers A31b':(glob.glob(BASE+'/A31b-25/30_浸水継続時間/*.shp'),DUR),
 'House-collapse zones national':(['A31a-25/41_家屋倒壊等氾濫想定区域_氾濫流/A31a-41-25_86_8606010001_10.shp','A31a-25/42_家屋倒壊等氾濫想定区域_河岸侵食/A31a-42-25_86_8606010001_10.shp'],HZ),
 'House-collapse zones all rivers A31b':(glob.glob(BASE+'/A31b-25/41_家屋倒壊等氾濫想定区域_氾濫流/*.shp')+glob.glob(BASE+'/A31b-25/42_家屋倒壊等氾濫想定区域_河岸侵食/*.shp'),HZ),
}
allres={}
for name,(paths,labels) in sets.items():
    layers=maxrank_layers(paths,labels)
    r=exposure(layers)
    allres[name]=r
    print(name)
    for code in munis:
        row=r[code]
        order=list(labels.values())
        items=sorted(row.items(), key=lambda kv: order.index(kv[0]) if kv[0] in order else 99)
        tp=sum(v[0] for v in row.values()); th=sum(v[1] for v in row.values())
        print('   ',code,' | '.join(f"{k}: pop {v[0]:.0f}, hh {v[1]:.0f}" for k,v in items),f'|| TOTAL pop {tp:.0f}, hh {th:.0f}')
json.dump({n:{c:{k:[round(v[0]),round(v[1])] for k,v in r[c].items()} for c in r} for n,r in allres.items()},open(f'{T}/exposure_results.json','w'),ensure_ascii=False,indent=1)

import shapefile, json, glob, os
from shapely.geometry import shape, mapping
from shapely.ops import unary_union
from shapely import make_valid, set_precision
BASE='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/ksj'
OUT=BASE+'/clipped_shingu_kiho'
os.makedirs(OUT,exist_ok=True)
munis={c:shape(json.load(open(f'{BASE}/N03/muni_{c}.geojson'))['geometry']) for c in ['30207','24562']}
study=unary_union(list(munis.values()))
DEPTH={1:'0-0.5m',2:'0.5-3.0m',3:'3.0-5.0m',4:'5.0-10.0m',5:'10.0-20.0m',6:'>=20.0m'}
DUR={1:'<12h',2:'12-24h',3:'24-72h',4:'72-168h',5:'168-336h',6:'336-672h',7:'>=672h'}
HZ={1:'氾濫流 (flood flow)',2:'河岸侵食 (bank erosion)'}
cats={'10_計画規模':('L1_planned_scale',DEPTH),'20_想定最大規模':('L2_max_assumed',DEPTH),'30_浸水継続時間':('L2_duration',DUR),
      '41_家屋倒壊等氾濫想定区域_氾濫流':('L2_house_collapse_flood_flow',HZ),'42_家屋倒壊等氾濫想定区域_河岸侵食':('L2_house_collapse_bank_erosion',HZ)}
keep_codes=['_86_','_30_8606010001','_24_8606010001','_24_8606010006']
for d,(name,labels) in cats.items():
    feats=[]
    for p in sorted(glob.glob(f'{BASE}/A31a-25/{d}/*.shp')):
        fn=os.path.basename(p)
        if not any(k in fn for k in keep_codes): continue
        r=shapefile.Reader(p,encoding='cp932')
        fields=[f[0] for f in r.fields[1:]]
        groups={}
        for sr in r.iterShapeRecords():
            rec=dict(zip(fields,sr.record))
            g=shape(sr.shape.__geo_interface__)
            if not g.is_valid: g=make_valid(g)
            if not g.intersects(study): continue
            rk=[v for k,v in rec.items() if k[-2:]=='05'][0]
            river=[v for k,v in rec.items() if k[-2:]=='02'][0]
            mgr=[v for k,v in rec.items() if k[-2:]=='04'][0]
            groups.setdefault((int(rk),river,mgr),[]).append(g.intersection(study))
        for (rk,river,mgr),gs in sorted(groups.items()):
            u=unary_union(gs)
            u=set_precision(u,1e-6)
            if u.is_empty: continue
            feats.append({'type':'Feature','properties':{'river':river,'manager':mgr,'rank':rk,'class':labels.get(rk,str(rk)),'source_file':fn.replace('.shp','')},'geometry':mapping(u)})
    fc={'type':'FeatureCollection','name':name,
        'crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::6668'}},
        'source':'国土数値情報 洪水浸水想定区域データ（河川単位）A31a 2025年度版 (MLIT), https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-A31a-2025.html, CC BY 4.0; clipped to 新宮市(30207)+紀宝町(24562) using 国土数値情報 行政区域 N03 2025 and dissolved by river/manager/rank (加工).',
        'features':feats}
    out=f'{OUT}/{name}_A31a-25_shingu_kiho.geojson'
    json.dump(fc,open(out,'w'),ensure_ascii=False)
    print(out, len(feats), os.path.getsize(out))

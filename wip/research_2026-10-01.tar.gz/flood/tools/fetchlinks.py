import sys,re,html,subprocess
url=sys.argv[1]; out=sys.argv[2]
r=subprocess.run(['curl','-sS','-L','--max-time','90','-o',out,'-w','%{http_code} %{size_download} %{url_effective}',url],capture_output=True,text=True)
print('STATUS',r.stdout,r.stderr)
s=open(out,'rb').read()
t=None
m=re.search(rb'charset=["\']?([A-Za-z0-9_\-]+)',s[:3000])
encs=[m.group(1).decode()] if m else []
encs+=['utf-8','cp932','euc-jp']
for enc in encs:
    try:
        t=s.decode(enc); break
    except Exception: pass
body=re.sub(r'<script.*?</script>','',t,flags=re.S)
body=re.sub(r'<style.*?</style>','',body,flags=re.S)
# main text
txt=re.sub(r'<br\s*/?>','\n',body)
txt=re.sub(r'</(p|div|li|h[1-6]|tr|td|th)>','\n',txt)
txt=re.sub(r'<[^>]+>','',txt)
txt=html.unescape(txt)
lines=[re.sub(r'\s+',' ',l).strip() for l in txt.split('\n')]
lines=[l for l in lines if l]
open(out+'.txt','w').write('\n'.join(lines))
print('---TEXT---')
mode=sys.argv[3] if len(sys.argv)>3 else 'both'
if mode in ('both','text'):
    print('\n'.join(lines[:int(sys.argv[4]) if len(sys.argv)>4 else 400]))
if mode in ('both','links'):
    print('---LINKS---')
    for h,x in re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>',body,flags=re.S):
        x=html.unescape(re.sub(r'\s+',' ',re.sub(r'<[^>]+>','',x))).strip()
        print(h,'|',x[:100])

import sys, pymupdf
# usage: pdftxt.py file.pdf [out.txt]  -> writes text with page markers
f = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else f.rsplit('.',1)[0] + '.txt'
doc = pymupdf.open(f)
meta = doc.metadata
with open(out, 'w') as o:
    o.write(f"# {f} pages={doc.page_count} meta={meta}\n")
    for i, p in enumerate(doc):
        o.write(f"\n===== PAGE {i+1} =====\n")
        o.write(p.get_text())
print(out, doc.page_count, meta.get('title'), meta.get('creationDate'), meta.get('modDate'))

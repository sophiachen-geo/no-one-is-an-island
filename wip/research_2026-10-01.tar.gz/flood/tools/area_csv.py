import sys, csv, glob, os
sys.path.insert(0,'/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/tools')
from areas import load, munis, DEPTH, DUR, HZ
from shapely.ops import unary_union
BASE='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/ksj'
os.chdir(BASE)
NAMES={'30207':'新宮市 Shingū','24562':'紀宝町 Kihō'}
def maxrank(paths, labels):
    by={}
    for p in paths:
        br,_=load(p)
        for k,g in br.items(): by.setdefault(k,[]).append(g)
    by={k:unary_union(v) for k,v in by.items()}
    res={}
    for code,m in munis.items():
        higher=None; row={}
        for rk in sorted(by, reverse=True):
            g=by[rk].intersection(m)
            g2=g.difference(higher) if higher is not None else g
            higher=g if higher is None else unary_union([higher,g])
            row[labels.get(rk,rk)]=round(g2.area/1e4,1)
        res[code]=row
    return res
A='A31a-25/'
sets=[
 ('A31a national 熊野川+相野谷川+市田川 L1 (designated 2023-03-16)',[A+'10_計画規模/A31a-10-25_86_8606010001_10.shp'],DEPTH),
 ('A31a national 熊野川 L2 (2017-03-21)',[A+'20_想定最大規模/A31a-20-25_86_8606010001_10.shp'],DEPTH),
 ('A31a national 市田川 L2 (2017-07-07)',[A+'20_想定最大規模/A31a-20-25_86_8606010002_10.shp'],DEPTH),
 ('A31a national 相野谷川 L2 (2017-03-21)',[A+'20_想定最大規模/A31a-20-25_86_8606010006_10.shp'],DEPTH),
 ('A31a national L2 max of 3 rivers',[A+'20_想定最大規模/A31a-20-25_86_8606010001_10.shp',A+'20_想定最大規模/A31a-20-25_86_8606010002_10.shp',A+'20_想定最大規模/A31a-20-25_86_8606010006_10.shp'],DEPTH),
 ('A31a national duration L2 (熊野川・相野谷川)',[A+'30_浸水継続時間/A31a-30-25_86_8606010001_10.shp'],DUR),
 ('A31a national house-collapse 氾濫流',[A+'41_家屋倒壊等氾濫想定区域_氾濫流/A31a-41-25_86_8606010001_10.shp'],HZ),
 ('A31a national house-collapse 河岸侵食',[A+'42_家屋倒壊等氾濫想定区域_河岸侵食/A31a-42-25_86_8606010001_10.shp'],HZ),
 ('A31a Wakayama 熊野川 (pref. section, 日足区間 etc.) L1',[A+'10_計画規模/A31a-10-25_30_8606010001_10.shp'],DEPTH),
 ('A31a Wakayama 熊野川 (pref. section) L2',[A+'20_想定最大規模/A31a-20-25_30_8606010001_10.shp'],DEPTH),
 ('A31a Wakayama 熊野川 (pref. section) duration',[A+'30_浸水継続時間/A31a-30-25_30_8606010001_10.shp'],DUR),
 ('A31a Wakayama 熊野川 (pref. section) 氾濫流',[A+'41_家屋倒壊等氾濫想定区域_氾濫流/A31a-41-25_30_8606010001_10.shp'],HZ),
 ('A31a Wakayama 熊野川 (pref. section) 河岸侵食',[A+'42_家屋倒壊等氾濫想定区域_河岸侵食/A31a-42-25_30_8606010001_10.shp'],HZ),
 ('A31a Mie 相野谷川 upstream (中小河川) L1',[A+'10_計画規模/A31a-10-25_24_8606010006_20.shp'],DEPTH),
 ('A31a Mie 相野谷川 upstream (中小河川) L2',[A+'20_想定最大規模/A31a-20-25_24_8606010006_20.shp'],DEPTH),
 ('A31b all rivers merged L1',glob.glob(BASE+'/A31b-25/10_計画規模/*.shp'),DEPTH),
 ('A31b all rivers merged L2',glob.glob(BASE+'/A31b-25/20_想定最大規模/*.shp'),DEPTH),
 ('A31b all rivers merged duration',glob.glob(BASE+'/A31b-25/30_浸水継続時間/*.shp'),DUR),
]
out='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/analysis/flood_area_by_class_ha.csv'
with open(out,'w',newline='') as f:
    w=csv.writer(f); w.writerow(['dataset','municipality','class','area_ha'])
    for name,paths,labels in sets:
        r=maxrank(paths,labels)
        for code,row in r.items():
            for cls in labels.values():
                if cls in row and row[cls]>0: w.writerow([name,NAMES[code],cls,row[cls]])
            w.writerow([name,NAMES[code],'TOTAL',round(sum(row.values()),1)])
        print('done',name, {NAMES[c]:round(sum(r[c].values()),1) for c in r})

import sys, json, glob
sys.path.insert(0,'/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/tools')
from areas import load, munis, DEPTH, DUR, HZ
from shapely.ops import unary_union
BASE='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/ksj'
def maxrank(paths, labels):
    by={}
    for p in paths:
        br,_=load(p)
        for k,g in br.items(): by.setdefault(k,[]).append(g)
    by={k:unary_union(v) for k,v in by.items()}
    res={}
    for code,m in munis.items():
        higher=None; row={}
        for rk in sorted(by, reverse=True):
            g=by[rk].intersection(m)
            if higher is not None: g2=g.difference(higher)
            else: g2=g
            higher=g if higher is None else unary_union([higher,g])
            a=g2.area/1e4
            if a>0.005: row[labels.get(rk,rk)]=round(a,1)
        row=dict(sorted(row.items(), key=lambda kv: list(labels.values()).index(kv[0])))
        res[code]=(row, round(sum(row.values()),1))
    return res
sets={
 'L1 national (all 3 rivers, one file)':(['A31a-25/10_計画規模/A31a-10-25_86_8606010001_10.shp'],DEPTH),
 'L2 national 熊野川+市田川+相野谷川 (max depth)':(['A31a-25/20_想定最大規模/A31a-20-25_86_8606010001_10.shp','A31a-25/20_想定最大規模/A31a-20-25_86_8606010002_10.shp','A31a-25/20_想定最大規模/A31a-20-25_86_8606010006_10.shp'],DEPTH),
 'A31b L1 _10 (major rivers, merged)':(glob.glob(BASE+'/A31b-25/10_計画規模/A31b-10-25_10_*.shp'),DEPTH),
 'A31b L2 _10 (major rivers, merged)':(glob.glob(BASE+'/A31b-25/20_想定最大規模/A31b-20-25_10_*.shp'),DEPTH),
 'A31b L1 _20 (other rivers)':(glob.glob(BASE+'/A31b-25/10_計画規模/A31b-10-25_20_*.shp'),DEPTH),
 'A31b L2 _20 (other rivers)':(glob.glob(BASE+'/A31b-25/20_想定最大規模/A31b-20-25_20_*.shp'),DEPTH),
 'A31b L1 all rivers':(glob.glob(BASE+'/A31b-25/10_計画規模/*.shp'),DEPTH),
 'A31b L2 all rivers':(glob.glob(BASE+'/A31b-25/20_想定最大規模/*.shp'),DEPTH),
 'A31b duration all rivers':(glob.glob(BASE+'/A31b-25/30_浸水継続時間/*.shp'),DUR),
}
import os
os.chdir(BASE)
for name,(paths,labels) in sets.items():
    r=maxrank(paths,labels)
    print(name)
    for code,(row,tot) in r.items(): print('   ',code,row,'total',tot)

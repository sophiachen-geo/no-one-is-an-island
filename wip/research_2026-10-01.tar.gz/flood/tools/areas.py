import shapefile, json, glob, os, sys
from shapely.geometry import shape, mapping
from shapely.ops import unary_union, transform
from shapely import make_valid
from pyproj import Transformer
BASE='/tmp/claude-0/-home-user-no-one-is-an-island/12597f4f-a471-563e-939e-90ea1b9703e1/scratchpad/research/flood/ksj'
tr=Transformer.from_crs('EPSG:6668','EPSG:6674',always_xy=True).transform
munis={}
for code in ['30207','24562']:
    f=json.load(open(f'{BASE}/N03/muni_{code}.geojson'))
    munis[code]=transform(tr, shape(f['geometry']))
DEPTH={1:'<0.5m',2:'0.5-3m',3:'3-5m',4:'5-10m',5:'10-20m',6:'>=20m'}
DUR={1:'<12h',2:'12-24h',3:'1-3d',4:'3-7d',5:'1-2wk',6:'2-4wk',7:'>=4wk'}
HZ={1:'hanranryu',2:'kaganshinshoku'}
def load(path):
    r=shapefile.Reader(path, encoding='cp932')
    fields=[f[0] for f in r.fields[1:]]
    rankf=[f for f in fields if f.endswith('05') or f.endswith('_101') ]
    out={}
    for sr in r.iterShapeRecords():
        rec=dict(zip(fields, sr.record))
        # rank field: *_105/_205/_305/_405 for A31a; A31b_101 etc for A31b
        rk=None
        for k in fields:
            if k.startswith('A31a_') and k[-2:]=='05': rk=rec[k]
            if k.startswith('A31b_') and k[-2:] in ('01',) : rk=rec[k]
        g=shape(sr.shape.__geo_interface__)
        if not g.is_valid: g=make_valid(g)
        g=transform(tr,g)
        out.setdefault(int(rk),[]).append(g)
    return {k:unary_union(v) for k,v in out.items()}, fields
def report(path, labels):
    byrank, fields = load(path)
    res={}
    for code,m in munis.items():
        row={}
        for rk,g in sorted(byrank.items()):
            a=g.intersection(m).area/1e4
            if a>0.005: row[labels.get(rk,rk)]=round(a,1)
        res[code]=row
    tot={labels.get(rk,rk):round(g.area/1e4,1) for rk,g in sorted(byrank.items())}
    return res, tot, fields
if __name__=='__main__':
    for p in sys.argv[1:]:
        cat=p.split('/')[-2]
        labels=DEPTH if cat.startswith(('10','20')) else DUR if cat.startswith('30') else HZ
        res,tot,fields=report(p,labels)
        print(os.path.relpath(p,BASE), '| fields', fields)
        print('   TOTAL ha', tot)
        for code,row in res.items():
            print('   ',code, 'ha', row, 'sum', round(sum(row.values()),1))

# Tsunami data for Shingū (新宮市) and Kihō (紀宝町): newest inundation, arrival times, evacuation assumptions

Research date: 2026-10-01. Every URL below returned HTTP 200 through the session proxy on that date, with one exception: `wakayamaken.geocloud.jp` returns 403 to non-browser user agents, so it needs a browser User-Agent string. `www.gsi.go.jp` needs OpenSSL legacy renegotiation; certificate verification stayed on (see `tsunami/_web/fetch_legacy.py`).
The downloaded files are in `research/tsunami/`; the inventory is in §8.

## 0. Bottom line

* **No GIS of the 2026 revisions exists anywhere public (as of 2026-10-01).**
  * **Wakayama 令和8年:** published 2026-03-25 as PDF maps only (two per municipality), plus MP4 animations.
  * **Mie 2026 assumption under the Tsunami Act:** set and published 2026-03-30/31, corrected 2026-06-01. Published as PDF only: 22 map sheets at 1:50,000, plus per-municipality result sheets.
  * **Every GIS copy is the old assumption:**
    * 国土数値情報 A40: the newest edition is 2024年度版, released 2025-05-30, and it still serves Wakayama as `A40-16_30`.
    * Wakayama geocloud/BODIK shapefiles: H25.
    * geospatial.jp: H25.
    * Mie Click Maps and Mie BODIK: a re-distribution of A40.
    * GSI hazard-map tiles: last-modified March 2023.
* **Only one official, reusable, machine-readable dataset has arrival times per location:** the Cabinet Office's 2025 Nankai model data on G空間情報センター. Shingū's web hazard map also has an H25 layer of 1 cm arrival times in 5-minute classes, but it has no open licence (§2b).
  * It gives a 10 m 浸水メッシュ CSV with the arrival time of 1 cm, 30 cm, 1 m, 3 m, 5 m, 10 m, 20 m, 30 m and 40 m, and of the maximum water level, in seconds, for each mesh and each case.
  * Download requires free user registration and login, and the licence forbids redistributing the raw files. **It was not downloaded.**
  * Wakayama's own 令和8年 numbers are single per-municipality values. For Shingū the maximum class gives:
    * maximum height 13 m;
    * time to a 1 m wave 5 min;
    * these are measured about 30 m offshore at the fastest point.
* **The city and prefecture use one fixed set of assumptions for 津波避難困難地域:**
  * departure **5 min** after the earthquake;
  * walking **30 m/min (0.5 m/s)** along roads 3 m or wider;
  * **21 m/min** straight-line equivalent where no such road exists;
  * stairs **21 cm/s** of vertical rise;
  * the deadline is the time to **1 cm** of inundation;
  * the target is ground with less than **30 cm** of inundation, or a designated tsunami building.
* **Shingū's two difficult areas** (2014 programme, based on the H25 assumption):
  * 王子・熊野地: 185 people, 5.5 ha, 1 cm arrival 7–15 min, maximum depth 7 m. Still unresolved at end of FY2024.
  * 三輪崎: 600 people, 11 ha, 6–10 min, 6 m. Resolved by end of FY2023.

---

## 1. Newest inundation assumptions and whether GIS exists

### 1a. Wakayama 令和8年公表「地震動予測及び津波浸水想定」
- **Publisher:** 和歌山県 危機管理部 危機管理局 防災企画課 (TEL 073-441-2271, e0902001@pref.wakayama.lg.jp).
- **Date:** the governor's message is dated 「令和８年３月２５日」, and the maps carry 「令和8 年3 月作成」. The PDF creation dates are 2026-03-19 (report) and 2026-03-23 (maps). HTTP Last-Modified: page 2026-05-29; 巨大 map PDF 2026-03-25; 3連動 map PDF 2026-04-01.
- **Main page:** https://www.pref.wakayama.lg.jp/prefg/011400/bousai/shinsui/r8sinsui.html
  - Report: https://www.pref.wakayama.lg.jp/prefg/011400/bousai/shinsui/r8sinsui_d/fil/03_jishindoutsunami.pdf (18 pp)
  - 概要: …/r8sinsui_d/fil/01_gaiyou.pdf
  - 知事メッセージ: …/r8sinsui_d/fil/02_message.pdf
- **Maps (PDF only):**
  - 最大クラス (南海トラフ巨大地震) list: https://www.pref.wakayama.lg.jp/prefg/011400/d00221942.html
    - Shingū: https://www.pref.wakayama.lg.jp/prefg/011400/d00221942_d/fil/kyodaishinngu.pdf (2 sheets: 1/2 Miwasaki–Sano; 2/2 city centre and the Kumano River mouth)
  - 発生頻度の高い地震 (3連動) list: https://www.pref.wakayama.lg.jp/prefg/011400/d00221941.html
    - Shingū: https://www.pref.wakayama.lg.jp/prefg/011400/d00221941_d/fil/3rendoushinngu.pdf
- **Map format:** A4-landscape PDF.
  - The map is an embedded JPEG raster in strips about 4,811 px wide. It is not vector.
  - Depth legend (7 classes): 0.01–0.3 / 0.3–0.5 / 0.5–1.0 / 1.0–3.0 / 3.0–5.0 / 5.0–10.0 / 10.0–20.0 m. This differs from the H25/A40 breaks.
  - Base map: 「測量法に基づく国土地理院長承認（使用）R 7JHs 784」.
  - The 巨大 maps state: 「「津波浸水想定」は、津波防災地域づくりに関する法律（平成23 年法律第123 号）第8条第1 項に基づいて設定するもの」.
- **Model basis** (page text): 「内閣府が令和7年（2025年）3月に公表した浸水想定を基に、より詳細な地形データ等を用いて想定したもの。」 Cases selected: 「ケース2、3、8、10 を選定」 (report p.4). Tide: 朔望平均満潮位 T.P.+1.00 m (report p.3).
- **Animations (MP4, also downloadable):**
  - Shingū 2D, 巨大: https://www.pref.wakayama.lg.jp/prefg/011400/bousai/shinsui/trough/d00222025_d/fil/16_shinguu_nk_2D_k.mp4
  - Shingū 2D, 3連動: …/trough/d00222029_d/fil/16_shinngu_3ren_2D_k.mp4
- **Licence:** 「和歌山県ホームページ公開情報利用規約」 https://www.pref.wakayama.lg.jp/prefg/000200/opendata/hpopendatakiyaku.html. Key quotes:
  - 「県ホームページのコンテンツは…どなたでも本利用規約に従って複製、公衆送信、翻訳・変形等の翻案等、自由に利用できます。商用利用も可能です。」
  - 「数値データ、簡単な表・グラフ等は著作権の対象ではありませんので…自由に利用できます。」
  - Attribution: 「出典：和歌山県ホームページ（当該ページのURL）」. If you edit, 「改変した旨を記載」.
  - 「本利用ルールは、クリエイティブ・コモンズ・ライセンスの表示4.0 国際…と互換性があり」.
  - Exclusions: 「第三者が権利を有するコンテンツ」. This covers the GSI base map inside the PDFs.
- **GIS availability, checked 2026-10-01:**
  - Pref page: none. Only PDF and MP4 files are linked.
  - **和歌山県オープンデータ (BODIK ODCS, https://odcs.bodik.jp/300004/):** 109 datasets. The tsunami ones are:
    - `300004_w090200_nankai_tsunami01` and `300004_w090200_3ren_tsunami`: metadata 2024-03-25, CC BY 4.0, author 危機管理部危機管理局防災企画課.
      - https://data.bodik.jp/dataset/300004_w090200_nankai_tsunami01
      - https://data.bodik.jp/dataset/300004_w090200_3ren_tsunami
    - Both describe the H24 committee and the H25 assumption.
    - Their shapefile links point to the prefectural WebGIS:
      - https://wakayamaken.geocloud.jp/webgis/OpenData/Download/Shp/Polygon/1/0 (巨大)
      - …/Polygon/2/0 (3連動)
  - **The geocloud data is H25, not R8:**
    - Map metadata gives `publishdate 2022/09/27`; the files inside the zip are dated 2023-08-04/05.
    - The classes are 0.01–0.3 / 0.3–1.0 / 1.0–2.0 / 2.0–3.0 / 3.0–5.0 / 5.0–10.0 / 10.0–20.0, the H25 scheme.
    - The 巨大 layer has 108,032 polygons, against 107,978 in A40-16_30 with the same classes. It is the same dataset.
  - **Licence:** the BODIK terms (https://odcs.bodik.jp/300004/tos/) say:
    - 第2条: 「…クリエイティブ・コモンズ・ライセンス…の表示4.0国際…によるものとします」.
    - 第6条: 「同一のデータセットが、他のサイトにも公開されている場合において、当該サイトの利用規約…と当サイトの利用規約が異なるときは、利用者が当サイトを利用するときに限り、当サイトの利用規約が優先」.
    - The geocloud site's own general terms forbid reuse beyond personal use, so cite the BODIK record.
  - **G空間情報センター:** `30000-020`「30_和歌山県_防災」 https://www.geospatial.jp/ckan/dataset/30000-020. Licence CC-BY. The resource is dated 2018-07-20 (「更新日：2018/03/02」, JGD2000), so it is H25. A search of geospatial.jp for 和歌山 tsunami found nothing newer.
  - **国土数値情報 A40:**
    - Newest edition page: https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-A40-2024.html. It says 「最新のデータはデータ基準年度 2024年度（令和6年度）版です」 and 「2025年5月：2024年度（令和6年度）版に更新しました」.
    - KSJ news (https://nlftp.mlit.go.jp/ksj_news.html) lists 2025/05/30 「津波浸水想定データ（2024年度（令和6年度）版）」 as the last A40 release. No A40 entry appears through 2026/09/16. `KsjTmplt-A40-2025.html` returns 404.
    - The Wakayama row is still 「和歌山 世界測地系 2016年（平成28年） 45.8MB A40-16_30_GML.zip」. **A40 does not contain the 2026 revision.**
    - Licence on the 2024 page: 「オープンデータ（CC_BY_4.0（一部制限））」, with 和歌山県 listed under 「＜オープンデータとして利用可（商用利用可・再配信可）＞」.
    - The older v1.1 detail page (KsjTmplt-A40.html) still lists 和歌山県 under 「国土数値情報としてダウンロード提供不可」, which contradicts this. Prefer citing the BODIK CC BY 4.0 record for the same H25 data.
  - **GSI ハザードマップポータル** raster tiles `04_tsunami_newlegend_pref_data/30` and `/24` (spec: https://disaportal.gsi.go.jp/hazardmap/copyright/opendata.html):
    - The Shingū tiles show `last-modified: Sat, 11 Mar 2023` (Wakayama) and `Fri, 10 Mar 2023` (Mie). They are the old assumptions, not R8.

### 1b. Mie: new 津波浸水想定 (2026), maps 21 and 22 cover 紀宝町
- **Publisher:** 三重県 防災対策部 災害対策推進課 南海トラフ地震対策班 (TEL 059-224-2282, staisaku@pref.mie.lg.jp).
- **Page:** https://www.pref.mie.lg.jp/D1BOUSAI/845440078610001.htm 「三重県南海トラフ地震被害想定について」.
  - Dates: 令和08年03月31日, corrected 2026-04-03 and 2026-06-01. The correction notice is https://www.pref.mie.lg.jp/TOPICS/m0021500094.htm, dated 2026-06-02.
  - Section 3: 「津波防災地域づくりに関する法律第８条第１項の規定に基づき、津波浸水想定を設定しましたので、下記のとおり公表します。」
- **Maps (raster PDF, 1:50,000, 8 depth classes up to 「20.0m 以上」):**
  - 図面番号21 (熊野市、御浜町、紀宝町): https://www.pref.mie.lg.jp/common/content/001249287.pdf
  - 図面番号22 (御浜町、紀宝町): https://www.pref.mie.lg.jp/common/content/001249288.pdf
  - Last-Modified 2026-03-30 for both. Sheets 21 and 22 were not in the 2026-06-01 correction list (全体図, 2, 3, 5–12, 16–18).
- **解説:** https://www.pref.mie.lg.jp/common/content/001249264.pdf 「令和8 年3 月30 日公表 令和8 年6 月1 日一部追記」.
  - Cases 1, 2, 6, 7, 8, 9 and 10 of the 2012 CAO models.
  - Minimum grid 10 m; 12 h simulated.
  - Tide at 熊野 0.9 m and 浦神 1.0 m (朔望平均満潮位).
- **Kihō result sheet (資料4, replaced 2026-06-01):** https://www.pref.mie.lg.jp/common/content/001259061.pdf. Figures are in §2.
- **Licence** (page footer): 「本ページで掲載しているデータは、クリエイティブ・コモンズ表示4.0国際ライセンスの下に提供されており、三重県オープンデータ利用規約を守れば誰でも自由に利用することができます。」 Terms: https://odcs.bodik.jp/240001/tos/ (第１条: CC BY 4.0). The map base is GSI (承認 R 7JHs 1142), and the sheet adds 「承認を得て作成した複製品を第三者がさらに複製する場合には、国土地理院の長の承認を得なければならない。」
- **GIS for Kihō: none for 2026.**
  - Mie open data (BODIK `240001_bousai_tsunami_shinsui_soutei`「津波浸水予測図（シェープファイル）」, 2023-06-19, CC BY 4.0) points to Mie Click Maps item `662dced0aa3f4d2fb6f73eee20df8c1f` (created 2021-01-25, modified 2023-12-11). The item describes itself as 「出典：国土交通省国土数値情報ダウンロードサイト」, so it is the A40 data.
  - The FeatureServer `tsunamishinsui_zokusei` has only `A40_003`, the depth class.
  - No 2026 tsunami layer exists among the 68 services of Mie's ArcGIS organisation.
  - The newest Kihō GIS is therefore still `A40-16_24`, i.e. Mie's 2015 Act-based assumption, which equals the H26.3 prediction (MLIT 河川分科会 第52回 資料2-7, https://www.mlit.go.jp/river/shinngikai_blog/shaseishin/kasenbunkakai/bunkakai/dai52kai/siryou2-7.pdf). A40 licence for Mie: 「利用にあたり、「三重県オープンデータ利用規約」を遵守すること」.
  - Mie's correction notice says the prefecture is now confirming new 津波災害警戒区域 based on the 2026 assumption.

### 1c. What was downloaded for item 1
| File (under `tsunami/`) | What | Licence |
|---|---|---|
| `wakayama_R8/wk_r8_kyodaishinngu.pdf`, `wk_r8_3rendoushinngu.pdf` | R8 Shingū inundation maps, 2 sheets each (raster) | Wakayama HP terms (CC BY-compatible); GSI base map is third-party |
| `wakayama_R8/wk_r8_03_jishindoutsunami.pdf`, `wk_r8_01_gaiyou.pdf`, `wk_r8_02_message.pdf` (+ `.txt`) | R8 report, summary, governor's message | same |
| `wakayama_R8/wk_r8_16_shinguu_nk_2D_k.mp4` | R8 2D animation, Shingū, 巨大 (1280×720, 10 fps, 1 frame = 10 s simulated) | same |
| `wakayama_H25_gis/gc_nankai/wk_geocloud_nankai_H25.*`, `gc_3ren/wk_geocloud_3rendou_H25.*` | Prefecture-wide H25 shapefiles from Wakayama WebGIS (WGS84 .prj; attribute 「津波浸水深」 class, UTF-8) | CC BY 4.0 (BODIK) |
| `wakayama_H25_gis/wk_H25_nankai_shingu.geojson` (2,256 polygons, 313 ha) and `wk_H25_3rendou_shingu.geojson` (1,157 polygons, 97 ha) | The same data clipped to the N03-2026 boundary of Shingū. The 3連動 layer is **not in A40** | CC BY 4.0 (BODIK) |
| `mie_R8/mie_001249287.pdf`, `mie_001249288.pdf` | Mie 2026 inundation maps 21 and 22 (Kihō) | CC BY 4.0 + Mie terms; GSI base map |
| `mie_R8/mie_001259061.pdf` | Kihō result sheet (contains the 1 cm arrival-time map) | same |
| `mie_R8/mie_001249264.pdf`, `mie_001259031.pdf` | 解説; 概要版 | same |

---

## 2. Arrival-time data

### 2a. Wakayama 令和8年: Shingū figures (report `03_jishindoutsunami.pdf`)
Definitions (quotes):
- Heights, p.9: 「最大津波高とは、和歌山県全域の海岸線から沖合約30ｍ地点における、当該市町内の最大の高さを示しており、当該市町内の全ての沿岸部を表しているわけはありません。」 Also 「※いずれも小数点以下切り上げ」.
- Times, p.14: 「※上記到達時間について、秒単位で切り捨てている。」 and 「※津波到達時間とは、和歌山県全域の海岸線から沖合約30m地点における、当該市町村内の津波高別の最短の到達地点の時間を示している。」
- Message: 「発表した津波高、津波到達時間というのは、各市町における一つの地点を示す代表値であり、当該市町全域がこれらの数値になるものではありません。」
- p.15 uses Kushimoto as the example: the fastest point is 1 min, but 「串本町市街地における津波到達時間は５分です」.

| Shingū | R8 | H25 | Source (printed page / PDF page) |
|---|---|---|---|
| 最大クラス 最大津波高 / 平均津波高 | **13 m** / 10 m | 14 m / 10 m | p.10 / PDF 13. Change ▲1 m, factor 「地形データを更新したため。」 (p.11) |
| 発生頻度の高い地震 最大 / 平均 | 7 m / 6 m | 7 m / 6 m | p.10 |
| 最大クラス arrival, 津波高 +1 m / +3 m / +5 m / +10 m | **5 / 5 / 6 / 28 min** | 5 / 5 / 6 / 28 | p.14 / PDF 17 |
| 発生頻度の高い地震 arrival, 第1波最大津波 | **11 min** | 11 | p.14 |
| 浸水面積, 最大クラス (1 cm or more) | **290 ha** (1.1 % of 25,523 ha) | 330 ha | p.12. Change ▲40 ha, 「地形データを更新したため。」 (p.13) |
| 浸水面積, 3連動 | **100 ha** (0.4 %) | 110 ha | p.12 |

Shingū's own 地域防災計画, revised March 2026, still prints the H25 table: 14 m, 330 ha, 「津波高 1m→5分 3m→5分 5m→6分 10m→28分」, 3連動 第1波最大津波 11分. See 第1編 p.1-24, sourced to 「防災わかやま「平成25年 和歌山県の浸水想定について」」, in the PDF https://www.city.shingu.lg.jp/Link/Pdf/596 linked from https://www.city.shingu.lg.jp/info/412.

### 2b. Is there an official, spatially varying arrival-time dataset?
1. **Cabinet Office, 2025 Nankai model data: yes, mesh-level, but behind a login.** This is the only one.
   - G空間情報センター, organisation 「内閣府 南海トラフ巨大地震モデル・被害想定手法検討会 （令和7年～）」.
     - 「津波断層モデル(11)陸域における津波浸水深データ」 https://www.geospatial.jp/ckan/dataset/11_. Created 2025-05-14, modified 2026-04-01. One ZIP per case, 217–242 MB, CSV inside. Cases ①–⑪, plus ① 東側半割れ and ④ 西側半割れ, under 「堤防破堤」; four cases also under 「堤防03分破壊」.
     - 「(10)海岸における津波高・津波到達時間・波形」 https://www.geospatial.jp/ckan/dataset/10. Modified 2025-09-17.
   - Field list (計算結果データの説明, https://www.geospatial.jp/ckan/dataset/26804359-b035-4df2-84cc-eb2121172a1e/resource/f588ccfc-7641-4a92-9b94-2906dee41847/download/calc.pdf, p.3):
     - 浸水メッシュ: ①経度 ②緯度 (JGD2000) ③浸水深公表値.
     - Arrival times: ④1cm ⑤30cm ⑥1m ⑦3m ⑧5m ⑨10m ⑩20m ⑪30m ⑫40m ⑬最高水位の到達時間〔秒〕.
     - Reference values: ⑭浸水深 ⑮地殻変動後の標高 ⑯隆起量.
     - The 海岸メッシュ file has the same arrival-time fields.
     - Files are split by 平面直角座標系; 「Ⅵ系（06 系）：大阪府、三重県、和歌山県」.
     - Mesh: 「沿岸域を 10m×10m のメッシュ単位で想定」 (licence, 第2条).
   - Access: 「データのダウンロードは、ユーザ登録の後、ログイン状態で行ってください。」 **Not downloaded.** Free registration is needed.
   - Licence 「…データ利用規程」 (https://www.geospatial.jp/ckan/dataset/26804359-b035-4df2-84cc-eb2121172a1e/resource/414d34d1-6277-4f80-8137-d63dc9212c67/download/license.pdf):
     - 第3条: 「「内閣府 南海トラフの巨大地震モデル・被害想定手法検討会」と出典を明記のこと。なお、編集・加工した情報を、あたかも内閣府が作成した未加工のままであるかのような態様で公表・利用してはならない。」
     - 第4条: 「…編集・加工し、その成果物を自由に頒布…できる。一 公開データをこのまま複製（ファイル形式を変換しての複製を含む）して、第三者に頒布、譲渡することを禁じる。」
     - So derived per-building margins may be published, but the CSVs may not be re-hosted.
   - Wakayama's R8 maximum class is built on this model ("より詳細な地形データ") with cases 2, 3, 8 and 10. Mie uses cases 1, 2, 6, 7, 8, 9 and 10. The minimum 1 cm or 30 cm arrival over those cases is the closest public analogue of the prefectural envelope. The structure conditions differ from Wakayama's.
2. **Wakayama R8:** no spatial arrival data; only the per-municipality minima above. The animations (above) show inundation over time: 1 frame = 10 s, with an on-screen clock (frame n reads n×10 s).
   - **Feasibility probe (not official data, not georeferenced):** `wakayama_R8/vid_arrival_probe.py` and `vid_arrival_classes_preview.png`.
   - First-wet time per video pixel: beach strip about 3–7 min; Udono (Kihō) bank about 7–10 min; the inner lowland of central Shingū about 20–40 min.
   - Usable only as a sanity check, or after georeferencing and validation.
3. **Wakayama H25-based district ranges:** 1 cm arrival inside the difficult areas.
   - 王子・熊野地 **7–15 min**; 三輪崎 **6–10 min** (programme map, 巻末資料2 (13)).
   - Shingū overall 「6～15分後 7ｍ」 (R6 progress report, slide 8).
4. **Shingū web hazard map** (https://shingu.nigedoki-map.com):
   - It has a layer 「南海トラフ巨大地震津波 到達時間…到達時間は、地震発生から浸水深1cmの津波が到達するまでの時間」. The layer is H25, from 和歌山県.
   - Classes: 5分以内 / 5–10 / 10–15 / 15–20 / 20–25 / 25–30 / 30分以上. Served as vector tiles (`/tiles/main/{z}/{x}/{y}.pbf`, layer `hm_tsunami_reach`).
   - Doc: https://shingu.nigedoki-map.com/doc/map.html.
   - Terms (https://shingu.nigedoki-map.com/doc/terms.html) forbid 「提供する情報を営利目的で利用する行為」. There is no open licence, so ask 新宮市防災対策課 before reuse. **Not extracted.**
5. **Mie 2026, Kihō** (result sheet p.2; 概要版 pp.20 and 23):
   - Coastal: 沿岸最大津波高 L2 **11 m** / L1 6 m. 沿岸津波到達時間 L2 **5 min** / L1 4 min (「※沿岸で１ｍの水位変動が発生するまでの最短の時間」). 浸水面積 L2 198 ha / L1 62 ha.
   - Map 「(7) 津波浸水深到達時間 ※陸上で１cmの浸水が発生するまでの時間」 uses coarse classes: 0–30, 30–60, 60–90, 90–120, 120–240 … 600–720 min. Almost all of the Kihō inundation is 0–30 min.
   - Offshore 「海域の津波影響開始時間」 at 紀宝町井田（上野口）: L2 海面±20cm **5 min**, +1m **6 min**; L1 4 / 5 min. The footnote reads 「※気象庁が発表する津波注意報の発表下限である20㎝と、巻き込まれた場合にほとんどの人が亡くなる可能性がある１ｍの高さを基準に予測しました。」
6. **A40, the GSI tiles and KSJ hold no arrival times.**

---

## 3. Shingū city evacuation planning

- **新宮市津波防災地域づくり推進計画** (October 2025; the PDF Last-Modified is 2025-10-20; created under the Tsunami Act's 法定協議会).
  - Page: https://www.city.shingu.lg.jp/info/2811. PDF: https://www.city.shingu.lg.jp/div/bousai/pdf/suisinkeikaku/suisinkeikaku.pdf (57 pp).
  - **Definition and method,** p.19 (PDF 21), quoting the prefecture's programme:
    - 「…避難開始時間、移動速度等の一定の条件や想定した津波到達時間に基づき、地域単位で避難先までの経路と距離を詳細に考慮して、津波到達時間までに浸水域外（津波の想定浸水深が30 ㎝未満となる地域）の高台や津波避難ビル等の安全な場所に避難することが困難な地域を津波避難困難地域として抽出しました。」
    - 抽出方法:
      - 「平成25 年３月公表の３連動地震及び巨大地震の津波浸水想定に基づき想定」
      - 「避難対象地域は、津波の想定浸水深が30cm 以上の住居地域」
      - 「津波到達時間は、津波の想定浸水深が１cm となる時間」
      - 「避難開始時間は地震発生より５分後とする」
      - 「避難方法は徒歩とする」
      - 「道路に沿って移動し、移動速度は毎分30m とする」
      - 「避難場所は、市町が指定する避難先(浸水域外の避難施設もしくは広場、または想定津波浸水域内の津波避難タワーもしくは津波避難ビル等)」
    - (参考): 「① ３m 以上の道路は30m/分で避難範囲を設定 ② ①の道路がない地域は同心円…により､21m/分で避難範囲を設定」.
  - **Table 3-3** (p.20 / PDF 22): 新宮地区（王子、熊野地等）185人, 5.5ha, 1cm 津波到達時間 7～15分, 最大浸水深 7m; 三輪崎・佐野・木ノ川・蜂伏地区（三輪崎）600人, 11ha, 6～10分, 6m.
  - Map: Fig. 3-6 (p.21), taken from the 2014 programme. Its note reads 「※津波避難困難地域とは、居住地域で、かつ、避難ビル等への緊急避難を考慮しても逃げ切れない地域」.
  - p.25: 「王子、熊野地などの津波避難困難地域では、津波が7 分～15 分で到達することとなっており、極めて円滑な避難が求められます。」
- **Prefectural source:** 「津波から『逃げ切る！』支援対策プログラム」 (October 2014).
  - Page: https://www.pref.wakayama.lg.jp/prefg/011400/h26nigekiru.html. PDF: https://www.pref.wakayama.lg.jp/prefg/011400/h26nigekiru_d/fil/nigekiru_h26.pdf.
  - pp.5–9: the 避難可能距離 is 「歩行速度×（津波の想定浸水深が１cmとなる時間－避難開始時間－高層階へ上る時間）」.
    - 高層階へ上る速度: 「毎秒21cm」.
    - 避難開始時間: 「県内全域５分」. The 2008 version used 新宮市～白浜町 5分, 中部 7分, 北部 10分.
    - 避難可能最大距離: 「上限を設けない」.
  - Table 6 (p.8):
    - Roads: 「幅員３m以上の主な道路網」; narrower ways are converted from straight-line distance.
    - Bridges passable only if 「耐震補強済みの橋」「道路橋示方書適用年が昭和55年以降の橋」「橋長15m未満の橋」.
    - Destinations: 「巨大地震による最大津波高よりも高い場所への避難を前提とする」.
    - Tsunami buildings: post-1981 seismic design or retrofitted; RC or SRC; 「巨大地震の基準水位以上に避難可能な施設」.
  - Table 13 (p.19): Shingū 2地区 (三輪崎、熊野地等), 16.5 ha, 785人. The 3連動 table on p.10 lists no Shingū district.
  - 巻末資料2 (13) (PDF p.55) is the map of the difficult areas. Rendered crop: `tsunami/guidance/wk_nigekiru_h26_p55.png`.
- **Progress report** (March 2025): https://www.pref.wakayama.lg.jp/prefg/011400/h26nigekiru_d/fil/nigekiru_R6.pdf
  - Slide 11 (2024年度末): 三輪崎 ● ◎ 解消. **王子・熊野地 ○ 着手済, not resolved:** 「避難路整備、避難施設整備（避難高台）」「津波防護施設（緑の防潮堤※）※新宮道路の整備に合わせて施工予定」. 事前復興計画: 2026年度着手予定.
  - Slide 2: Shingū shows 1 remaining district from 2023年度末 through the 2026年度末 forecast.
- **事前避難対象地域 (南海トラフ地震臨時情報):** https://www.city.shingu.lg.jp/info/2177 (updated 2023-10-29).
  - Definition: 「（津波到達前に、地震動に伴う堤防沈下の影響により、概ね地震発生から30分以内に30ｃｍの以上の浸水が生じる地域）」.
  - 住民事前避難対象地域: 「熊野地２丁目、あけぼの、王子町２・３丁目の一部」.
  - 高齢者等事前避難対象地域: 「阿須賀１丁目、熊野地１・２丁目、あけぼの、王子町１・２・３丁目、田鶴原町２丁目、三輪崎１・２・３丁目」.
- **津波一時避難施設・場所** (the city's tsunami-building list; page updated 2017-02-03): https://www.city.shingu.lg.jp/info/762
  - 43 sites across 丹鶴, 千穂, 蓬莱, 王子, 三輪崎, 佐野 and 木ノ川, giving the designated floor and the 海抜 of that floor (e.g. シャトー新宮 「３階以上の廊下等」 14.5 m).
  - Parsed to `shingu_city/shingu_tsunami_ichiji_hinan_2017.csv`.
- **指定避難所・指定緊急避難場所** (updated 2024-04-08): https://www.city.shingu.lg.jp/info/123
  - 91 rows; 49 tsunami-designated (☆☆☆ 31, ☆☆ 10, ☆ 8). Parsed to `shingu_city/shingu_shitei_hinan_2024.csv`.
  - Star levels (和歌山県津波避難計画策定指針, November 2015, p.23; https://www.pref.wakayama.lg.jp/prefg/011400/bousai/guide/index_d/fil/hinankeikaku27.pdf):
    - ☆☆☆ 「３連動地震及び巨大地震ともに浸水の危険性がない地域において、より標高が高く、またはより離れた安全な避難先」.
    - ☆☆ 「① ３連動地震の浸水想定区域外にある避難先 ② 巨大地震の浸水想定区域内にあるが浸水深以上の高さがある避難先」.
    - ☆ 「① ３連動地震の浸水想定区域内にあるが３連動地震の浸水深以上の高さがある避難先 または ② ３連動地震の浸水想定区域外にあるが、巨大地震では浸水想定区域内にあり巨大地震の浸水深以上の高さがない避難先」.
    - All of these are based on H25 and are due for review: the R8 message says 「各市町村ではこの想定に基づきハザードマップの見直しなどが行われる予定です」.
- **Other city documents:**
  - 地域防災計画 (R8.3, https://www.city.shingu.lg.jp/info/412): the evacuation chapter (第4編 第2章 第4節, pp.4-36–4-44) gives no numeric speed or delay. Much of the PDF has broken font encoding.
  - The 津波ハザードマップ is H26 (https://www.city.shingu.lg.jp/info/126).
  - The 津波災害警戒区域 was designated 2016-04-19 on the H25 area, with 基準水位 published as 10 PDF sheets: https://www.pref.wakayama.lg.jp/prefg/082500/tsunami/kuiki_shingu.html.
  - I found no standalone 「新宮市津波避難計画」.

---

## 4. National guidance: walking speed, departure delay, slopes and stairs

- **The 2013 report is by 消防庁 (FDMA), not 内閣府.** It is 「津波避難対策推進マニュアル検討会報告書」, 平成25年3月. 内閣府 lists it under 【消防庁】 at https://www.bousai.go.jp/jishin/tsunami/hinan/kanren.html.
  - Committee page: https://www.fdma.go.jp/singi_kento/kento/kento106.html.
  - Original chapter 2 「市町村における津波避難計画策定指針」, 2013-03-11: https://www.fdma.go.jp/laws/tutatsu/items/tuchi2503/pdf/250311_sai_1-2.pdf (pp.11–13).
  - Chapter 2 was amended 「令和8年1月16日改正」:
    - Full report: https://www.fdma.go.jp/singi_kento/kento/items/kento106_01_p0.pdf, printed pp.24–26 (PDF 29–31).
    - Chapter alone: https://www.fdma.go.jp/singi_kento/kento/2026/09/01/items/kento106_01_2syou2.pdf, printed pp.24–26.
  - The speed text is unchanged between versions:
    - (1) 「歩行速度は1.0ｍ／秒（老人自由歩行速度、群集歩行速度、地理不案内者歩行速度等）を目安とするが、歩行困難者、身体障がい者、乳幼児、重病人等についてはさらに歩行速度が低下する（0.5ｍ／秒）こと、東日本大震災時の津波避難実態調査結果による平均避難速度が0.62ｍ／秒であったこと等を考慮する必要がある。」
    - (2) 「避難できる限界の距離は最長でも500ｍ程度を目安とする」.
    - (3) 「地域の実情に応じて、地震発生後２～５分後に避難開始できるものと想定する。」
    - (4) Night and snow are slower.
    - Formula: 「避難可能距離＝（歩行速度）×（津波到達時間－避難開始時間）」.
    - Footnote 2, on the 津波到達予想時間 (2013 p.11 / 2026 p.24): 「20cm の水位変化が生じるまでの時間を一つの目安とすることが考えられる。」
  - The 2026 text adds (p.25): 「令和７年３月に公表された南海トラフ巨大地震の被害想定…では、避難の迅速化が図られた場合について、昼間の場合には発災後５分後、深夜でも発災後10 分で避難開始するとして試算している。避難速度についても夜間は昼間の80％に低下するものとしている。」 The 2013 text cited the 2012 第一次報告 with the same numbers.
  - 【参考】歩行速度 (2013 p.13 / 2026 p.26), including stairs:
    - 自力のみで行動できにくい人: 水平 0.8 m/s, 階段 0.4 m/s.
    - 位置、経路等に慣れていない人: 水平 1.0 m/s, 階段 0.5 m/s.
    - 老人単独歩行 1.1 m/s; ベビーカー 0.9 m/s.
    - Tōhoku walkers: 全体 0.62 m/s, 平野部 0.78 m/s, リアス部 0.53 m/s.
- **内閣府 「津波避難ビル等に係るガイドライン」 (June 2005): abolished.** https://www.bousai.go.jp/jishin/tsunami/hinan/tsunami_top.html says 「「津波避難ビル等に係るガイドライン」は、廃止しました」 (2017-07-05). Its parameters are quoted in MLIT 都市局 「津波避難を想定した避難路、避難施設の配置及び避難誘導について（第３版）」, April 2013 (https://www.mlit.go.jp/common/000233464.pdf), p.95:
  - L = P1 × (T − t1 − t2).
  - 「P1（歩行速度）；1.0m/秒を想定。ただし、歩行困難者…（0.5m/秒）」.
  - 「t２…「最大浸水深 H（m）」/「階段・上り坂昇降速度P2（m/秒）」…P2は0.21m/秒を想定する。」 This is a vertical rate, and the source of Wakayama's 21 cm/s.
  - Slopes, same document p.33, from the Tōhoku survey: 「徒歩の避難速度について避難路の勾配が5%未満は2.51km/h、5%以上は1.59km/h」, plus mean 2.24 km/h (平野部 2.81, リアス部 1.89).
- **MLIT 都市局 「津波防災まちづくりの計画策定に係る指針」** (June 2013, https://www.mlit.go.jp/common/001000488.pdf), pp.34–35: 「避難可能時間 = T －t1 － t2」, with the 0.21 m/s stair or uphill rate. Its table of municipal departure settings ranges from 100 s (Shizuoka City) to 15 min (Miyagi).
- **内閣府 2025 damage method** 「南海トラフ巨大地震の被害想定項目及び手法の概要」 (March 2025, https://www.bousai.go.jp/jishin/nankai/taisaku_wg_02/pdf/sanko_gaiyo.pdf), pp.24–26:
  - Rule: people who have not finished evacuating before 「津波が到達する時間（浸水深30cm以上）」 are counted as caught.
  - Destination mesh: 「最短距離にあり、かつ避難元メッシュよりも津波浸水深1cm到達時間が長い、津波浸水深30cm未満」.
  - Distance: 「メッシュ中心間の直線距離の1.5倍」.
  - Departure: 「昼間発災時は、直接避難者で発災5分後、用事後避難者で15分後」. 切迫避難 begins after arrival. At night, 「さらに5分」.
  - Speeds in km/h (m/s):

    | Group | 全体 | 平野部 (勾配5%未満) | 傾斜部 (勾配5%以上) |
    |---|---|---|---|
    | All walkers | 2.24 (0.62) | 2.51 (0.70) | 1.59 (0.44) |
    | 避難行動要支援者同行 | 1.69 (0.47) | 1.89 (0.53) | 1.20 (0.33) |
    | 健常者 | 2.43 (0.68) | 2.72 (0.76) | 1.73 (0.48) |

    平野部 is 1.12× the overall mean and 傾斜部 0.71×. Night is 「昼間の8割」.
  - 高層階滞留者 (occupants above a depth-dependent floor may stay): 「1、2階滞留者が避難」 if the maximum depth is 30 cm–6 m, 「1～5階…」 if 6–15 m, 「1～10階…」 if 15–30 m, and 「全員避難」 if 30 m or more.
- **Wakayama guideline (November 2015) rationale,** pp.41–43:
  - 5 min: 「震度４以上の強い揺れが３分程度続いたこと、避難準備時間に２分程度を要することなどを考慮し…県内全域で避難開始までに必要な時間を５分」.
  - 30 m/min: chosen from the FDMA figures 「…を参考に、避難行動要支援者の避難や家屋倒壊、道路閉塞等も考慮し、専門家会議の意見を踏まえ、移動速度は毎分30m」. Stairs 毎秒21cm.

---

## 5. GSI 指定緊急避難場所データ (newest)

- **Portal:** https://hinanmap.gsi.go.jp/index.html. The click-through 「同意する」 leads to https://hinanmap.gsi.go.jp/hinanjocp/hinanbasho/koukaidate.html. The overall list's last update is 2026-09-25.
- **Shingū (30207):** 公開日 2017-02-22, **最終更新日 2025-01-23**.
  - 87 指定緊急避難場所, **48 with 津波=1**; 51 指定避難所.
- **Kihō (24562):** 公開日 2017-06-19, **最終更新日 2025-01-23**.
  - 41 指定緊急避難場所, **30 with 津波=1**; 15 指定避難所.
- **Files:**
  - 指定緊急避難場所: `https://hinanmap.gsi.go.jp/hinanjocp/defaultFtpData/csv/{code}_2.csv` and `…/geoJSON/{code}_2.geojson`.
  - 指定避難所: `…/{code}_1.*`.
  - Saved in `tsunami/gsi_hinanbasho/`.
  - The CSV columns are NO, 共通ID, 施設・場所名, 住所, then one flag per hazard (洪水 … 津波 … 火山現象), then 指定避難所との住所同一, 緯度, 経度, 備考.
- **Derived file:** `30207_tsunami_sites_with_H25_depth.csv`. 11 of the 48 tsunami sites lie inside the H25 巨大 inundation (vertical refuges such as オーシャンハイツ, 熊野地ハイツ and たづはら保育園).
- **Licence:**
  - 国土地理院コンテンツ利用規約 (令和7年11月20日改正, https://www.gsi.go.jp/kikakuchousei/kikakuchousei40182.html): 「公共データ利用規約（第1.0 版）（PDL1.0）が適用」. Attribution 「出典：国土地理院ウェブサイト （当該ページのURL）」; if edited, say so.
  - Notice text, saved as `gsi_notice_utf8.txt`:
    - 「最新でない場合や未掲載の場合があるため、最新かつ詳細の状況などは必ず当該市町村にご確認ください」.
    - 「本データを用いた情報を第三者に提供する場合は、上記1．～3．の注意事項が正確に伝わるよう、十分にご留意ください」.
- **Differences from the city page (2024-04-08):**
  - Naming differences: 丹鶴ホール; 保健センター vs こども家庭センター; 宝珠寺境内 vs 宝珠寺駐車場.
  - The city's 「よってって駐車場」 (新宮8001-52, 津波 ☆☆☆) has no GSI tsunami record.
  - GSI has no star safety levels; use the city CSV for those.

---

## 6. Suggested parameters for the per-building margin
Margin = T_local − t_dep − D_net / v − H / 0.21. The last term applies only to vertical evacuation.

- **T_local:**
  - Preferred: the 1 cm arrival (Wakayama's rule), or 30 cm (CAO 2025 and 事前避難 rule), from the CAO 2025 10 m 浸水メッシュ.
    - Take the minimum over cases 2, 3, 8 and 10 for Shingū, and 1, 2, 6, 7, 8, 9 and 10 for Kihō.
    - Requires a G空間 login. Publish only derived values, credited 「内閣府 南海トラフの巨大地震モデル・被害想定手法検討会」.
  - Fallbacks:
    - Uniform 5 min (R8 +1 m minimum), which is very conservative inland.
    - The H25 district ranges.
    - The video probe, after georeferencing.
- **t_dep:** 5 min as the base (Wakayama, Shingū, and CAO daytime direct evacuation). Sensitivity runs: 10 min (night) and 15/20 min (用事後).
- **v:** 0.5 m/s as the base (Wakayama 30 m/min; FDMA figure for people needing help). Sensitivity:
  - 1.0 m/s (FDMA 目安).
  - CAO slope-aware values: 0.70 m/s flat or 0.44 m/s on grades of 5 % or more.
  - ×0.8 at night.
  - Narrow lanes: 21 m/min on straight-line distance (Wakayama), or CAO's 1.5× straight line.
- **Safe target:** ground with less than 0.3 m of inundation and above the maximum tsunami height, or GSI 津波=1 / city ☆ sites. Use the floor 海抜 from `shingu_tsunami_ichiji_hinan_2017.csv`; climb at 0.21 m/s.
- **Bridges:** Wakayama's passable rule (retrofitted, post-1980 design specification, or under 15 m long).

## 7. Caveats and open points
- The R8 PDF maps could be georeferenced and colour-classified to rebuild R8 depth classes, but:
  - the JPEG artifacts and pale palette make classification error-prone;
  - the GSI base map is third-party content (approval R 7JHs 784).
- The better route is to ask 和歌山県防災企画課 and 三重県南海トラフ地震対策班 for R8 GIS.
- Wakayama's 「被害想定」 based on R8 is promised for 令和8年度 (知事メッセージ).
- Mie's further 32 risk items are due 「令和８年秋ごろ」.
- Wakayama's R8 summary sheet attributes Shingū's −1 m to 地殻変動 modelling, but the detailed table (p.11) says 「地形データを更新したため。」. Quote the table.
- Polygon areas recomputed from the H25 clips (313 ha and 97 ha) are below the report's 330 and 110 ha. The report rounds up, and coastline or river clipping differs.

## 8. File inventory (`research/tsunami/`)
- `wakayama_R8/`: R8 report, summary, message and Shingū maps (PDF and .txt), the 2D MP4, rendered checks (`wk_r8_p17.png` = arrival table), and the video probe script and preview.
- `wakayama_H25_gis/`: prefecture-wide H25 shapefiles (巨大, 3連動) and the Shingū-clipped GeoJSONs.
- `mie_R8/`: Kihō maps 21 and 22, the Kihō result sheet (with the arrival map PNG), 解説, 概要版, and the 2015 Mie assumption document.
- `cao_2025/`: CAO data descriptions (`calc.pdf` ×2), licence, and the 2025 damage-method summary (`sanko_gaiyo`).
- `guidance/`:
  - FDMA report (2026 full, 2013 chapter 2, 2026 chapter 2, chapter 3);
  - MLIT 都市局 2013 ×2;
  - Wakayama 指針 (H27) and 逃げ切る programme (H26 and the 2025 progress report, with rendered pages).
- `shingu_city/`: 推進計画 (PDF and .txt), the two parsed evacuation-site CSVs, and rendered pages of the 地域防災計画.
- `gsi_hinanbasho/`: `30207_{1,2}` and `24562_{1,2}` (.csv and .geojson), the notice, and the H25-tagged tsunami sites.
- `_web/`: raw HTML/JSON snapshots (KSJ, BODIK, geocloud, ArcGIS, nigedoki docs, terms pages) and helper scripts.

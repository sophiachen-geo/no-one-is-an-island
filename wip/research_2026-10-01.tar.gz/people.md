# People, age and services: Shingū (30207) and Kihō (24562)

Research date: 2026-10-01. Every URL below returned HTTP 200 through the proxy on that date unless noted. Quotes are
copied from the fetched files. Downloads are in `research/people/` (folder index in section 7). Scripts that build the
derived files are in `research/people/scripts/`.

Labels: **verified** = in the cited primary source; **derived** = computed here (method given); **inference** = my
reading, not stated by the source.

---

## 0. Bottom line

| Question | Answer |
|---|---|
| Newest census data with age at small-area level | **2020 census** (令和2年). The 2025 census has **no** small-area or mesh results yet. Only municipal totals by age are out, published 2026-09-29. |
| Best small-area unit | **Shingū**: 町丁・字 small areas (127 polygons, 122 keys, 115 reporting units after suppression merges). **Kihō**: the census has only **4** small areas (桐原, 高岡, 井田, 鵜殿), which is too coarse for exposure work, so use the **250 m mesh** on both banks. |
| 65+ counts | 2020 census: Shingū 10,111 (38.4% of those with a known age); Kihō 3,867 (37.6%). 2025 census (imputed values): Shingū 9,767 (40.1%); Kihō 3,832 (39.8%). |
| IPSS 2023 projection for 2050 | Shingū 15,423 people, of whom 7,729 are 65+ (50.1%). Kihō 5,713 people, of whom 2,933 are 65+ (51.3%). |
| Vacant housing in Shingū, 2023 | 3,980 of 16,700 dwellings = **23.8%**. The narrower category 「賃貸・売却用及び二次的住宅を除く空き家」 is 2,620 = 15.7%. Kihō is **not tabulated** (towns under 15,000 people are excluded). |
| Newest facility layers (国土数値情報) | P04 医療機関 **2020**; P14 福祉施設 **2023**; P29 学校 **2023**; P05 役場等・公的集会施設 **2022**; P17 消防署 **2012**; P18 警察署 **2012**; P02 公共施設 **2006**. P17, P18 and P02 are **非商用** (non-commercial). P14 for Wakayama is **商用利用不可**. |
| Newer official alternatives | MHLW 医療情報ネット open data (2026-06-01) and 介護サービス情報公表システム open data (end of June 2026). Both have coordinates; MHLW states CC BY / PDL1.0 terms. |
| Shingū 立地適正化計画 | Adopted March 2017, revised September 2021. It **has no 防災指針**: the term does not appear anywhere in the document, and MLIT's list as of 2026-03-31 shows 新宮市 without the ◎ mark that denotes a published 防災指針. The plan excludes 土砂災害特別警戒区域, 土砂災害警戒区域, 土砂災害危険箇所 and 津波避難困難地域 from **both** zones. It does **not** exclude tsunami or Kumano River flood inundation areas, and it sets **no depth thresholds**. |
| National red-zone rule | Article 81(19) of the 都市再生特別措置法, plus 施行令 Article 30. The 2020 cabinet order added 地すべり防止区域, 急傾斜地崩壊危険区域 and 土砂災害特別警戒区域. It was promulgated **2020-10-23** and took effect **2021-10-01**. 浸水被害防止区域 was added from **2021-11**. The 防災指針 provision (Art. 81(2)(5)) took effect **2020-09-07**. |

---

## 1. Census population by age at small-area level

### 1.1 Is any 2025 census small-area or mesh data out? No (verified)
- The Statistics Bureau results page for the 2025 census (https://www.stat.go.jp/data/kokusei/2025/kekka.html):
  - 人口等基本集計 is dated 「令和8年 9月29日」.
  - 小地域集計 / 人口等基本集計に関する集計 is listed as 「各集計区分の公表後、順次公表」.
  - The 集計体系 PDF (https://www.stat.go.jp/data/kokusei/2025/pdf/schedule.pdf) says the small-area tabulation is 「該当する基本集計等の公表後に集計し、地理データ等を活用して秘匿処理を施した上で、速やかに公表」, covering 「町丁・字等、基本単位区、地域メッシュ」.
- The e-Stat file tree for the 2025 census (`tstat=000001230925`, 643 files, updated 2026-09-29) contains only:
  - 人口速報集計 (2026-05-29);
  - 人口等基本集計 (2026-09-29);
  - 不詳補完値 reference tables.
- The e-Stat GIS download catalogue (`/gis/statmap-search/search_detail`, queried with `toukeiYear=2025`) lists census years 1995–2020 only. A 2025 boundary query returned no data.
- **Inference:** for 2020, small-area results (2022-02-10) followed the municipal basic tabulation (2021-11-30) by about 2.4 months. If 2025 follows the same pattern, small-area data would arrive around December 2026. Nothing official gives a date.

### 1.2 2020 small areas (町丁・字等): boundaries and age tables (verified, downloaded)

**Publisher:** 総務省統計局 / e-Stat 統計地理情報システム.

**Release dates:**
- Statistics Bureau: 小地域 人口等基本集計 released 「令和4年2月10日」 (https://www.stat.go.jp/data/kokusei/2020/kekka.html).
- e-Stat GIS: tables T001081 and T001082 released 2022-06-24; catalogue updated 2022-08-29.

| File (in `people/census2020_smallarea/`) | What it is | URL |
|---|---|---|
| `A002005212020DDSWC30207-JGD2011.zip`, `…24562-JGD2011.zip` | 2020 小地域 boundaries, Shapefile, JGD2011 lat/lon. JGD2000 versions without the suffix are also kept; the geometry is identical, only the record order differs. | `https://www.e-stat.go.jp/gis/statmap-search/data?dlserveyId=A002005212020&code=30207&coordSys=1&format=shape&downloadType=5&datum=2011` (also `code=24562`; `datum=2000` for JGD2000) |
| `tblT001082C30.zip`, `tblT001082C24.zip` | T001082 「年齢（５歳階級、４区分）別、男女別人口」 for each small area in Wakayama (30) and Mie (24). CSV, CP932. Columns: totals including age unknown, 5-year bands up to 70–74, 15歳未満, 15～64, **65歳以上**, **75歳以上**, each by sex. | `https://www.e-stat.go.jp/gis/statmap-search/data?statsId=T001082&code=30&downloadType=2` (and `code=24`) |
| `tblT001081C30.zip`, `tblT001081C24.zip` | T001081 「男女別人口総数及び世帯総数」 | same pattern with `statsId=T001081` |
| `derived_smallarea_age_2020_shingu_kiho.csv` / `.geojson` | **Derived.** The two above joined. Suppressed areas are merged into their receiving area. Fields: pop_total, age0_14, age15_64, age65p, age75p, share65 (known ages only), area. | built by `scripts/build_census.py` |

**Reconciliation (derived):**
- The sum over all areas equals the municipal totals exactly.
- Shingū: population 27,171; 65+ 10,111; 75+ 5,576; age unknown 852.
- Kihō: population 10,321; 65+ 3,867; 75+ 2,025; age unknown 27.

**Caveats:**
- **Suppression (秘匿).** Small units show `X`, with HTKSYORI=2 and HTKSAKI giving the receiving area.
  - Shingū has **7** suppressed areas: 大橋通一丁目, 熊野川町鎌塚, 畝畑, 谷口, 山本, 志古二区 and 松沢.
  - They are merged into 5 receiving areas: 大橋通二丁目, 熊野川町滝本, 能城, 志古 and 音川.
  - So Shingū's 122 unique keys become 115 reporting units. Kihō has no suppression.
  - `-` means zero population.
- **Kihō is only 4 small areas.**

  | Small area | Population | 65+ | 65+ share |
  |---|---|---|---|
  | 鵜殿 | 3,761 | 1,224 | 32.7% |
  | 井田 | 3,513 | 1,155 | 32.9% |
  | 高岡 | 1,945 | 975 | 50.2% |
  | 桐原 | 1,102 | 513 | 46.6% |

- **Largest 65+ counts in Shingū (derived):**

  | Small area | Population | 65+ |
  |---|---|---|
  | 新宮 (one large area) | 3,823 | 1,162 |
  | 三輪崎 | 1,377 | 607 |
  | 佐野 | 1,747 | 455 |
  | 王子町一丁目 | 577 | 250 |
  | 熊野地二丁目 | 604 | 249 |

- **蜂伏** has 108 residents, all aged 65+. This is consistent with the care homes located there.

**Licence:**
- The e-Stat GIS terms, Art. 6 (https://www.e-stat.go.jp/gis-terms): 「本機能が提供する情報（以下「コンテンツ」という。）の利用条件等は、「政府統計の総合窓口（e-Stat）利用規約」に準じるものとします。」
- The e-Stat terms (https://www.e-stat.go.jp/terms-of-use): 「当サイトで公開している情報…は、どなたでも以下の１）～６）に従って、複製、公衆送信、翻訳・変形等の翻案等、自由に利用できます。商用利用も可能です。」 and 「本利用ルールは、クリエイティブ・コモンズ・ライセンスの表示 4.0 国際…と互換性があり」. This is the Government Standard Terms of Use 2.0, which is compatible with CC BY 4.0.

### 1.3 2020 census mesh statistics with age (verified, downloaded)

Shingū and Kihō lie in first-level meshes **5035** and **5036**. The first-level files contain every populated cell regardless of prefecture, so they cover both banks.

| File (in `people/census2020_mesh/`) | Table (statsId) | Unit | e-Stat release |
|---|---|---|---|
| `tblT001142Q5035.zip`, `…Q5036.zip` | 人口及び世帯 (JGD2011): total, 0–14, 15–64, **65+, 75+, 85+, 95+**, households, 高齢単身世帯, 高齢夫婦世帯, 65歳以上世帯員のいる世帯 | 250 m (1/4 mesh) | 2024-03-14 (JGD2000 version T001102: 2022-07-27) |
| `tblT001196Q5035.zip`, `…Q5036.zip` | ５歳階級別人口 (JGD2011): 5-year bands to 95+, mean and median age | 250 m | 2025-09-09 (JGD2000 version T001175: 2025-07-29) |
| `tblT001141H*.zip`, `tblT001192H*.zip` | as above | 500 m | 2024-03-14 / 2025-09-09 |
| `tblT001231E*.zip`, `tblT001233E*.zip` | **参考表**: 人口及び世帯, 5歳階級 (JGD2011) | 125 m (1/8 mesh) | 2025-12-16 |
| `derived_mesh250_2020_shingu_kiho.geojson` | **Derived.** 591 cells of 250 m that touch either municipality, with polygons built from mesh codes. Each cell carries pop, 65+, 75+, 85+, households, elderly single and couple households, mean and median age, and frac_in_shingu / frac_in_kiho (share of the cell's area in each). | 250 m | `scripts/build_census.py` |
| `estat_gis_census_table_catalogue.csv` | all 133 census tables in e-Stat GIS (1995–2020) with IDs and dates | | |

**Download URL pattern:**
`https://www.e-stat.go.jp/gis/statmap-search/data?statsId=T001142&code=5035&downloadType=2`. Use `code=<first-level mesh>`, or `code=<prefecture>` for prefecture-clipped files, which have been offered since 2025-10-09.

**Notes:**
- Municipality–mesh lists: `stat_meshcodes_30_wakayama.csv` and `stat_meshcodes_24_mie.csv`, from https://www.stat.go.jp/data/mesh/csv/30.csv and `/24.csv` (1 km codes per municipality, 2020 boundaries).
- Usage notes PDF `mesh_ryuijikou.pdf` (https://www.stat.go.jp/data/mesh/pdf/ryuijikou.pdf, updated December 2025). It says:
  - **JGD2000 vs JGD2011:** the two give different results only in 20 eastern prefectures, from 青森県 to 岐阜県. Wakayama and Mie are not among them, so the two datums are interchangeable here.
  - **Suppression:** 「一定規模以下の地域メッシュにおいて結果数値を秘匿…「*」で表章し…合算先地域メッシュに足しあげています」. Total population, men, women and households are never suppressed (「秘匿しない項目：人口（総数、男、女）、世帯総数、一般世帯数、一般世帯人員」).
  - **125 m 参考表:** 「当該基本単位区のデータを、同定した各６次メッシュに機械的に配分して…参考までにご活用ください」, i.e. block data is split mechanically across 125 m cells. Use it for display only, not for counts.
- **Derived results** (cells with at least 50% of their area in the municipality):
  - Shingū: 327 cells, population 27,153, 65+ 10,112. In 121 of these cells the 65+ count is `*` (438 people live in them).
  - Kihō: 247 cells, population 10,264, 65+ 3,838. In 85 cells the 65+ count is `*` (390 people).
  - 11 cells straddle the river border.
  - Area-weighted totals: Shingū 27,053, Kihō 10,165. They fall slightly short because some cells extend into neighbouring municipalities.
- Licence: as in 1.2 (e-Stat terms).

### 1.4 2025 census, municipal level: newest numbers with age (verified, downloaded to `people/census2025_municipal/`)

**Sources:**
- 第1-1表: https://www.e-stat.go.jp/stat-search/file-download?statInfId=000040506423&fileKind=0 (b01_01.xlsx)
- 第2-7表, raw values: …statInfId=000040506431… (b02_07.xlsx)
- 第2-7表, 不詳補完値: …statInfId=000040506659… (wb02_07.xlsx)
- All published 2026-09-29.
- Also kept: `000040317626_…FUSHO-HOKAN_2020census_retro.xlsx`, which is the **2020** imputed back-tabulation, despite sitting under the 2025 tree.

| 2025-10-01 | Shingū | Kihō |
|---|---|---|
| Population | 24,331 (2020: 27,171; −10.45%) | 9,640 (2020: 10,321; −6.60%) |
| Households | 12,157 | 4,614 |
| 65+, raw (age unknown excluded from share) | 9,668 (40.33%), 359 age unknown | 3,657 (40.10%), 520 age unknown |
| 75+ / 85+, raw | 5,857 / 2,049 | 2,199 / 780 |
| **65+, 不詳補完値** | **9,767 (40.14%)** | **3,832 (39.75%)** |
| 75+ / 85+, 不詳補完値 | 5,912 / 2,071 | 2,309 / 808 |
| Mean / median age, 不詳補完値 | 54.42 / 57.96 | 54.28 / 57.59 |

Kihō row, 第1-1表, verbatim: `2267_紀宝町 | 9640 | 4470 | 5170 | 10321 | -681 | -6.5982 | 86.46035 | 79.62 | 121.1 | 4614 …`

### 1.5 Resident-register data by district and age: not found
- Shingū's population page (https://www.city.shingu.lg.jp/info/2708, updated 2026-09-25) has only city-wide PDFs.
- I found no district-by-age table for Kihō.

---

## 2. IPSS 2023 projections (令和5年推計), exact numbers (verified, downloaded to `people/ipss2023/`)

**Publisher:** 国立社会保障・人口問題研究所, 『日本の地域別将来推計人口（令和5（2023）年推計）』, released **2023-12-22** (report published October 2024).
- Page: https://www.ipss.go.jp/pp-shicyoson/j/shicyoson23/t-page.asp
- Tables: https://www.ipss.go.jp/pp-shicyoson/j/shicyoson23/2gaiyo_hyo/gaiyo.asp
- Files: `kekkahyo1.xlsx` (総人口), `kekkahyo2_3.xlsx` (65+), `kekkahyo2_4.xlsx` (75+), `kekkahyo3_3.xlsx` (65+ share), `kekkahyo3_4.xlsx`, in `…/2gaiyo_hyo/`. The server's Last-Modified is 2026-04-24, but the values match the 2023 release.

| Year | Shingū total | Shingū 65+ | 65+ share | Shingū 75+ | Kihō total | Kihō 65+ | 65+ share | Kihō 75+ |
|---|---|---|---|---|---|---|---|---|
| 2020 (base) | 27,171 | 10,414 | 38.33% | 5,726 | 10,321 | 3,872 | 37.52% | 2,026 |
| 2025 | 25,150 | 10,174 | 40.45% | 6,195 | 9,522 | 3,794 | 39.84% | 2,285 |
| 2030 | 23,065 | 9,824 | 42.59% | 6,209 | 8,719 | 3,685 | 42.26% | 2,345 |
| 2035 | 21,041 | 9,372 | 44.54% | 5,972 | 7,944 | 3,497 | 44.02% | 2,270 |
| 2040 | 19,074 | 9,002 | 47.20% | 5,701 | 7,191 | 3,387 | 47.10% | 2,173 |
| 2045 | 17,195 | 8,381 | 48.74% | 5,387 | 6,429 | 3,197 | 49.73% | 2,000 |
| 2050 | 15,423 | 7,729 | 50.11% | 5,216 | 5,713 | 2,933 | 51.34% | 1,945 |

**Verbatim rows:**
- `30207 | 2 | 和歌山県 | 新宮市 | 27171 | 25150 | 23065 | 21041 | 19074 | 17195 | 15423`
- `24562 | 3 | 三重県 | 紀宝町 | 10321 | 9522 | 8719 | 7944 | 7191 | 6429 | 5713`
- 65+ (結果表2-3): `新宮市 10414 | 10174 | 9824 | 9372 | 9002 | 8381 | 7729`; `紀宝町 3872 | 3794 | 3685 | 3497 | 3387 | 3197 | 2933`

**Why the 2020 base 65+ (10,414) differs from the census count (10,111):** IPSS uses imputed ages. The 概要 (`gaiyo_s.pdf`) says: 「いずれも，令和2 年国勢調査の参考表として公表されている「令和2 年国勢調査に関する不詳補完結果」を用いている。」

**Derived, 2025 actual (imputed values) against the projection:**
- Shingū: 24,331 vs 25,150 (−819, −3.3%); 65+ 9,767 vs 10,174 (−4.0%).
- Kihō: 9,640 vs 9,522 (**+118, +1.2%**); 65+ 3,832 vs 3,794 (+1.0%).

**Licence** (https://www.ipss.go.jp/site-ad/link/anlink.html): 「権利表記の記載がない限り「公共データ利用規約（第1.0版）」（PDL1.0）に準拠した利用条件の下で、利用することができます。」 Attribution is required, and edits must be marked as such.

---

## 3. Vacant housing, 2023 住宅・土地統計調査 (verified, downloaded to `people/housing2023/`)

**Table:** 令和5年住宅・土地統計調査 住宅及び世帯に関する基本集計, 第1-2表 「居住世帯の有無(8区分)別住宅数及び住宅以外で人が居住する建物数－全国、都道府県、市区町村」. Published **2024-09-25**.
- Download: https://www.e-stat.go.jp/stat-search/file-download?statInfId=000040209842&fileKind=0 (`e001_2_jutaku2023_t1-2.xlsx`)

**Shingū, verbatim row:** `30207_新宮市 | 16700 | 12440 | 12400 | 40 | 4260 | 250 | 3980 | 2620 | 1110 | 30 | 230 | 30 | 60`

| Item, Shingū 2023 | Dwellings | Share of all dwellings (derived) |
|---|---|---|
| 総数 | 16,700 | |
| 居住世帯あり | 12,440 | 74.5% |
| **空き家** | **3,980** | **23.8%** |
| ・賃貸・売却用及び二次的住宅を除く空き家 | 2,620 | 15.7% |
| ・賃貸用 / 売却用 / 二次的住宅 | 1,110 / 30 / 230 | |

**Comparisons:**
- Shingū in 2018 (第1-2表, statInfId 000031865669, https://www.e-stat.go.jp/stat-search/file-download?statInfId=000031865669&fileKind=0): 16,900 dwellings; 空き家 3,710 (22.0%); 「その他の住宅」 2,560 (15.1%). In 2023 that category was renamed 賃貸・売却用及び二次的住宅を除く空き家.
- Wakayama Prefecture in 2023: 495,600 dwellings; 空き家 105,300 (21.2%); 59,800 (12.1%).

**Kihō is not tabulated.** 利用上の注意 (https://www.stat.go.jp/data/jyutaku/2023/pdf/riyou.pdf) says: 「市区町村の結果については、市区及び人口１万５千人以上の町村を表章の対象とした（人口は令和２年国勢調査時点）。」 Kihō had 10,321 people in 2020.

**Precision:**
- It is a sample survey: 「本調査は標本調査であるため、統計表の数値は標本誤差を含んでいる」.
- Municipal figures are rounded to the nearest 10.
- Standard errors for Wakayama cities under 50,000 (`se_table1.xlsx`, https://www.stat.go.jp/data/jyutaku/2023/zuhyou/sui_01_chiiki.xlsx, sheet 5万未満市区): estimate 10,000 → 2.89%; 5,000 → 5.29%; 3,000 → 7.46%. So 3,980 vacant dwellings is about **±6% (1 SE)** (derived by interpolation).

**Licence:** e-Stat terms, as in 1.2.

---

## 4. Official facility layers

### 4.1 国土数値情報 (MLIT) layers (verified; prefecture files for 30 and 24 downloaded to `people/ksj/`)

Download base: `https://nlftp.mlit.go.jp/ksj/gml/data/<ID>/<ID-YY>/<file>`. Each file contains GML + Shapefile (+ GeoJSON for newer layers).

| Layer | Newest version (from the page) | Files | Licence as displayed on the page | Shingū / Kihō count (derived subset) |
|---|---|---|---|---|
| **P04 医療機関** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P04-2020.html)) | 「最新のデータはデータ作成年度 2020年度（令和2年度）版」; updated 2021. Earlier versions: 2010, 2014. | `P04-20_30_GML.zip`, `P04-20_24_GML.zip` | 「オープンデータ（CC_BY_4.0）」 | Shingū: 3 hospitals, 37 clinics, 27 dental. Kihō: 0 / 6 / 6. |
| **P14 福祉施設** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P14-2023.html)) | 「データ基準年度 2023年度（令和5年度）版」; 「2024年6月：…に更新」. Earlier versions: 2021, 2015, 2011. | `P14-23_30_GML.zip`, `P14-23_24_GML.zip` | 「オープンデータ（CC_BY_4.0（一部制限））」. **Wakayama: 「公開可・商用利用不可」** (see below). Mie: not listed among the exceptions. | Shingū 90 (老人福祉 15, 障害者支援 3, 児童 19, その他 53). Kihō 19. |
| **P29 学校** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P29-2023.html)) | 2023年度 版, updated June 2024. Source: 学校コード一覧, 2023-05-01. Earlier versions: 2021, 2013. | `P29-23_30_GML.zip`, `P29-23_24_GML.zip` | 「2023年度（令和5年度）、2021年度（令和3年度）：オープンデータ（CC_BY_4.0）」. The 2013 version is 非商用. | Shingū 21 (5 小, 6 中, 3 高, …). Kihō 8 (5 小, 2 中, 1 幼). |
| **P05 市町村役場等及び公的集会施設** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P05-2022.html)) | 「データ基準年 2022年（令和4年）版」; 基準年月 2022年4月; updated 2023. Earlier version: 2010. | `P05-22_30_GML.zip`, `P05-22_24_GML.zip` | 「オープンデータ（CC_BY_4.0）」. 「非商用」 appears in the page source but is commented out. | Shingū 71 (本庁 1, 支所 2, 行政局 1, 公民館 8, 集会施設 59). Kihō 31. |
| **P17 消防署** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P17.html)) | 「最新のデータは2012年（平成24年）版」, as of October 2012. Only version. | `P17-12_30_GML.zip`, `P17-12_24_GML.zip` (point + 管轄 polygon) | **非商用**: 「本データは有償刊行物を使用し作成したものですので商用利用はできません。」 | Shingū 4. Kihō 1 (熊野市消防署紀宝分署). |
| **P18 警察署** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P18.html)) | 2012年 版, as of October 2012. Only version. | `P18-12_30_GML.zip`, `P18-12_24_GML.zip` (point + 管轄 polygon) | **非商用** | Shingū 5 (警察署 1, 交番 2, 駐在所 2). Kihō 3 (紀宝警察署, …). |
| **P02 公共施設** ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P02-2006.html)) | 「最新のデータはデータ作成年度 2006年度（平成18年度）版」. Earlier version: 1990. JGD2000. | `P02-06_30_GML.zip`, `P02-06_24_GML.zip` | **非商用** | Shingū 107, Kihō 38. Outdated; do not use for current services. |
| P34 市区町村役場 (extra) ([page](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-P34.html)) | 2014年度 版, as of 2014-08-31 | `P34-14_30_GML.zip`, `P34-14_24_GML.zip` | 非商用 | Shingū 4, Kihō 1 |

**Subsets:** `people/ksj/subset_shingu_kiho/*.geojson` plus `summary_counts.csv`, built by `scripts/ksj_subset.py`.
- Facilities are assigned by admin code where the layer has one; otherwise by point-in-polygon on the census boundaries with a 150 m buffer.
- Layers whose file names end `_NONCOMMERCIAL` are for internal analysis only (see the terms below).

**P14, Wakayama restriction:**
- Source: R5 per-prefecture terms, `R5_Terms_of_Use_WelfareInstitution.xlsx` (https://nlftp.mlit.go.jp/ksj/gml/codelist/R5_Terms_of_Use_WelfareInstitution.xlsx).
- Row: `和歌山県 | 公開可・商用利用不可 | ・社会福祉施設への問い合わせなどにより本来の業務に支障が出てしまうリスク等が考えられるため、商用利用不可。`
- Mie has no row, so the standard CC BY 4.0 terms apply.

**KSJ terms:**
- Open layers (https://nlftp.mlit.go.jp/ksj/other/agreement_01.html): 「…どなたでも以下の１）～６）に従って、複製、公衆送信、翻訳・変形等の翻案等、自由に利用できます。商用利用も可能です。」 They are compatible with CC BY 4.0. Required credit format: 「出典：「国土数値情報（○○データ）」（国土交通省）（当該ページのURL）（○年○月○日取得）」.
- 非商用 layers (old 約款, https://nlftp.mlit.go.jp/ksj/other/agreement_02.html):
  - 「（ｂ）「非商用」＝出典・加工者等表示のうえ、原著作者等の許諾上、非商用目的のみでの利用（ただし複製物の再配布を除く）が可能なもの」. In other words, **no redistribution of the data files**.
  - 「「非商用」の「国土数値情報」であっても、GISによって空間演算した結果（データベースでないもの）等については、出典及び加工者名を明示することによって利用可能です」.

**Data-quality flag (verified):**
- P04-2020 codes 新宮市立医療センター as P04_010=9 (災害拠点病院 「指定なし」).
- Wakayama Prefecture's list `ksj/wakayama_pref_saigai_kyoten_byoin_list.pdf` (https://www.pref.wakayama.lg.jp/prefg/040100/shisetsu/index_d/fil/10_4-6_iryoukikan.pdf, file dated 2026-09-08) shows 「（災害拠点病院） 新宮市立医療センタ- 新宮市蜂伏18－7」.
- P04 does flag it as 救急告示 (P04_009=1), with 304 beds.

### 4.2 Newer official alternatives from MHLW, 2026 (verified, downloaded to `people/mhlw/`)

| Dataset | Snapshot | URL | Licence (quote) | Shingū / Kihō (derived) |
|---|---|---|---|---|
| 医療情報ネットのオープンデータ (hospital, clinic and dental 施設票 CSV with 所在地座標) | **2026-06-01**. Earlier snapshots from 2024-08 onwards. | https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kenkou_iryou/iryou/newpage_43373.html. Files: `/content/11121000/01-1_hospital_facility_info_20260601.csv.zip`, `02-1_clinic…`, `03-1_dental…` | 「本サイトのコンテンツには公共データ利用規約（第1.0版）（PDL1.0)が適用されています。」 | Hospitals 3 / 0; clinics 29 / 5; dental 21 / 5. Hospitals: 新宮市立医療センター, 新宮病院, 岩崎病院. |
| 介護サービス情報公表システム オープンデータ (CSV per service, with 緯度経度 and 定員) | **End of June 2026** (output 2026-07-09); refreshed every end of June and end of December | https://www.mhlw.go.jp/stf/kaigo-kouhyou_opendata.html. Files: `/content/12300000/jigyosho_<code>_all_20260709….csv` | 「このオープンデータは、厚生労働省ホームページの利用規約に準拠しています。同時に、クリエイティブコモンズライセンスCCBYに準拠しています。…介護サービス情報公表システムから抽出したデータであることを表示した上でご活用ください」 | **Shingū** (residential): 特養 3, 地域密着型特養 2, 老健 1, GH 2, 軽費(地域密着特定施設) 1; plus 短期入所 6+1, 通所 9+7, 通所リハ 3. **Kihō**: 特養 1 (宝寿園), 地域密着型特養 1, GH 1, 有料/サ高住 1; 短期入所 3, 通所 6+4, 通所リハ 1. |

Subset: `people/mhlw/subset_shingu_kiho/mhlw_medical_care_shingu_kiho.{geojson,csv}` (116 points, all with coordinates), built by `scripts/mhlw_subset.py`.

---

## 5. Shingū 立地適正化計画 and the national red-zone rule

### 5.1 The plan document (verified, downloaded to `people/rittekika/`)

**Where it is published:**
- City page: https://www.city.shingu.lg.jp/Info/773, 「新宮市立地適正化計画の改訂・公表について」. The page still shows 「更新日 2017年3月30日」.
- Plan PDF: https://www.city.shingu.lg.jp/div/kikaku/pdf/rittekikaiteiban.pdf (`rittekikaiteiban.pdf`, 104 pp; Last-Modified 2021-10-11). Cover: 「平成２９年３月 策定 / 令和３年９月 改訂」.
- 届出 guide PDF: https://www.city.shingu.lg.jp/div/kikaku/pdf/ricchi/tebiki.pdf (2017).

**Why it was revised in 2021, quoted from the city page:** 「平成29年３月の新宮市立地適正化計画策定時には、居住誘導区域に土砂災害特別警戒区域は含まれていませんでしたが、平成30年７月に和歌山が新たに土砂災害特別警戒区域（通称：災害レッドゾーン）を指定したため、当該区域を居住誘導区域から除く改訂（変更）を行うものです。」

**Still current:** the city's 津波防災地域づくり推進計画 (October 2025, https://www.city.shingu.lg.jp/div/bousai/pdf/suisinkeikaku/suisinkeikaku.pdf) cites 「（出典：令和３年９月新宮市立地適正化計画）」. Nothing newer turned up on the city site.

**Target year:** 「概ね20 年後の平成47 年（2035 年）までとする」.

### 5.2 Does it contain a 防災指針? **No**

**Evidence:**
1. The string 防災指針 does not occur in the 104-page PDF. The table of contents runs from ch. 1 to ch. 8 plus 用語集 and 届出制度. There is no 防災指針 chapter.
2. MLIT's 「立地適正化計画の作成状況」 (as of 2026-03-31, 971 cities; https://www.mlit.go.jp/en/toshi/city_plan/content/002011503.pdf, linked from https://www.mlit.go.jp/en/toshi/city_plan/compactcity_network.html as 「令和８年３月３１日現在（９７１都市）」):
   - The legend reads: 「立地適正化計画を作成・公表の都市（黒字：６８５都市）。うち、防災指針を作成・公表の都市（黒太字◎：５３５都市）」.
   - 新宮市 is printed in **black regular type with no ◎**: plan published, no 防災指針.
   - By contrast, 新宮町◎ is Shingū *town* in Fukuoka.
   - 紀宝町 does not appear at all. Neighbouring 熊野市 is listed as 作成中・作成予定.

### 5.3 How hazards are treated in the two zones (verified quotes; the plan sets no depth thresholds)

**Zones and areas** (from the map legends, pp. 77 and 79):

| District | 都市機能誘導区域 | 居住誘導区域 |
|---|---|---|
| 緑丘・城南 | 94.8 ha | 339.9 ha |
| 光洋 | 63.2 ha | 165.9 ha |

The PDF text layer on p. 77 instead reads 「居住誘導区域（338.8 ha）」. **Inference:** 338.8 ha is the post-2021 figure, after the red-zone removal, while the map image still shows the 2017 figure.

**都市機能誘導区域** (§6-1/6-2, p. 72–73):
- Rule: 「本市は都市計画区域内の広範囲で，防災上の危険性が懸念されており，誘導方針に基づき，特に危険性の高い地域は区域から除外するものとする。」
- Extent: 「中心拠点（新宮駅）・・・概ね1km 圏域，概ね商業系用途に囲まれた地域」 and 「地域拠点（三輪崎駅，新宮市立医療センターバス停）・・・概ね800m 圏域」.
- 除外 in the flow diagram: 「●土砂災害特別警戒区域 ●土砂災害警戒区域 ●土砂災害危険箇所 ●津波避難困難地域」.

**居住誘導区域** (§6-5, p. 75):
- Inclusion conditions: 「・都市計画区域 ・公共交通利用圏域（鉄道駅1,000 m，バス停500 m） ・一定規模の人口密度（30 人/ha 程度）の維持が可能で上記に連担する地域 ・将来的に用途地域の指定を検討する地域」.
- Exclusions, verbatim: 「<<居住誘導区域から除外する地域>> ・居住誘導区域に含めないこととされている区域 ・居住を誘導することが困難な工業地域及び工業専用地域 ・土砂災害特別警戒区域 ・土砂災害警戒区域 ・土砂災害危険箇所 ・津波避難困難地域 ・一団の非可住地」.
- §6-6 adds 「③ 災害危険区域」 to the list of boundary lines used when drawing zone edges.

**What stays inside the zones** (verified text; the conclusion is derived):
- The plan's hazard analysis says 「◆緑丘・城南地域の北東部は，広範囲にわたり津波浸水想定区域となっている。◆光洋地域は，新宮港など国道42 号より東側が津波浸水想定区域となっている。」 (p. 33).
- It also says 「◆緑丘・城南地域は広範囲にわたり，熊野川浸水想定区域となっている。」 (p. 34). The flood map is sourced to 国土数値情報 H23.
- The 2011 Kii flood extent is mapped on p. 35.
- None of these is on the exclusion list, so **tsunami and flood inundation areas lie inside both zones, at any depth**.
- The plan gives **no inundation-depth thresholds**. 「0.5」 and 「3m」 in the text are unrelated statistics.

**Exposure statement (p. 53):** 「防災上危険性が懸念される地域（ここでは，南海トラフ巨大地震における津波浸水想定区域，熊野川浸水想定区域，H23 紀伊半島大水害における浸水域，土砂災害警戒区域，土砂災害危険箇所）に居住する人口割合は68.2％である。」 The base is 2010 population estimated on a 100 m mesh, with a total of 31,498.

**Policy text (p. 66):** 「…行政・民間・住民等が共通認識を持った戦略的な都市づくり（誘導区域の適正な配置）を行うことにより，災害リスクの低減を図る。」

**People-based figures in the city's tsunami 推進計画 (October 2025)** (verified; the plan does not state the population base date):

| | 新宮地区 | 三輪崎・佐野・木ノ川・蜂伏地区 |
|---|---|---|
| 区域内人口 | 17,183 | 7,522 |
| 区域内高齢者人口 | 6,704 | 2,539 |
| 区域内避難行動要支援者数 | 2,816 | 811 |
| 区域内津波避難困難地域人口 | 185 | 600, marked 「※…避難マップの作成・配布等により解消」 |

- 津波避難困難地域 are defined as residential areas with ≥30 cm inundation, using a 5-minute start and walking at 30 m/min.
- Same plan: 「津波の浸水深が２ｍ以上となる区域では、木造家屋や老朽化した建築物等が流出する危険性が高く」.

### 5.4 National rule: red zones excluded from 居住誘導区域; 防災指針 (verified quotes)

e-Gov 法令検索 was under maintenance on 2026-10-01 (HTTP 403, 「ただいまシステムメンテナンス中です」). The texts below are therefore taken from MLIT's official bill text, new-old comparison and 参照条文 PDFs.

**都市再生特別措置法 第81条第19項.** Text as quoted in MLIT's 参照条文 for the 2020 cabinet order (https://www.mlit.go.jp/report/press/content/001368528.pdf): 「第二項第二号の居住誘導区域は、立地適正化計画の区域における人口、土地利用及び交通の現状及び将来の見通しを勘案して、良好な居住環境が確保され、公共投資その他の行政運営が効率的に行われるように定めるものとし、都市計画法第七条第一項に規定する市街化調整区域…、建築基準法第三十九条第一項に規定する災害危険区域（同条第二項の規定に基づく条例により住居の用に供する建築物の建築が禁止されているものに限る。）その他政令で定める区域については定めないものとする。」
- This paragraph predates 2020. The 2020 act renumbered it: 「第十四項を第十九項とし」.

**防災指針, Art. 81(2)(5)**, added by 令和2年法律第43号 (bill text https://www.mlit.go.jp/report/press/content/001327918.pdf; new-old comparison 001327919.pdf):
- Lead sentence: 「２ 立地適正化計画には、その区域を記載するほか、おおむね次に掲げる事項を記載するものとする。」
- Item 5: 「五 居住誘導区域にあっては住宅の、都市機能誘導区域にあっては誘導施設の立地及び立地の誘導を図るための都市の防災に関する機能の確保に関する指針（以下この条において「防災指針」という。）に関する事項」.

**Effective dates of the 2020 act:**
- MLIT 施行通知 (国都まち第55号 ほか, 2020-09-07; https://www.mlit.go.jp/toshi/content/001362391.pdf): 「本年６月１０日に公布され、同年９月７日から施行されます。」
- Bill 附則第1条: the 開発許可 provisions (都市計画法33条/34条) and the 都市再生特別措置法88条 勧告 provision took effect within 2 years. MLIT's 流域治水施策集 dates the 自己業務用施設 development ban 「R4.4～」.
- The 附則 contains **no transitional exemption** for plans adopted before 2020, and **no deadline** for adding a 防災指針.

**施行令 第30条, red zones added.** Press release, 2020-10-20 (https://www.mlit.go.jp/report/press/toshi07_hh_000163.html):
- 「災害危険区域に加えて、災害リスクの高い区域である地すべり防止区域※、急傾斜地崩壊危険区域※及び土砂災害特別警戒区域について、居住誘導区域を定めない区域に追加することとします。」
- 「公　布：令和２年10月23日（金）/ 施　行：令和３年10月１日（金）」
- The ※ exception: zones are not excluded where 防止工事 and maintenance ensure safety.

New text of Art. 30 (https://www.mlit.go.jp/report/press/content/001368527.pdf): 「第三十条 法第八十一条第十九項の政令で定める区域は、次に掲げる区域とする。一 都市計画法施行令第八条第二項各号に掲げる土地の区域 二 地すべり等防止法…第三条第一項に規定する地すべり防止区域（…措置が講じられている土地の区域を除く。） 三 急傾斜地の崩壊による災害の防止に関する法律…第三条第一項に規定する急傾斜地崩壊危険区域（…を除く。） 四 土砂災害警戒区域等における土砂災害防止対策の推進に関する法律（平成十二年法律第五十七号）第九条第一項に規定する土砂災害特別警戒区域」.

**Later addition: 浸水被害防止区域** (特定都市河川浸水被害対策法 第56条第1項).
- MLIT 手引き 【基本編】 R7.4 (https://www.mlit.go.jp/en/toshi/city_plan/content/001741220.pdf, p. 30/32) lists it as 「都市再生特別措置法施行令第30条第1項第5号」 → 「定めない」.
- MLIT 流域治水施策集 (https://www.hrr.mlit.go.jp/toyama/upload/file/ryuuikichisuiproject_r5/16-2_sankoushiryou4-2.pdf): 「（参考）災害レッドゾーン ・浸水被害防止区域（R3.11施行）…」 and 「居住誘導区域から原則除外」.
- **Relevance (inference):** 市田川 is due to be designated a 特定都市河川 in FY2026 (see `research/official_links.md`). Any 浸水被害防止区域 later designated there would have to come out of Shingū's 居住誘導区域.

**Yellow zones and depth thresholds**, per the national guidance (手引き R7.4). These are not binding.

Table 「主なレッドゾーン・イエローゾーンと居住誘導区域との関係」 (p. 32):
- 津波災害特別警戒区域: 「原則として含まないこととすべき（都市計画運用指針）」.
- 浸水想定区域 (水防法), 土砂災害警戒区域, 津波災害警戒区域, 津波浸水想定, 都市浸水想定: 「総合的に勘案し、適切で無いと判断される場合は、原則として含まないこととすべき」.

Response examples for floods (p. 53):
- Areas with frequent floods: 「一般的な家屋において被害が想定される一定以上の浸水深（床上浸水のおそれのある50cm、垂直避難が困難となるおそれのある3m等）の区域は、居住誘導区域に含めないことが考えられる。」
- 「家屋倒壊等氾濫想定区域では…居住誘導区域に含めないことが考えられる。」
- For 想定最大規模 floods, exclusion is suggested where evacuation is judged infeasible. Where most of the city sits in an inundation area, it may stay inside the zone 「…防災指針の検討において、想定規模・想定浸水深等に応じて十分な防災対策・安全確保策を計画」.

The 2020 施行通知 explains why inundation areas usually stay in: 「洪水、雨水出水、津波、高潮による浸水エリアは広範囲に及び、既に市街地が形成されていることも多いことから、この範囲を居住誘導区域又は都市機能誘導区域から全て除くことは現実的に困難…このため…防災指針を定める」.

**Implication for the page (inference):**
- Shingū already excludes the landslide red zone, and goes further than the law requires by also excluding the yellow zone and 危険箇所.
- It has not added the 防災指針 that MLIT expects for its large tsunami and Kumano River inundation areas.
- Those inundation areas remain inside both zones, with no depth rule.

---

## 6. Caveats and items not found
- **2025 census small-area or mesh data:** not published as of 2026-10-01. The plan as written uses 2020.
- **Kihō vacancy rate:** not available from the 2023 survey.
- **Resident-register data by 町丁 and age:** not found for either municipality.
- **Population base date for the 推進計画 tables:** not stated in the plan.
- **e-Gov law texts:** e-Gov was unavailable (maintenance), so quotes come from MLIT PDFs. They match the current paragraph numbering, which the 手引き R7.4 still cites as 第81条第19項 and 施行令第30条第1項第2–5号.
- **P02, P17, P18, P34 (非商用):** do not republish the data files. Maps or counts derived from them may be shown with attribution, per 約款 第3条(2).
- **P14 for Wakayama:** commercial use is not permitted.
- **KSJ P04 (2020):** the 災害拠点病院 flag is missing for 新宮市立医療センター.

---

## 7. File index (`research/people/`)

| Folder | Contents |
|---|---|
| `census2020_smallarea/` | Boundaries (JGD2011 + JGD2000) for 30207 and 24562; tables T001082 (age) and T001081 for prefectures 30 and 24; derived CSV/GeoJSON; e-Stat terms pages |
| `census2020_mesh/` | 250 m / 500 m / 125 m tables for meshes 5035 and 5036; municipality mesh-code lists; mesh usage-notes PDF; derived 250 m GeoJSON; table catalogue CSV |
| `census2025_municipal/` | 2025 第1-1表, 第2-7表 (raw), 第2-7表 不詳補完値; 2020 imputed back-tabulation |
| `ipss2023/` | 結果表 1, 2-3, 2-4, 3-3, 3-4; 概要 PDF; pages; terms page |
| `housing2023/` | 2023 and 2018 第1-2表; 利用上の注意; standard-error table; area list |
| `ksj/` | P04-20, P14-23, P29-23, P05-22, P17-12, P18-12, P02-06, P34-14 for prefectures 30 and 24; P14 per-prefecture terms; KSJ terms pages; `subset_shingu_kiho/`; Wakayama 災害拠点病院 list |
| `mhlw/` | Raw 2026 CSVs (medical, care); `subset_shingu_kiho/` |
| `rittekika/` | Plan PDF + text; 届出 PDF; map page renders (`img/`); MLIT status PDF (2026-03-31); `law/` (bill text, new-old comparison, cabinet order release and text, 参照条文, 施行通知, 手引き R7.4, 流域治水施策集); `other/` (tsunami 推進計画 Oct 2025, 国土強靭化 Mar 2026) |
| `scripts/` | `build_census.py`, `ksj_subset.py`, `ksj_parse.py`, `mhlw_subset.py` |
| `_scratch/` | Probe files from the search; not needed |

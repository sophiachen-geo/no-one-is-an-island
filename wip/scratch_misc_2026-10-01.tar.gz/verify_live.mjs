// Post-deploy check of the live site: files served byte-identical to main, page boots without JS errors,
// new sections present, lazy building layer and photos load from the deployed paths.
const { chromium } = await import("/opt/node22/lib/node_modules/playwright/index.mjs");
import { readFileSync, readdirSync } from "node:fs";
import { createHash } from "node:crypto";

const BASE = "https://sophiachen-geo.github.io/no-one-is-an-island/";
const REPO = "/home/user/no-one-is-an-island/";
const sha = (b) => createHash("sha256").update(b).digest("hex").slice(0, 16);
let bad = 0;
const say = (ok, msg) => { if (!ok) bad++; console.log(`${ok ? "ok " : "BAD"} ${msg}`); };

async function same(rel, local) {
  const r = await fetch(BASE + rel + (rel.endsWith("/") ? "" : "") + "?v=" + Date.now(), { cache: "no-store" });
  const buf = Buffer.from(await r.arrayBuffer());
  const want = readFileSync(REPO + local);
  say(r.status === 200 && sha(buf) === sha(want), `${rel || "/"} ${r.status} ${buf.length} B ${sha(buf) === sha(want) ? "= repo" : "≠ repo (" + want.length + " B)"} [${r.headers.get("content-type")}]`);
}

await same("", "index.html");
await same("kansai/", "kansai/index.html");
await same("kansai/data/buildings.js", "kansai/data/buildings.js");
for (const f of ["kamikura.js", "kamikura_relief.jpg", "kamikura_elev.jpg", "kamikura_slope.jpg", "kamikura_lrm.jpg", "kamikura_curv.jpg",
                 "kamikura_study.geojson", "kamikura_study.kml", "kamikura_cadastre.geojson"]) await same("kansai/data/" + f, "kansai/data/" + f);
for (const f of readdirSync(REPO + "kansai/img")) await same("kansai/img/" + f, "kansai/img/" + f);

// Chromium does not trust the sandbox proxy's CA, so every HTTPS request the page makes is fetched by Node
// (which verifies against NODE_EXTRA_CA_CERTS) and handed back to the page unchanged.
const offsite = {};
async function viaNode(route) {
  const q = route.request(), h = q.headers(), pass = {};
  for (const k of ["accept", "range", "user-agent", "accept-language"]) if (h[k]) pass[k] = h[k];
  try {
    const r = await fetch(q.url(), { method: q.method(), headers: pass, redirect: "follow" });
    const body = Buffer.from(await r.arrayBuffer()), headers = {};
    r.headers.forEach((v, k) => { if (!/^(content-encoding|content-length|transfer-encoding|connection)$/i.test(k)) headers[k] = v; });
    if (!q.url().startsWith(BASE)) { const host = new URL(q.url()).host; offsite[host] = offsite[host] || {}; offsite[host][r.status] = (offsite[host][r.status] || 0) + 1; }
    await route.fulfill({ status: r.status, headers, body });
  } catch (e) {
    if (!q.url().startsWith(BASE)) { const host = new URL(q.url()).host; offsite[host] = offsite[host] || {}; offsite[host].err = (offsite[host].err || 0) + 1; }
    await route.abort("failed");
  }
}

const browser = await chromium.launch();
for (const vp of [{ width: 1440, height: 900 }, { width: 390, height: 844 }]) {
  const page = await browser.newPage({ viewport: vp });
  await page.route(/^https:\/\//, viaNode);
  const errs = [], failed = [];
  page.on("pageerror", (e) => errs.push(e.message));
  page.on("console", (m) => { if (m.type() === "error") errs.push(m.text()); });
  page.on("requestfailed", (q) => { if (q.url().startsWith(BASE)) failed.push(q.url()); });
  page.on("response", (r) => { if (r.url().startsWith(BASE) && r.status() >= 400) failed.push(r.status() + " " + r.url()); });
  await page.goto(BASE + "kansai/", { waitUntil: "load", timeout: 90000 });
  await page.waitForTimeout(2500);
  const info = await page.evaluate(() => ({
    intro: !!document.querySelector("#intro .glance"),
    ksmap: !!document.querySelector("#ksmap svg, #ksmap"),
    steps: document.querySelectorAll(".step").length,
    sources: document.querySelector("details#sources") ? !document.querySelector("details#sources").open : null,
    imgs: [...document.images].filter((i) => i.src.includes("/kansai/img/")).length,
    pulses: document.querySelectorAll(".pulse").length,
    satbtn: document.querySelectorAll(".satbtn").length,
    wide: document.documentElement.scrollWidth - window.innerWidth,
  }));
  say(info.intro && info.ksmap, `${vp.width}px intro + linked system map present`);
  say(info.sources === true, `${vp.width}px Sources & method closed by default`);
  say(info.wide <= 0, `${vp.width}px no sideways scroll (${info.wide})`);
  // photos: scroll every page image into view and require it decoded
  const imgs = await page.$$("img[src*='/kansai/img/'], img[src^='img/']");
  let dec = 0;
  for (const h of imgs) { await h.scrollIntoViewIfNeeded(); dec += await h.evaluate(async (i) => { for (let t = 0; t < 60 && !(i.complete && i.naturalWidth); t++) await new Promise((r) => setTimeout(r, 250)); return i.decode().then(() => i.naturalWidth > 0 ? 1 : 0, () => 0); }); }
  say(imgs.length > 0 && dec === imgs.length, `${vp.width}px photos decoded ${dec}/${imgs.length}`);
  // lazy building layer: jump to a step that declares data-bld and zoom in past the threshold
  const bld = await page.evaluate(async () => {
    const st = document.querySelector(".step[data-bld]");
    if (!st) return "no step";
    st.scrollIntoView({ block: "center" });
    await new Promise((r) => setTimeout(r, 1500));
    for (let i = 0; i < 40 && !window.__BLD; i++) await new Promise((r) => setTimeout(r, 250));
    return window.__BLD ? window.__BLD.counts : "not loaded";
  });
  say(typeof bld === "object", `${vp.width}px buildings.js loaded from the deployed path ${JSON.stringify(bld)}`);
  const kmk = await page.evaluate(async () => {
    const ok = await window.__QA.kmkLoad(); const svg = document.querySelector("#kmkmap svg.kmk-svg");
    return { ok, svg: !!svg, labels: svg ? svg.querySelectorAll(".kmk-ov text").length : 0, prof: document.querySelectorAll("#kmkprof path").length,
             relief: svg ? (svg.querySelector("image.k-relief") || {}).href?.baseVal : null,
             img: await new Promise((r) => { const im = new Image(); im.onload = () => r(im.naturalWidth); im.onerror = () => r(0); im.src = "data/kamikura_relief.jpg"; }) };
  });
  say(kmk.ok && kmk.svg && kmk.labels > 10 && kmk.prof >= 2 && kmk.img > 1000, `${vp.width}px Kamikura chapter builds: map, ${kmk.labels} labels, profile, relief ${kmk.img}px wide`);
  const ground = await page.evaluate(async () => {
    const K = window.__QA.kmk, D = window.__KMK, img = document.querySelector("#kmkmap svg.kmk-svg image.k-relief"), out = {};
    for (const key of ["elev", "slope", "lrm", "curv"]) {
      K.setBase(key);
      const href = img.getAttribute("href");
      out[key] = href === D.bases[key].href && !document.getElementById("kmkramp").hidden
        ? await new Promise((r) => { const im = new Image(); im.onload = () => r(im.naturalWidth); im.onerror = () => r(0); im.src = href; }) : -1;
    }
    K.setBase("relief");
    out.figures = ["kmkfoot", "kmkscore", "kmkoff"].map((id) => document.querySelectorAll(`#${id} circle, #${id} path`).length);
    out.name = document.querySelector("#kamikura-study .kflow") ? document.querySelector("#kamikura-study").textContent.includes("神倉堀端都市下水路") : false;
    return out;
  });
  say(["elev", "slope", "lrm", "curv"].every((k) => ground[k] > 1000) && ground.figures.every((n) => n > 0) && ground.name,
      `${vp.width}px ground layers load (${["elev", "slope", "lrm", "curv"].map((k) => k + " " + ground[k] + "px").join(", ")}), figures drawn ${JSON.stringify(ground.figures)}, channel named`);
  const rev = await page.evaluate(() => {
    const t = document.querySelector("#kamikura-study").textContent, sc = document.getElementById("kmkscore");
    return { ve: ["kmkfoot", "kmkprof"].map((id) => document.getElementById(id).getAttribute("data-ve")),
             runs: [...sc.querySelectorAll("text")].map((e) => e.textContent).filter((x) => / of 6$/.test(x)),
             words: ["numbered parcels", "Beyond 25 m, nothing holds", "with both minimum slides", "28% of the study area lies under a GSI outline"].map((w) => t.includes(w)),
             stale: ["private land", "the town bends with the mountain", "1,951"].filter((w) => t.includes(w)) };
  });
  say(rev.ve.every((v) => v === "2.00") && rev.runs.join(",") === "6 of 6,4 of 6,3 of 6,3 of 6,3 of 6,0 of 6,0 of 6,0 of 6,0 of 6" && rev.words.every(Boolean),
      `${vp.width}px review fixes live: heights ×${rev.ve.join("/")}, runs [${rev.runs.join(", ")}], wording ${rev.words.map(Number).join("")}, older wording still present: ${JSON.stringify(rev.stale)}`);
  const sac = await page.evaluate(async () => {
    const K = window.__QA.kmk, chip = document.querySelector('.kchip[data-ks="shinko"]'), card = document.querySelector('.kcard[data-ks="shinko"]');
    K.setSys("shinko", true); await new Promise((r) => setTimeout(r, 400));
    const svg = document.querySelector("#kmkmap svg.kmk-svg"), r0 = svg.getBoundingClientRect();
    const ptrs = [...svg.querySelectorAll(".kptr text")].filter((t) => { const q = t.getBoundingClientRect(); return q.width > 0 && q.left >= r0.left && q.right <= r0.right; }).map((t) => t.textContent);
    K.setSys("all", true);
    const t = document.querySelector("#kamikura-study").textContent;
    return { chip: !!chip, card: !!card, ptrs, figs: ["kmkclimb", "kmksec", "kmktown"].map((id) => document.querySelectorAll(`#${id} path, #${id} circle`).length),
             ve: ["kmkclimb", "kmksec"].map((id) => document.getElementById(id).getAttribute("data-ve")),
             words: ["Where the gods first came down", "15 of these 21 stand in the last 41 m of the climb", "the Kumano’s estuary, 0.4 km from its mouth", "1,217 m²"].map((w) => t.includes(w)) };
  });
  say(sac.chip && sac.card && sac.ptrs.length === 3 && sac.figs.every((n) => n >= 4) && sac.ve.join("/") === "1.00/10.00" && sac.words.every(Boolean),
      `${vp.width}px sacred layer live: chip ${sac.chip}, card ${sac.card}, pointers [${sac.ptrs.join(" | ")}], figures ${JSON.stringify(sac.figs)}, heights ×${sac.ve.join("/")}, wording ${sac.words.map(Number).join("")}`);
  say(errs.length === 0, `${vp.width}px JS errors: ${errs.length ? errs.slice(0, 3).join(" | ") : "none"}`);
  say(failed.length === 0, `${vp.width}px same-origin failures: ${failed.length ? failed.slice(0, 5).join(" | ") : "none"}`);
  console.log(`    steps ${info.steps}, pulses ${info.pulses}, satellite buttons ${info.satbtn}`);
  await page.close();
}
await browser.close();
console.log("off-site requests by host/status:", JSON.stringify(offsite));
console.log(bad ? `\n${bad} problem(s)` : "\nlive site matches main");
process.exit(bad ? 1 : 0);

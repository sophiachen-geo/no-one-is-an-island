A 流れ · 信仰 (sacred) layer for the Kamikura chapter. The religious flow is located, measured and drawn. Every statement is checked against the shrine, the city, the prefecture, the Agency for Cultural Affairs, UNESCO and the local press.

## Map: a new 信仰 system
- New chip and card. The view shows:
  - the shrine's lower precinct;
  - the grounds of the 出雲大社新宮教会 across the channel, drawn and counted separately;
  - the Oto Matsuri route down the steps;
  - the small shrines and the steles at the foot.
- Arrows at the map's edge point to 熊野速玉大社 (0.9 km), 阿須賀神社 (1.3 km) and the mouth of the Kumano (2.8 km).
- The precincts card is corrected. Its 1,951 m² included the church grounds; it is now 1,217 m², plus 734 m² for the church.

## Three figures
1. **The climb, true to scale.**
   - The ground is coloured by slope, with each threshold placed where it lies and dated.
   - The 2024 festival programme is placed on the slope: 19:10 fire, ≈19:25 the great torch to 中ノ地蔵堂 and back, ≈20:00 the gate opens.
   - A strip shows every stele, board and shrine OSM maps within 12 m of the line: 15 of the 21 stand in the last 41 m.
2. **One measured section, 1.6 km.**
   - The line runs rock → steps → the shortest street walk → 熊野速玉大社 → the river bank. The river to its mouth (3.0 km along MLIT's centre line) is drawn as a break.
   - Rows show the gods' path in the shrine's account, the fire, and the water (dotted where it leaves the line).
3. **The town, from 御船島 to the river mouth.** Four flows, each at its own time scale:
   - always: water, Kamikura-yama → 神倉堀端都市下水路 → 市田川 → the estuary;
   - before the Edo period: the pilgrims (Hongū by boat → 熊野速玉大社 → 阿須賀神社 → 浜王子 → 高野坂 → Nachi; the order, not the routes);
   - every 6 February: the priests' times and the climbers' visits;
   - every 16 October: Hayatama's god upriver to 御船島.

## Text
Seven paragraphs:
- the first descent and the name 新宮, hedged where the city hedges it;
- Gongen-yama, UNESCO's reading, and the finds from around the rock (late-Yayoi bell fragments; about 300 Buddhist objects found in 1956);
- the climb as thresholds;
- the festival;
- mountain–town–river–sea;
- layers (the hongan temples, 1531, the decrees of 1868 and 1872, the additions of 1983–2024), and a remade landscape (the goma at Kamikura ended in 2019; Nachi's Gyōjadō was rebuilt in 2023).

The sources are listed in the Sources box, with links wherever the site answers reliably.

## Corrections made while building
- **River mouth.** The section's first draft took the river layer's point nearest the coast as the Kumano's end. That point belongs to another watercourse, 1.3 km from the mouth. The mouth is now where MLIT's centre line (via OSM) meets the coastline, and river distances are measured along that line.
- **Alignment test.** Its "temple and shrine property" class contains the church grounds. It is relabelled "temple, shrine and church grounds"; the results are unchanged.
- **Foot of the steps.** One height (6.6 m, at the bridge) is now used wherever the text gives it.

## Independent review
An adversarial fact-check of the finished section, against the sources and the data, found:
- **Two factual errors, fixed:**
  - the church grounds lie across the channel, on the town side, not between the slope and the channel;
  - "the oldest finds lie on the rock" is now "came from around the rock".
- **Overstatements, now hedged as the sources hedge:**
  - "where, by tradition, the gods first came down";
  - bell *fragments*;
  - the 2024 works as a *donation* with no completion date;
  - the 下馬 stone as a pillar telling riders to dismount;
  - 「ともいわれています」 as "is also said".
- **The gods' path** is now drawn and described as leaving the section line (rock → 石淵 across the river → Hayatama's riverside site).
- **Smaller fixes:**
  - the Gongen gloss now quotes Hayatama's own words;
  - Nachi: Shugendō revived in 1988; the Gyōjadō rebuilt on a new site;
  - the pilgrims' route labelled "before the Edo period";
  - chronology and register citations corrected;
  - the source list states which places are independently checked and which come from OSM alone.

## QA
- New register claims for every number and fact. Derived ones are recomputed from `kamikura.js` on every run.
- Every place on the town figure except the river mouth is checked against an independent coordinate (GSI annotations, Wikidata, GSI address search; `kmc_*` in `points.toml`). A planted 220 m offset is caught. The small shrines and steles on the map come from OSM alone, and the page says so.
- Render checks:
  - the three new figures are drawn;
  - their labels stay inside them;
  - the section (×10) and the climb (true scale) are drawn at the exaggeration their captions state.
- Gate: 0 errors. The 31 warnings are the same as on main.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01EtBegohJj8hLPRQhjcEfPm

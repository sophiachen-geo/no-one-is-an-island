Essay vs sources (for the final report)

Corrected on the page / to tell the user:
1. UNESCO: fusion of Shinto (nature worship) + Buddhism; Shugendō is a separate element "influenced by the former two faiths" (integrity section), not part of the "fusion" sentence.
2. Sign 「史跡 熊野三山（権現山）」: wording real (2019 photo), issuer not visible, no official copy; it does not place the shrine "below the Gotobiki rock". Page uses the city's official text instead.
3. Name 新宮: the city hedges (ともいわれています); Hayatama's account has an intermediate seat, 石淵 (now 貴祢谷) across the river.
4. 538 steps / Yoritomo 1193: tradition (伝えられています). A 1265 poem already mentions the stone way.
5. Archaeology: not an excavation; finds came from 1956 wall repairs (three spots, ~300 Buddhist objects, late Heian–Muromachi). Only the late-Yayoi bell is designated (prefecture, 2012).
6. Oto Matsuri: city ~2,000 is nominal; organisers counted 1,580 (2026). Visiting order is not fixed (Kumano Shimbun: 熊野速玉大社、阿須賀神社、妙心寺など). Men only. The next-day goma/fire-walk at Kamikura (still in the Agency's 2016 text) ended in 2019.
7. 「猿田彦神社・神倉三宝荒神社」: one 神 (三宝荒神社). 1983 → 2024 confirmed.
8. 天磐盾 stele (11 Feb 1990, 2,650th year) confirmed; neither stone nor board names 高倉下 or 八咫烏. 高倉下命 is the shrine's deity (with 天照大御神).
9. Twelve Gongen: 「禅地宮」 not attested; sources write 禅師宮 (city) or 禅児宮 (Hongū). Dating differs (Hayatama ~10th c.; city: three Gongen mid-10th, twelve 11th c.). Not on the page beyond Hayatama's own statement.
10. Myōshinji: Kamikura hongan (title 1531) confirmed; leading the bikuni is "thought to" (日本歴史地名大系) — hedged; the mandala copy 妙心寺旧本 is the documented link.
11. Pilgrim order Hongū → boat → Hayatama → Asuka → 浜王子 → 高野坂 → Nachi: confirmed by Shingū City. Return over the Kumotori pass was one option, not the usual one; river distance 34 km (Wakayama) vs 40 km (nomination).
12. Nachi Gyōjadō 2023 confirmed; cause given as the Meiji separation (AGARA) or the Shugendō ban (Kyodo). Closure 19–21 June 2026 confirmed.
13. Izumo Taisha Shingū church: exists (main deity 大国主大神 on its sign); founding date unverified. Also: OSM had its grounds inside the shrine precinct polygon — now separated.
14. Ōmine Okugakemichi: ~80 km (nomination; 86.9 km inscribed); some sources say ~170 km. Not on the page.

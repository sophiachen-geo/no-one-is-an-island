Terrain-first rework of the Kamikura chapter on the Kansai page. The chapter is regrouped by layer: 下部構造 ground · 中部構造 lots · 上部構造 buildings · 流れ flows. A field kit for the fieldwork parts is included.

## Ground (下部構造)
- **Is 1 m defensible?** Yes.
  - The study area is 100% GSI DEM1A.
  - Against the GSI survey marks within 800 m of the study area: two of three levelling benchmarks agree to 0.01 m and 0.14 m (the third reads 0.79 m low), the two triangulation points to 0.08 m and 0.51 m.
  - DEM5A matches it on flat open ground, but reads the channel as 0.93 m deep instead of 2.68 m.
  - Caveat: 28% of the area lies under building outlines, where the ground is interpolated.
- **New ground layers under the map:** height, slope, local relief (σ 8 m) and profile curvature (σ 2.5 m), each with a colour bar spaced by its colour stops.
- **Where does Kamikura-yama stop?** The foot is located four ways on 310 cross-profiles every 2 m: the mask edge, the plain + 1 m, the most concave point, and a two-segment knee.
  - The map shows their median line and the band between them.
  - Median spread 5.8 m, but over 31 m on a tenth of the profiles. A and B share a 1 m threshold and agree most closely.
  - Median slopes are 40° above the foot and 1° below it.
  - The face stays steep almost to the foot. The steepest metre near the foot is no steeper than the same statistic 10 m up the face, so the page does not claim a cut or wall.
- **What follows the foot?** Each feature class is measured against the town grid, only where the two differ by 10° or more.
  - Chance: the foot's sequence of directions is slid along the foot by 50 m or more (circular shift). A run counts as significant only if it also passes with slides of 100 m or more.
  - Six runs: each foot definition and a second registration of the parcel map.
  - **Within 25 m, holds:** channel centre line (6 of 6 runs), lanes (4).
  - **Leans, does not hold:** channel banks, back boundaries (8 of 9 lines follow), buildings (3 of 6 each).
  - **Nothing:** frontages, temple and shrine property, the drawn waterway, steep steps (0 of 6).
  - **Beyond 25 m:** only two frontages in one place, just north of the study area. Every other class reaches at most 2 of 6.

## Lots (中部構造)
- The MoJ cadastral map is in arbitrary coordinates (任意座標系). It is registered here in two steps:
  1. the school parcel is matched to the school's outline;
  2. the road parcels are fitted to GSI road edges.
- To fit, the drawing is enlarged 13–16% and turned 14°: 31% more area than drawn. Road parcels then sit a median 1.2 m from GSI road edges.
- MLIT reports a 26% average 縄伸び in cadastral surveys certified 1970–2011. It compares registers, not drawings.
- The drawing records numbered lots (地番), not owners. The page and the download say "numbered".
- The numbered parcels end at the foot on the median (0.3 m; −1.7 to +0.9 m across runs). Row by row the edge ranges from 10 m upslope to 12 m out (middle half).
- The cadastre's waterway parcels run a median 35.5 m out. Numbered parcels fill the strip, a single parcel deep on half the rows.
- 宗応寺 is placed on parcel 708-1: its address point is 4.0 m inside and its OSM node 11 m inside. 妙心寺's point lies inside the school parcel, 0.8 m from its edge, so it is left out.

## Flows (流れ)
- The channel is named **神倉堀端都市下水路, the Kamikura Horibata Urban Drainage Channel**: a municipal drainage channel in the upper Ichida-gawa system. The headwater is also documented as Kamikura-gawa.
- Naming levels, shown as overlapping, without legal transition points: 千穂ヶ峰 → 神倉川 → 神倉堀端都市下水路 → 市田川 → 熊野川. MLIT has the Ichida-gawa rising on 千穂ヶ峰, 4.8 km.
- Sourced chronology:
  - FY1959: drainage works begin;
  - 1970–75: Class A river, then direct national control of the lowest 2 km, then 1975 river-area land designated along it and the Ukishima-gawa;
  - FY1999: MLIT landscape works (740 m² stone facing, railings, 124 m planting), listed under two model programmes;
  - FY2025: budget line;
  - 2025: repair tender and re-tender.
- Widths are given per definition: plan 1.5–2.0 m; visible channel about 3.5 m; wall to wall about 4–5 m.
- Today's channel read against the cadastre, where the drawing covers it:
  - north (135 m): in road and waterway strips (59–71%);
  - diagonal (79 m): through numbered parcels, 65–70% more than 3 m inside them; half of it through the school's parcel, up to 11–13 m from its edge;
  - south (about 100 m): along the school parcel's edge, within 3 m of the drawn waterway for 40–65%.

## Field kit (`kansai/field/`)
- Gou & Shibata's visitor-employed photography methods, from Gou's 2017 thesis.
- Their adaptation to six gazes on the Kamikura foot, with one coding frame tied to the measured foot.
- Templates:
  - a photo log;
  - a bridge-census sheet pre-filled with the 7 crossings mapped in OSM;
  - a GPX with the crossings, the transect and the foot.

## Pipeline and QA
- New pipeline steps `05_terrain_plus`, `06_foot`, `07_parcels` and `08_align`, plus `gsi.py` and `mojparse.py`. The export moves to `09_export`.
- New downloads: the four ground rasters and `kamikura_cadastre.geojson` (kind: numbered / road / water / strip; no parcel numbers; MoJ licence attribution included).
- Every number in the chapter has a register claim: 171 claims for the chapter, 136 of which recompute their number from the data.
- Render QA covers:
  - the ground switcher and its colour bars;
  - the three new figures;
  - that both ground profiles are drawn at the vertical exaggeration their captions state (mutation-tested).
- Self-test 19/19. Gate: 0 errors with the real web fonts.

## Review passes
1. **Precision pass:**
   - the cross-profiles were drawn at ×1.49 under a ×2 caption;
   - the building share was overstated (31% → 28%);
   - "beyond 25 m, nothing does" was too strong;
   - the survey-mark distance and the temple-parcel margins were added.
2. **Independent review:** an adversarial fact-check of the chapter against its sources and data.
   - Statistics:
     - the piece-shuffle null ignored spatial autocorrelation, so it was replaced by the circular shift, with one criterion for significance in text and figure;
     - shared boundaries were double-counted;
     - the "steeper than the face above" comparison was unfair.
   - Lots:
     - "private" became "numbered";
     - the row spread of the parcels' edge is now stated;
     - the lane comparison mixed different rows;
     - the channel-course extent is now stated.
   - Sources:
     - MLIT's description of the Ichida-gawa;
     - the scope of notice 157;
     - the FY1999 programmes;
     - 縄伸び hedged as hearsay;
     - 妙心寺 hedged ("thought to");
     - the annex date.
   - Figures and QA:
     - colour bars and the score legend;
     - the residential-inducement area now has a real check;
     - dead fields removed.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01EtBegohJj8hLPRQhjcEfPm
